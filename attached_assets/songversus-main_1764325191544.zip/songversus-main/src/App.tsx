import { Toaster } from "@/components/ui/toaster";
import { Toaster as Sonner } from "@/components/ui/sonner";
import { TooltipProvider } from "@/components/ui/tooltip";
import { QueryClient, QueryClientProvider } from "@tanstack/react-query";
import { BrowserRouter, Routes, Route, useLocation } from "react-router-dom";
import { AnimatePresence, motion } from "framer-motion";
import { lazy, Suspense } from "react";
import { GlobalChat } from "@/components/GlobalChat";
import { SlotMachine } from "@/components/SlotMachine";


// Lazy load all page components for better code splitting
const Splash = lazy(() => import("./pages/Splash"));
const Index = lazy(() => import("./pages/Index"));
const Battles = lazy(() => import("./pages/Battles"));
const BattleView = lazy(() => import("./pages/BattleView"));
const Leaderboard = lazy(() => import("./pages/Leaderboard"));
const Auth = lazy(() => import("./pages/Auth"));
const CharacterCreation = lazy(() => import("./pages/CharacterCreation"));
const Profile = lazy(() => import("./pages/Profile"));
const Store = lazy(() => import("./pages/Store"));
const Community = lazy(() => import("./pages/Community"));
const Inbox = lazy(() => import("./pages/Inbox"));
const NotFound = lazy(() => import("./pages/NotFound"));

const queryClient = new QueryClient();

const pageTransition = {
  initial: { opacity: 0, y: 10 },
  animate: { opacity: 1, y: 0, transition: { duration: 0.3 } },
  exit: { opacity: 0, y: -10, transition: { duration: 0.2 } }
};

const AnimatedRoute = ({ children }: { children: React.ReactNode }) => (
  <motion.div
    initial="initial"
    animate="animate"
    exit="exit"
    variants={pageTransition}
  >
    {children}
  </motion.div>
);

const AnimatedRoutes = () => {
  const location = useLocation();

  return (
    <AnimatePresence mode="wait">
      <Suspense fallback={<div className="min-h-screen flex items-center justify-center"><div className="animate-pulse">Loading...</div></div>}>
        <Routes location={location} key={location.pathname}>
          <Route path="/" element={<AnimatedRoute><Splash /></AnimatedRoute>} />
          <Route path="/home" element={<AnimatedRoute><Index /></AnimatedRoute>} />
          <Route path="/battles" element={<AnimatedRoute><Battles /></AnimatedRoute>} />
          <Route path="/battle/:id" element={<AnimatedRoute><BattleView /></AnimatedRoute>} />
          <Route path="/leaderboard" element={<AnimatedRoute><Leaderboard /></AnimatedRoute>} />
          <Route path="/auth" element={<AnimatedRoute><Auth /></AnimatedRoute>} />
          <Route path="/character-creation" element={<AnimatedRoute><CharacterCreation /></AnimatedRoute>} />
          <Route path="/profile/:userId" element={<AnimatedRoute><Profile /></AnimatedRoute>} />
          <Route path="/profile" element={<AnimatedRoute><Profile /></AnimatedRoute>} />
          <Route path="/store" element={<AnimatedRoute><Store /></AnimatedRoute>} />
          <Route path="/community" element={<AnimatedRoute><Community /></AnimatedRoute>} />
          <Route path="/inbox" element={<AnimatedRoute><Inbox /></AnimatedRoute>} />
          {/* ADD ALL CUSTOM ROUTES ABOVE THE CATCH-ALL "*" ROUTE */}
          <Route path="*" element={<AnimatedRoute><NotFound /></AnimatedRoute>} />
        </Routes>
      </Suspense>
    </AnimatePresence>
  );
};

const App = () => (
  <QueryClientProvider client={queryClient}>
    <TooltipProvider>
      <Toaster />
      <Sonner />
      <BrowserRouter>
        <AnimatedRoutes />
        <GlobalChat />
        <SlotMachine />
      </BrowserRouter>
    </TooltipProvider>
  </QueryClientProvider>
);

export default App;
