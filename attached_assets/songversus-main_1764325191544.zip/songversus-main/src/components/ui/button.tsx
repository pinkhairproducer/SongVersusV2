import * as React from "react";
import { Slot } from "@radix-ui/react-slot";
import { cva, type VariantProps } from "class-variance-authority";

import { cn } from "@/lib/utils";

const buttonVariants = cva(
  "inline-flex items-center justify-center gap-2 whitespace-nowrap rounded text-sm font-bold font-mono ring-offset-background transition-all focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring focus-visible:ring-offset-2 disabled:pointer-events-none disabled:opacity-50 [&_svg]:pointer-events-none [&_svg]:size-4 [&_svg]:shrink-0 uppercase tracking-wider",
  {
    variants: {
      variant: {
        default: "bg-acid-lime text-deep-void border-4 border-black shadow-hard hover:translate-x-1 hover:translate-y-1 hover:shadow-none",
        destructive: "bg-punk-pink text-white border-4 border-black shadow-hard hover:translate-x-1 hover:translate-y-1 hover:shadow-none",
        outline: "border-4 border-black bg-white hover:bg-acid-lime hover:text-deep-void shadow-hard-sm",
        secondary: "bg-deep-void text-white border-4 border-acid-lime hover:bg-acid-lime hover:text-deep-void",
        ghost: "hover:bg-deep-void/10 hover:text-deep-void border-2 border-transparent hover:border-black",
        link: "text-deep-void underline-offset-4 hover:underline",
        battle: "bg-gradient-to-r from-acid-lime to-punk-pink text-deep-void font-display border-4 border-black shadow-hard-pink hover:shadow-hard-lime hover:scale-105",
        victory: "bg-electric-blue text-deep-void border-4 border-black shadow-hard hover:animate-shake",
        sticker: "rounded-full bg-punk-pink text-white border-4 border-black shadow-hard hover:animate-float",
      },
      size: {
        default: "h-10 px-4 py-2",
        sm: "h-9 px-3 text-xs",
        lg: "h-12 px-8 text-base",
        xl: "h-14 px-10 text-lg",
        icon: "h-10 w-10",
      },
    },
    defaultVariants: {
      variant: "default",
      size: "default",
    },
  },
);

export interface ButtonProps
  extends React.ButtonHTMLAttributes<HTMLButtonElement>,
    VariantProps<typeof buttonVariants> {
  asChild?: boolean;
}

const Button = React.forwardRef<HTMLButtonElement, ButtonProps>(
  ({ className, variant, size, asChild = false, ...props }, ref) => {
    const Comp = asChild ? Slot : "button";
    return <Comp className={cn(buttonVariants({ variant, size, className }))} ref={ref} {...props} />;
  },
);
Button.displayName = "Button";

export { Button, buttonVariants };