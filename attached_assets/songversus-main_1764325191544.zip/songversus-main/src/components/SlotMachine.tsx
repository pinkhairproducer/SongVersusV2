import { useState, useEffect } from "react";
import { Button } from "@/components/ui/button";
import { supabase } from "@/integrations/supabase/client";
import { useToast } from "@/hooks/use-toast";
import { motion, AnimatePresence } from "framer-motion";
import { Coins, X, Minimize2, Maximize2 } from "lucide-react";

const SYMBOLS = ["🍒", "🍋", "🍊", "🍇", "💎", "7️⃣"];
const SPIN_COST = 10;

interface SlotMachineProps {}

export const SlotMachine = ({}: SlotMachineProps) => {
  const [isOpen, setIsOpen] = useState(false);
  const [isMinimized, setIsMinimized] = useState(true);
  const [isSpinning, setIsSpinning] = useState(false);
  const [reels, setReels] = useState([SYMBOLS[0], SYMBOLS[0], SYMBOLS[0]]);
  const [coins, setCoins] = useState(0);
  const [userId, setUserId] = useState<string | null>(null);
  const [hasFreeSpin, setHasFreeSpin] = useState(false);
  const { toast } = useToast();

  useEffect(() => {
    const getUser = async () => {
      const { data: { user } } = await supabase.auth.getUser();
      if (user) {
        setUserId(user.id);
        fetchCoins(user.id);
        checkFreeSpin(user.id);
      }
    };
    getUser();
  }, []);

  const fetchCoins = async (uid: string) => {
    const { data } = await supabase
      .from("profiles")
      .select("coins")
      .eq("user_id", uid)
      .single();
    
    if (data) {
      setCoins(data.coins);
    }
  };

  const checkFreeSpin = async (uid: string) => {
    const { data } = await supabase
      .from("daily_spins")
      .select("*")
      .eq("user_id", uid)
      .eq("spin_date", new Date().toISOString().split('T')[0])
      .maybeSingle();
    
    setHasFreeSpin(!data);
  };

  const useFreeSpin = async () => {
    if (!userId) return false;

    const { data, error } = await supabase.rpc("use_daily_free_spin");

    if (error || !(data as any)?.success) {
      toast({
        title: "Error",
        description: (data as any)?.message || "Failed to use free spin",
        variant: "destructive",
      });
      return false;
    }

    setHasFreeSpin(false);
    return true;
  };

  const spin = async (isFree = false) => {
    if (!userId) {
      toast({
        title: "Not logged in",
        description: "You need to be logged in to play!",
        variant: "destructive",
      });
      return;
    }

    if (!isFree && coins < SPIN_COST) {
      toast({
        title: "Not enough coins",
        description: `You need ${SPIN_COST} coins to spin!`,
        variant: "destructive",
      });
      return;
    }

    setIsSpinning(true);

    // Handle free spin or paid spin
    if (isFree) {
      const success = await useFreeSpin();
      if (!success) {
        setIsSpinning(false);
        return;
      }
    } else {
      // Deduct coins for paid spin
      const { error: deductError } = await supabase.rpc("deduct_coins", {
        p_amount: SPIN_COST,
        p_user_id: userId,
      });

      if (deductError) {
        toast({
          title: "Error",
          description: "Failed to deduct coins",
          variant: "destructive",
        });
        setIsSpinning(false);
        return;
      }
    }

    // Animate spinning
    const spinDuration = 2000;
    const interval = setInterval(() => {
      setReels([
        SYMBOLS[Math.floor(Math.random() * SYMBOLS.length)],
        SYMBOLS[Math.floor(Math.random() * SYMBOLS.length)],
        SYMBOLS[Math.floor(Math.random() * SYMBOLS.length)],
      ]);
    }, 100);

    // Stop spinning and determine result
    setTimeout(async () => {
      clearInterval(interval);
      
      const finalReels = [
        SYMBOLS[Math.floor(Math.random() * SYMBOLS.length)],
        SYMBOLS[Math.floor(Math.random() * SYMBOLS.length)],
        SYMBOLS[Math.floor(Math.random() * SYMBOLS.length)],
      ];
      
      setReels(finalReels);
      setIsSpinning(false);

      // Check for wins
      let winAmount = 0;
      if (finalReels[0] === finalReels[1] && finalReels[1] === finalReels[2]) {
        // All three match
        if (finalReels[0] === "7️⃣") winAmount = 100;
        else if (finalReels[0] === "💎") winAmount = 50;
        else winAmount = 30;
      } else if (finalReels[0] === finalReels[1] || finalReels[1] === finalReels[2] || finalReels[0] === finalReels[2]) {
        // Two match
        winAmount = 15;
      }

      if (winAmount > 0) {
        await supabase.rpc("add_coins", {
          p_amount: winAmount,
          p_user_id: userId,
        });

        toast({
          title: "🎉 YOU WIN!",
          description: `You won ${winAmount} coins!`,
        });
      } else {
        toast({
          title: "Better luck next time!",
          description: "No match this time.",
        });
      }

      await fetchCoins(userId);
    }, spinDuration);
  };

  if (!isOpen) {
    return (
      <motion.div
        initial={{ scale: 0 }}
        animate={{ scale: 1 }}
        className="fixed bottom-4 left-4 z-50"
      >
        <Button
          onClick={() => setIsOpen(true)}
          variant="battle"
          size="icon"
          className="h-14 w-14 rounded-full shadow-hard-pink"
        >
          <Coins className="h-6 w-6" />
        </Button>
      </motion.div>
    );
  }

  return (
    <AnimatePresence>
      <motion.div
        initial={{ x: -300, opacity: 0 }}
        animate={{ x: 0, opacity: 1 }}
        exit={{ x: -300, opacity: 0 }}
        className="fixed bottom-4 left-4 z-50"
      >
        <div className="bg-deep-void border-4 border-acid-lime shadow-hard-lime rounded-lg overflow-hidden">
          {/* Header */}
          <div className="bg-acid-lime text-deep-void p-3 flex items-center justify-between">
            <div className="flex items-center gap-2">
              <Coins className="h-5 w-5" />
              <span className="font-display text-lg font-bold">SLOT MACHINE</span>
            </div>
            <div className="flex gap-1">
              <Button
                size="icon"
                variant="ghost"
                className="h-8 w-8"
                onClick={() => setIsMinimized(!isMinimized)}
              >
                {isMinimized ? <Maximize2 className="h-4 w-4" /> : <Minimize2 className="h-4 w-4" />}
              </Button>
              <Button
                size="icon"
                variant="ghost"
                className="h-8 w-8"
                onClick={() => setIsOpen(false)}
              >
                <X className="h-4 w-4" />
              </Button>
            </div>
          </div>

          {/* Content */}
          {!isMinimized && (
            <div className="p-4 w-80">
              {/* Coins Display */}
              <div className="bg-electric-blue/20 border-2 border-electric-blue rounded p-2 mb-4 text-center">
                <span className="text-white font-mono text-sm">YOUR COINS:</span>
                <div className="text-acid-lime font-display text-2xl font-bold">{coins}</div>
              </div>

              {/* Reels */}
              <div className="flex justify-center gap-2 mb-4">
                {reels.map((symbol, index) => (
                  <motion.div
                    key={index}
                    animate={isSpinning ? { y: [0, -20, 0] } : {}}
                    transition={{ repeat: isSpinning ? Infinity : 0, duration: 0.1 }}
                    className="bg-white border-4 border-black w-20 h-20 flex items-center justify-center text-4xl rounded shadow-hard"
                  >
                    {symbol}
                  </motion.div>
                ))}
              </div>

              {/* Free Spin Button */}
              {hasFreeSpin && (
                <Button
                  onClick={() => spin(true)}
                  disabled={isSpinning}
                  variant="victory"
                  size="lg"
                  className="w-full mb-2"
                >
                  {isSpinning ? "SPINNING..." : "🎁 FREE DAILY SPIN"}
                </Button>
              )}

              {/* Paid Spin Button */}
              <Button
                onClick={() => spin(false)}
                disabled={isSpinning || coins < SPIN_COST}
                variant="battle"
                size="lg"
                className="w-full"
              >
                {isSpinning ? "SPINNING..." : `SPIN (${SPIN_COST} COINS)`}
              </Button>

              {/* Payout Info */}
              <div className="mt-4 text-xs text-white/70 font-mono space-y-1">
                <div>3x 7️⃣ = 100 coins</div>
                <div>3x 💎 = 50 coins</div>
                <div>3x any = 30 coins</div>
                <div>2x match = 15 coins</div>
              </div>
            </div>
          )}
        </div>
      </motion.div>
    </AnimatePresence>
  );
};
