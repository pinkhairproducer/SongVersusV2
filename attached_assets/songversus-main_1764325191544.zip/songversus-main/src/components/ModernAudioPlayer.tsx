import { useEffect, useRef, useState } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { Play, Pause } from 'lucide-react';
import { Button } from './ui/button';
import { Slider } from './ui/slider';

interface ModernAudioPlayerProps {
  audioUrl: string;
  color?: 'primary' | 'secondary';
  onPlay?: () => void;
  onPause?: () => void;
  onEnded?: () => void;
}

export const ModernAudioPlayer = ({ 
  audioUrl, 
  color = 'primary',
  onPlay,
  onPause,
  onEnded
}: ModernAudioPlayerProps) => {
  const canvasRef = useRef<HTMLCanvasElement>(null);
  const audioRef = useRef<HTMLAudioElement>(null);
  
  const [isPlaying, setIsPlaying] = useState(false);
  const [currentTime, setCurrentTime] = useState(0);
  const [duration, setDuration] = useState(0);
  const [isReady, setIsReady] = useState(true);
  const [volume, setVolume] = useState(0.8);

  const colorClasses = {
    primary: {
      button: 'bg-primary hover:bg-primary/90 text-primary-foreground',
      gradient: 'from-primary to-primary-glow',
      glow: 'shadow-[0_0_30px_hsl(var(--primary)/0.6)]'
    },
    secondary: {
      button: 'bg-secondary hover:bg-secondary/90 text-secondary-foreground',
      gradient: 'from-secondary to-secondary-glow',
      glow: 'shadow-[0_0_30px_hsl(var(--secondary)/0.6)]'
    }
  };

  const theme = colorClasses[color];

  useEffect(() => {
    if (!audioRef.current || !canvasRef.current) return;

    const audio = audioRef.current;
    const canvas = canvasRef.current;
    const ctx = canvas.getContext('2d');
    
    if (!ctx) return;

    // Set canvas size for crisp rendering
    canvas.width = canvas.offsetWidth * 2; // 2x for retina
    canvas.height = canvas.offsetHeight * 2;
    ctx.scale(2, 2);

    // Ensure initial volume
    audio.volume = volume;

    const handleLoadedMetadata = () => {
      setDuration(audio.duration || 0);
      setIsReady(true);
    };

    const handleTimeUpdate = () => {
      setCurrentTime(audio.currentTime || 0);
    };

    audio.addEventListener('loadedmetadata', handleLoadedMetadata);
    audio.addEventListener('timeupdate', handleTimeUpdate);

    // If metadata already loaded, set up immediately
    if (audio.readyState >= 1) {
      handleLoadedMetadata();
    }

    return () => {
      audio.removeEventListener('loadedmetadata', handleLoadedMetadata);
      audio.removeEventListener('timeupdate', handleTimeUpdate);
    };
  }, [audioUrl, volume]);

  const draw = () => {
    // Placeholder for future waveform sync; currently visual only
  };

  const togglePlayPause = async () => {
    if (!audioRef.current) return;

    try {
      if (isPlaying) {
        audioRef.current.pause();
        setIsPlaying(false);
        onPause?.();
      } else {
        await audioRef.current.play();
        setIsPlaying(true);
        onPlay?.();
      }
    } catch (error) {
      console.error('Playback error:', error);
    }
  };

  const handleSeek = (e: React.MouseEvent<HTMLDivElement>) => {
    if (!audioRef.current) return;
    
    const rect = e.currentTarget.getBoundingClientRect();
    const x = e.clientX - rect.left;
    const percentage = x / rect.width;
    audioRef.current.currentTime = percentage * duration;
  };

  const formatTime = (time: number) => {
    const minutes = Math.floor(time / 60);
    const seconds = Math.floor(time % 60);
    return `${minutes}:${seconds.toString().padStart(2, '0')}`;
  };

  const handleEnded = () => {
    setIsPlaying(false);
    onEnded?.();
  };

  const handleVolumeChange = (value: number[]) => {
    const newVolume = value[0];
    setVolume(newVolume);
    if (audioRef.current) {
      audioRef.current.volume = newVolume;
    }
  };

  return (
    <div className="relative w-full space-y-3">
      <audio
        ref={audioRef}
        src={audioUrl}
        onEnded={handleEnded}
        preload="metadata"
        className="hidden"
      />
      
      {/* Waveform Canvas */}
      <div className="relative h-32 bg-muted/30 rounded-lg overflow-hidden backdrop-blur-sm border border-border/50">
        <canvas
          ref={canvasRef}
          className="absolute inset-0 w-full h-full"
        />
        
        {/* Static waveform when not playing */}
        {!isPlaying && isReady && (
          <div className="absolute inset-0 flex items-end justify-center gap-[2px] px-4 pb-4">
            {[...Array(40)].map((_, i) => (
              <motion.div
                key={i}
                className={`w-1.5 rounded-full bg-gradient-to-t ${theme.gradient}`}
                initial={{ height: '20%' }}
                animate={{
                  height: [`${20 + Math.random() * 30}%`, `${30 + Math.random() * 50}%`, `${20 + Math.random() * 30}%`],
                  opacity: [0.4, 0.7, 0.4],
                }}
                transition={{
                  duration: 2 + Math.random(),
                  repeat: Infinity,
                  delay: i * 0.05,
                  ease: "easeInOut",
                }}
              />
            ))}
          </div>
        )}
      </div>

      {/* Controls */}
      <div className="flex flex-col gap-3">
        <div className="flex items-center gap-4">
          <Button
            onClick={togglePlayPause}
            disabled={!isReady}
            size="lg"
            className={`${theme.button} ${isPlaying ? theme.glow : ''} rounded-full w-14 h-14 p-0 transition-all duration-300`}
          >
            <AnimatePresence mode="wait">
              {isPlaying ? (
                <motion.div
                  key="pause"
                  initial={{ scale: 0, rotate: -180 }}
                  animate={{ scale: 1, rotate: 0 }}
                  exit={{ scale: 0, rotate: 180 }}
                  transition={{ duration: 0.2 }}
                >
                  <Pause className="h-6 w-6" fill="currentColor" />
                </motion.div>
              ) : (
                <motion.div
                  key="play"
                  initial={{ scale: 0, rotate: -180 }}
                  animate={{ scale: 1, rotate: 0 }}
                  exit={{ scale: 0, rotate: 180 }}
                  transition={{ duration: 0.2 }}
                >
                  <Play className="h-6 w-6 ml-0.5" fill="currentColor" />
                </motion.div>
              )}
            </AnimatePresence>
          </Button>

          {/* Progress Bar */}
          <div className="flex-1 space-y-1">
            <div
              className="h-2 bg-muted rounded-full overflow-hidden cursor-pointer group"
              onClick={handleSeek}
            >
              <motion.div
                className={`h-full bg-gradient-to-r ${theme.gradient} relative`}
                style={{ width: `${duration ? (currentTime / duration) * 100 : 0}%` }}
              >
                <motion.div
                  animate={{ x: ['0%', '100%'] }}
                  transition={{ duration: 1, repeat: Infinity, ease: "linear" }}
                  className="absolute inset-0 bg-gradient-to-r from-transparent via-white/30 to-transparent"
                />
              </motion.div>
            </div>
            <div className="flex justify-between text-xs text-muted-foreground">
              <span>{formatTime(currentTime)}</span>
              <span>{formatTime(duration)}</span>
            </div>
          </div>
        </div>

        {/* Volume Control */}
        <div className="flex items-center gap-3 text-xs text-muted-foreground">
          <span className="w-10">Vol</span>
          <Slider
            value={[volume]}
            min={0}
            max={1}
            step={0.01}
            className="flex-1"
            onValueChange={handleVolumeChange}
          />
          <span className="w-8 text-right">{Math.round(volume * 100)}%</span>
        </div>
      </div>
    </div>
  );
};
