import { useState } from "react";
import { supabase } from "@/integrations/supabase/client";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Upload, Loader2 } from "lucide-react";
import { toast } from "sonner";

interface AudioUploadProps {
  battleId: string;
  userId: string;
  isCreator: boolean;
  onUploadComplete: () => void;
}

export function AudioUpload({ battleId, userId, isCreator, onUploadComplete }: AudioUploadProps) {
  const [uploading, setUploading] = useState(false);

  const handleFileChange = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;

    // Validate file type
    if (!file.type.startsWith('audio/')) {
      toast.error("Please upload an audio file");
      return;
    }

    // Validate file size (max 50MB)
    if (file.size > 50 * 1024 * 1024) {
      toast.error("File too large. Maximum size is 50MB");
      return;
    }

    setUploading(true);
    try {
      // Create storage bucket path
      const fileExt = file.name.split('.').pop();
      const fileName = `${battleId}/${userId}/${Date.now()}.${fileExt}`;

      // Upload to storage
      const { error: uploadError } = await supabase.storage
        .from('battle-audio')
        .upload(fileName, file, {
          upsert: true,
        });

      if (uploadError) throw uploadError;

      // Get public URL
      const { data: { publicUrl } } = supabase.storage
        .from('battle-audio')
        .getPublicUrl(fileName);

      // Update battle record
      const updateField = isCreator ? 'creator_audio_url' : 'opponent_audio_url';
      const { error: updateError } = await supabase
        .from('battles')
        .update({ [updateField]: publicUrl })
        .eq('id', battleId);

      if (updateError) throw updateError;

      toast.success("Audio uploaded successfully!");
      onUploadComplete();
    } catch (error: any) {
      toast.error("Failed to upload audio", {
        description: error.message,
      });
    } finally {
      setUploading(false);
      // Reset input
      e.target.value = '';
    }
  };

  return (
    <div className="flex flex-col items-center justify-center h-full gap-3">
      <Upload className="h-8 w-8 text-primary" />
      <Label htmlFor={`audio-upload-${battleId}`} className="cursor-pointer">
        <Button
          variant="outline"
          size="sm"
          disabled={uploading}
          asChild
        >
          <span>
            {uploading ? (
              <>
                <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                Uploading...
              </>
            ) : (
              <>
                <Upload className="mr-2 h-4 w-4" />
                Upload Audio
              </>
            )}
          </span>
        </Button>
        <Input
          id={`audio-upload-${battleId}`}
          type="file"
          accept="audio/*"
          className="hidden"
          onChange={handleFileChange}
          disabled={uploading}
        />
      </Label>
      <p className="text-xs text-muted-foreground">Max 50MB • MP3, WAV, etc.</p>
    </div>
  );
}
