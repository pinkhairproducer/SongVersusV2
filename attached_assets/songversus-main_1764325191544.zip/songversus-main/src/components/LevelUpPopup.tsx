import { useEffect } from "react";
import { motion, AnimatePresence } from "framer-motion";
import { Dialog, DialogContent } from "@/components/ui/dialog";
import { Badge } from "@/components/ui/badge";
import { Trophy, Coins, Star, Sparkles, TrendingUp } from "lucide-react";
import confetti from "canvas-confetti";
import { Button } from "@/components/ui/button";

interface LevelUpPopupProps {
  open: boolean;
  onClose: () => void;
  oldLevel: number;
  newLevel: number;
  xpGained: number;
  coinsGained?: number;
  unlockedItems?: string[];
}

export function LevelUpPopup({
  open,
  onClose,
  oldLevel,
  newLevel,
  xpGained,
  coinsGained = 0,
  unlockedItems = []
}: LevelUpPopupProps) {
  
  useEffect(() => {
    if (open) {
      // Trigger confetti animation
      const duration = 3000;
      const end = Date.now() + duration;

      const colors = ['#ccff00', '#ff0066', '#00f3ff', '#ffd700'];
      
      (function frame() {
        confetti({
          particleCount: 3,
          angle: 60,
          spread: 55,
          origin: { x: 0 },
          colors: colors
        });
        confetti({
          particleCount: 3,
          angle: 120,
          spread: 55,
          origin: { x: 1 },
          colors: colors
        });

        if (Date.now() < end) {
          requestAnimationFrame(frame);
        }
      }());
    }
  }, [open]);

  return (
    <Dialog open={open} onOpenChange={onClose}>
      <DialogContent className="max-w-md overflow-hidden border-2 border-primary bg-background/95 backdrop-blur-lg">
        <AnimatePresence>
          {open && (
            <motion.div
              initial={{ scale: 0.8, opacity: 0 }}
              animate={{ scale: 1, opacity: 1 }}
              exit={{ scale: 0.8, opacity: 0 }}
              className="text-center space-y-6 py-6"
            >
              {/* Level Up Badge */}
              <motion.div
                initial={{ scale: 0, rotate: -180 }}
                animate={{ scale: 1, rotate: 0 }}
                transition={{ delay: 0.2, type: "spring", stiffness: 200 }}
                className="flex justify-center"
              >
                <div className="relative">
                  <motion.div
                    animate={{ 
                      scale: [1, 1.2, 1],
                      rotate: [0, 5, -5, 0]
                    }}
                    transition={{ 
                      repeat: Infinity, 
                      duration: 2,
                      ease: "easeInOut"
                    }}
                    className="w-32 h-32 rounded-full bg-gradient-to-br from-primary via-yellow-500 to-primary flex items-center justify-center"
                  >
                    <Trophy className="h-16 w-16 text-white" />
                  </motion.div>
                  <motion.div
                    initial={{ scale: 0 }}
                    animate={{ scale: 1 }}
                    transition={{ delay: 0.4 }}
                    className="absolute -top-2 -right-2"
                  >
                    <Badge className="text-lg px-3 py-1 bg-yellow-500 text-black font-bold">
                      +{newLevel - oldLevel}
                    </Badge>
                  </motion.div>
                </div>
              </motion.div>

              {/* Title */}
              <motion.div
                initial={{ y: 20, opacity: 0 }}
                animate={{ y: 0, opacity: 1 }}
                transition={{ delay: 0.3 }}
              >
                <h2 className="text-4xl font-bold mb-2 bg-gradient-to-r from-primary via-yellow-500 to-primary bg-clip-text text-transparent animate-pulse">
                  LEVEL UP!
                </h2>
                <p className="text-xl text-foreground/80">
                  Level {oldLevel} → <span className="text-primary font-bold">{newLevel}</span>
                </p>
              </motion.div>

              {/* Rewards Section */}
              <motion.div
                initial={{ y: 20, opacity: 0 }}
                animate={{ y: 0, opacity: 1 }}
                transition={{ delay: 0.5 }}
                className="space-y-4"
              >
                {/* XP Gained */}
                <div className="flex items-center justify-center gap-3 p-4 bg-primary/10 rounded-lg border border-primary/20">
                  <Star className="h-6 w-6 text-yellow-500" />
                  <div className="text-left">
                    <p className="text-sm text-muted-foreground">XP Gained</p>
                    <p className="text-2xl font-bold text-primary">+{xpGained}</p>
                  </div>
                </div>

                {/* Coins Gained */}
                {coinsGained > 0 && (
                  <div className="flex items-center justify-center gap-3 p-4 bg-yellow-500/10 rounded-lg border border-yellow-500/20">
                    <Coins className="h-6 w-6 text-yellow-500" />
                    <div className="text-left">
                      <p className="text-sm text-muted-foreground">Coins Earned</p>
                      <p className="text-2xl font-bold text-yellow-500">+{coinsGained}</p>
                    </div>
                  </div>
                )}

                {/* Unlocked Items */}
                {unlockedItems.length > 0 && (
                  <div className="p-4 bg-purple-500/10 rounded-lg border border-purple-500/20">
                    <div className="flex items-center gap-2 mb-3">
                      <Sparkles className="h-5 w-5 text-purple-500" />
                      <p className="font-bold text-purple-500">New Items Unlocked!</p>
                    </div>
                    <div className="space-y-2">
                      {unlockedItems.map((item, i) => (
                        <motion.div
                          key={i}
                          initial={{ x: -20, opacity: 0 }}
                          animate={{ x: 0, opacity: 1 }}
                          transition={{ delay: 0.6 + i * 0.1 }}
                          className="flex items-center gap-2 text-sm"
                        >
                          <TrendingUp className="h-4 w-4 text-purple-400" />
                          <span className="text-foreground/80">{item}</span>
                        </motion.div>
                      ))}
                    </div>
                  </div>
                )}
              </motion.div>

              {/* Close Button */}
              <motion.div
                initial={{ y: 20, opacity: 0 }}
                animate={{ y: 0, opacity: 1 }}
                transition={{ delay: 0.7 }}
              >
                <Button
                  onClick={onClose}
                  size="lg"
                  className="w-full bg-gradient-to-r from-primary to-yellow-500 hover:from-primary/90 hover:to-yellow-500/90 font-bold"
                >
                  Awesome! 🎉
                </Button>
              </motion.div>
            </motion.div>
          )}
        </AnimatePresence>
      </DialogContent>
    </Dialog>
  );
}
