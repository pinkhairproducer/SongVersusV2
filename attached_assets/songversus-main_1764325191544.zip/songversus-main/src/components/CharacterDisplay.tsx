import { useQuery } from "@tanstack/react-query";
import { supabase } from "@/integrations/supabase/client";
import { Skeleton } from "@/components/ui/skeleton";
import defaultCharacter from "@/assets/default-character.png";

interface CharacterDisplayProps {
  userId?: string;
  size?: "sm" | "md" | "lg";
  className?: string;
  previewItems?: any[]; // For character creation preview
}

export const CharacterDisplay = ({ userId, size = "md", className = "", previewItems }: CharacterDisplayProps) => {
  const { data: equippedItems, isLoading } = useQuery({
    queryKey: ['character', userId],
    queryFn: async () => {
      if (!userId) return [];
      const { data, error } = await supabase
        .from('user_customizations')
        .select(`
          *,
          customization_items (
            id,
            name,
            category,
            image_url,
            rarity
          )
        `)
        .eq('user_id', userId)
        .eq('is_equipped', true);
      
      if (error) throw error;
      return data;
    },
    enabled: !!userId && !previewItems
  });

  // Use preview items if provided, otherwise use queried items
  const items = previewItems || equippedItems;

  const sizeClasses = {
    sm: "w-24 h-24",
    md: "w-48 h-48",
    lg: "w-64 h-64"
  };

  if (isLoading && !previewItems) {
    return <Skeleton className={`${sizeClasses[size]} rounded-lg ${className}`} />;
  }

  // Get equipped items by category in proper layering order
  const skin = items?.find((item: any) => item.customization_items?.category === 'skin' || item.category === 'skin');
  const outfit = items?.find((item: any) => item.customization_items?.category === 'outfit' || item.category === 'outfit');
  const eyes = items?.find((item: any) => item.customization_items?.category === 'eyes' || item.category === 'eyes');
  const hair = items?.find((item: any) => item.customization_items?.category === 'hair' || item.category === 'hair');
  const accessory = items?.find((item: any) => item.customization_items?.category === 'accessory' || item.category === 'accessory');
  const effect = items?.find((item: any) => item.customization_items?.category === 'effect' || item.category === 'effect');

  // Determine if we have a character
  const hasCharacter = skin || outfit || eyes || hair;
  
  console.log("CharacterDisplay - items:", items);
  console.log("CharacterDisplay - hasCharacter:", hasCharacter);
  console.log("CharacterDisplay - layers:", { skin, outfit, eyes, hair, accessory, effect });
  
  // Get highest rarity for glow effect
  const highestRarity = items?.reduce((highest: string, item: any) => {
    const rarity = item.customization_items?.rarity || item.rarity;
    if (rarity === 'legendary') return 'legendary';
    if (rarity === 'epic' && highest !== 'legendary') return 'epic';
    if (rarity === 'rare' && highest !== 'legendary' && highest !== 'epic') return 'rare';
    return highest;
  }, 'common');

  return (
    <div className={`${sizeClasses[size]} relative rounded-lg overflow-hidden ${className}`}>
      {/* Default Background */}
      <div className="absolute inset-0 bg-gradient-to-b from-transparent to-transparent" />
      
      {/* Base Character (always shown) */}
      <img 
        src={defaultCharacter} 
        alt="Character Base"
        className="absolute inset-0 w-full h-full object-contain z-5"
      />
      
      {/* Skin Layer */}
      {(skin?.customization_items?.image_url || skin?.image_url) && (
        <img 
          src={skin.customization_items?.image_url || skin.image_url} 
          alt="Skin"
          className="absolute inset-0 w-full h-full object-contain z-10"
        />
      )}
      
      {/* Outfit Layer */}
      {(outfit?.customization_items?.image_url || outfit?.image_url) && (
        <img 
          src={outfit.customization_items?.image_url || outfit.image_url} 
          alt="Outfit"
          className="absolute inset-0 w-full h-full object-contain z-20"
        />
      )}
      
      {/* Eyes Layer */}
      {(eyes?.customization_items?.image_url || eyes?.image_url) && (
        <img 
          src={eyes.customization_items?.image_url || eyes.image_url} 
          alt="Eyes"
          className="absolute inset-0 w-full h-full object-contain z-30"
        />
      )}
      
      {/* Hair Layer */}
      {(hair?.customization_items?.image_url || hair?.image_url) && (
        <img 
          src={hair.customization_items?.image_url || hair.image_url} 
          alt="Hair"
          className="absolute inset-0 w-full h-full object-contain z-40"
        />
      )}
      
      {/* Accessory Layer */}
      {(accessory?.customization_items?.image_url || accessory?.image_url) && (
        <img 
          src={accessory.customization_items?.image_url || accessory.image_url} 
          alt="Accessory"
          className="absolute inset-0 w-full h-full object-contain z-50"
        />
      )}
      
      {/* Effect Layer (on top) */}
      {(effect?.customization_items?.image_url || effect?.image_url) && (
        <img 
          src={effect.customization_items?.image_url || effect.image_url} 
          alt="Effect"
          className="absolute inset-0 w-full h-full object-contain z-60"
        />
      )}
      
      {/* Rarity Glow Effect */}
      {highestRarity && highestRarity !== 'common' && (
        <div className={`absolute inset-0 pointer-events-none z-70 rounded-lg
          ${highestRarity === 'rare' ? 'shadow-[0_0_30px_rgba(59,130,246,0.6)]' : ''}
          ${highestRarity === 'epic' ? 'shadow-[0_0_30px_rgba(168,85,247,0.6)]' : ''}
          ${highestRarity === 'legendary' ? 'shadow-[0_0_30px_rgba(234,179,8,0.6)] animate-pulse' : ''}
        `} />
      )}
    </div>
  );
};
