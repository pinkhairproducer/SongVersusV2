import { useRef, useMemo } from 'react';
import { Canvas, useFrame } from '@react-three/fiber';
import * as THREE from 'three';

interface ParticlesProps {
  intensity: number;
  color: string;
  direction: number;
}

function Particles({ intensity, color, direction }: ParticlesProps) {
  const particlesRef = useRef<THREE.Points>(null);
  const count = Math.floor(100 * intensity);

  const particles = useMemo(() => {
    const positions = new Float32Array(count * 3);
    const velocities = new Float32Array(count * 3);
    
    for (let i = 0; i < count; i++) {
      positions[i * 3] = (Math.random() - 0.5) * 3;
      positions[i * 3 + 1] = (Math.random() - 0.5) * 2;
      positions[i * 3 + 2] = (Math.random() - 0.5) * 0.5;
      
      velocities[i * 3] = (Math.random() - 0.5) * 0.02 * direction;
      velocities[i * 3 + 1] = (Math.random() - 0.5) * 0.02;
      velocities[i * 3 + 2] = (Math.random() - 0.5) * 0.01;
    }
    
    return { positions, velocities };
  }, [count, direction]);

  useFrame(() => {
    if (!particlesRef.current) return;
    
    const positions = particlesRef.current.geometry.attributes.position.array as Float32Array;
    
    for (let i = 0; i < count; i++) {
      positions[i * 3] += particles.velocities[i * 3];
      positions[i * 3 + 1] += particles.velocities[i * 3 + 1];
      positions[i * 3 + 2] += particles.velocities[i * 3 + 2];
      
      // Reset particles that go too far
      if (Math.abs(positions[i * 3]) > 2) {
        positions[i * 3] = (Math.random() - 0.5) * 3;
      }
      if (Math.abs(positions[i * 3 + 1]) > 1.5) {
        positions[i * 3 + 1] = (Math.random() - 0.5) * 2;
      }
    }
    
    particlesRef.current.geometry.attributes.position.needsUpdate = true;
  });

  return (
    <points ref={particlesRef}>
      <bufferGeometry>
        <bufferAttribute
          attach="attributes-position"
          count={count}
          array={particles.positions}
          itemSize={3}
        />
      </bufferGeometry>
      <pointsMaterial
        size={0.05}
        color={color}
        transparent
        opacity={0.6 + intensity * 0.4}
        sizeAttenuation
        blending={THREE.AdditiveBlending}
      />
    </points>
  );
}

function EnergyBeam({ intensity, fromColor, toColor }: { intensity: number; fromColor: string; toColor: string }) {
  const beamRef = useRef<THREE.Mesh>(null);
  
  useFrame((state) => {
    if (!beamRef.current) return;
    
    const scale = 1 + Math.sin(state.clock.elapsedTime * 3) * 0.1 * intensity;
    beamRef.current.scale.set(scale, scale, 1);
    
    const material = beamRef.current.material as THREE.MeshBasicMaterial;
    material.opacity = 0.2 + intensity * 0.3;
  });

  return (
    <mesh ref={beamRef} position={[0, 0, 0]}>
      <cylinderGeometry args={[0.02 * intensity, 0.02 * intensity, 5, 16]} />
      <meshBasicMaterial
        color={fromColor}
        transparent
        opacity={0.3}
        blending={THREE.AdditiveBlending}
      />
    </mesh>
  );
}

function Lightning({ intensity, color }: { intensity: number; color: string }) {
  const lineRef = useRef<THREE.Line>(null);
  
  const points = useMemo(() => {
    const pts = [];
    const segments = 20;
    
    for (let i = 0; i <= segments; i++) {
      const x = (i / segments - 0.5) * 5;
      const y = (Math.random() - 0.5) * 0.3 * intensity;
      const z = (Math.random() - 0.5) * 0.2 * intensity;
      pts.push(new THREE.Vector3(x, y, z));
    }
    
    return pts;
  }, [intensity]);

  useFrame(() => {
    if (!lineRef.current) return;
    
    const positions = lineRef.current.geometry.attributes.position.array as Float32Array;
    
    for (let i = 1; i < points.length - 1; i++) {
      positions[i * 3 + 1] += (Math.random() - 0.5) * 0.05 * intensity;
      positions[i * 3 + 2] += (Math.random() - 0.5) * 0.03 * intensity;
    }
    
    lineRef.current.geometry.attributes.position.needsUpdate = true;
  });

  return (
    <primitive object={new THREE.Line(
      (() => {
        const geometry = new THREE.BufferGeometry();
        geometry.setAttribute(
          'position',
          new THREE.BufferAttribute(
            new Float32Array(points.flatMap(p => [p.x, p.y, p.z])),
            3
          )
        );
        return geometry;
      })(),
      new THREE.LineBasicMaterial({
        color: new THREE.Color(color),
        transparent: true,
        opacity: 0.4 + intensity * 0.4,
        blending: THREE.AdditiveBlending,
      })
    )} ref={lineRef} />
  );
}

interface BattleEnergyEffectsProps {
  creatorVotePercentage: number;
  opponentVotePercentage: number;
  totalVotes: number;
}

export function BattleEnergyEffects({ creatorVotePercentage, opponentVotePercentage, totalVotes }: BattleEnergyEffectsProps) {
  const intensity = Math.min(totalVotes / 50, 1); // Max intensity at 50 votes
  const creatorIntensity = (creatorVotePercentage / 100) * intensity;
  const opponentIntensity = (opponentVotePercentage / 100) * intensity;
  
  return (
    <div className="absolute inset-0 pointer-events-none z-0">
      <Canvas camera={{ position: [0, 0, 3], fov: 50 }}>
        <ambientLight intensity={0.5} />
        
        {/* Energy beam in the center */}
        <group rotation={[0, 0, Math.PI / 2]}>
          <EnergyBeam 
            intensity={intensity} 
            fromColor="#8b5cf6" 
            toColor="#ec4899" 
          />
        </group>
        
        {/* Lightning effects */}
        {intensity > 0.2 && (
          <>
            <group rotation={[0, 0, Math.PI / 2]}>
              <Lightning intensity={intensity} color="#8b5cf6" />
            </group>
            <group rotation={[0, 0, Math.PI / 2]} position={[0, 0.3, 0]}>
              <Lightning intensity={intensity * 0.7} color="#ec4899" />
            </group>
          </>
        )}
        
        {/* Particles flowing from left to right (creator side) */}
        <Particles 
          intensity={creatorIntensity} 
          color="#8b5cf6" 
          direction={1}
        />
        
        {/* Particles flowing from right to left (opponent side) */}
        <Particles 
          intensity={opponentIntensity} 
          color="#ec4899" 
          direction={-1}
        />
        
        {/* Ambient glow spheres */}
        <mesh position={[-2, 0, 0]}>
          <sphereGeometry args={[0.3 + creatorIntensity * 0.2, 16, 16]} />
          <meshBasicMaterial
            color="#8b5cf6"
            transparent
            opacity={0.3 + creatorIntensity * 0.3}
            blending={THREE.AdditiveBlending}
          />
        </mesh>
        
        <mesh position={[2, 0, 0]}>
          <sphereGeometry args={[0.3 + opponentIntensity * 0.2, 16, 16]} />
          <meshBasicMaterial
            color="#ec4899"
            transparent
            opacity={0.3 + opponentIntensity * 0.3}
            blending={THREE.AdditiveBlending}
          />
        </mesh>
      </Canvas>
    </div>
  );
}