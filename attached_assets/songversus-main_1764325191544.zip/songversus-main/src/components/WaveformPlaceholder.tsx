import { Music, Upload } from "lucide-react";
import { motion } from "framer-motion";
import { AudioWaveform } from "./AudioWaveform";

interface WaveformPlaceholderProps {
  hasAudio: boolean;
  canPlay: boolean;
  audioUrl?: string | null;
  isCreator?: boolean;
  hasOpponent?: boolean;
  showUploadPrompt?: boolean;
  color?: string;
}

export const WaveformPlaceholder = ({ 
  hasAudio, 
  canPlay, 
  audioUrl, 
  isCreator = false,
  hasOpponent = false,
  showUploadPrompt = false,
  color = "#8b5cf6"
}: WaveformPlaceholderProps) => {
  // No audio uploaded yet
  if (!hasAudio) {
    if (showUploadPrompt) {
      return (
        <div className="flex flex-col items-center justify-center h-full gap-2">
          <Upload className="h-6 w-6 text-primary" />
          <p className="text-sm text-muted-foreground">Upload your audio to start</p>
        </div>
      );
    }
    
    if (!hasOpponent) {
      return (
        <div className="flex items-center justify-center h-full">
          <p className="text-sm text-muted-foreground">Waiting for opponent to join</p>
        </div>
      );
    }
    
    return (
      <div className="flex items-center justify-center h-full">
        <p className="text-sm text-muted-foreground">Waiting for audio upload</p>
      </div>
    );
  }

  // Audio uploaded - show waveform visualization
  return <AudioWaveform audioUrl={audioUrl || ''} color={color} />;
};
