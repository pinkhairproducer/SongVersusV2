import { useEffect, useState } from "react";
import { Button } from "@/components/ui/button";
import { Music, Swords, Trophy, User as UserIcon, ShoppingBag, Users, Coins, Gift, Settings, LogOut, Inbox, Menu, X } from "lucide-react";
import { Link, useNavigate } from "react-router-dom";
import { supabase, User } from "@/lib/supabase";
import { toast } from "sonner";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { Badge } from "@/components/ui/badge";
import { Sheet, SheetContent, SheetTrigger } from "@/components/ui/sheet";
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuLabel,
  DropdownMenuSeparator,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu";


export const Header = () => {
  const navigate = useNavigate();
  const queryClient = useQueryClient();
  const [user, setUser] = useState<User | null>(null);
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);

  useEffect(() => {
    supabase.auth.getSession().then(({ data: { session } }) => {
      setUser(session?.user ?? null);
    });

    const { data: { subscription } } = supabase.auth.onAuthStateChange((event, session) => {
      setUser(session?.user ?? null);
    });

    return () => subscription.unsubscribe();
  }, []);

  // Fetch user's coin balance
  const { data: profile } = useQuery({
    queryKey: ['profile', user?.id],
    enabled: !!user,
    refetchOnWindowFocus: false,
    staleTime: Infinity, // Prevent automatic refetches, rely on realtime updates
    queryFn: async () => {
      const { data, error } = await supabase
        .from('profiles')
        .select('coins, username')
        .eq('user_id', user!.id)
        .single();
      
      if (error) throw error;
      return data;
    }
  });

  // Fetch unread notifications count
  const { data: unreadCount } = useQuery({
    queryKey: ['unread-notifications', user?.id],
    enabled: !!user,
    refetchInterval: 30000, // Refresh every 30 seconds
    queryFn: async () => {
      const { count, error } = await supabase
        .from('notifications')
        .select('*', { count: 'exact', head: true })
        .eq('user_id', user!.id)
        .eq('is_read', false);
      
      if (error) throw error;
      return count ?? 0;
    }
  });

  // Setup realtime subscriptions for notifications and profile updates
  useEffect(() => {
    if (!user) return;

    const channel = supabase
      .channel('user-updates')
      .on(
        'postgres_changes',
        {
          event: 'INSERT',
          schema: 'public',
          table: 'notifications',
          filter: `user_id=eq.${user.id}`
        },
        () => {
          queryClient.invalidateQueries({ queryKey: ['unread-notifications'] });
        }
      )
      .on(
        'postgres_changes',
        {
          event: 'UPDATE',
          schema: 'public',
          table: 'profiles',
          filter: `user_id=eq.${user.id}`
        },
        () => {
          queryClient.invalidateQueries({ queryKey: ['profile', user.id] });
        }
      )
      .subscribe();

    return () => {
      supabase.removeChannel(channel);
    };
  }, [user, queryClient]);

  // Claim daily reward mutation
  const claimRewardMutation = useMutation({
    mutationFn: async () => {
      const { data, error } = await supabase.rpc('claim_daily_reward');
      if (error) throw error;
      return data as { success: boolean; message: string; coins_awarded?: number; streak?: number };
    },
    onSuccess: (data) => {
      if (data.success) {
        queryClient.invalidateQueries({ queryKey: ['profile'] });
        toast.success(`${data.message} +${data.coins_awarded} coins! 🎁 Streak: ${data.streak} days`);
      } else {
        toast.info(data.message);
      }
    },
    onError: (error: Error) => {
      toast.error(error.message);
    }
  });


  const handleSignOut = async () => {
    await supabase.auth.signOut();
    toast.success("Signed out successfully");
    navigate("/");
  };

  const handleSignIn = () => {
    navigate("/auth");
  };

  return (
    <header className="fixed top-0 left-0 right-0 z-50 border-b border-border/50 bg-card/80 backdrop-blur-md">
      <div className="container mx-auto px-4">
        <div className="flex h-16 items-center justify-between">
          <Link to="/home" className="flex items-center gap-2 group">
            <div className="relative">
              <Swords className="h-6 w-6 sm:h-8 sm:w-8 text-primary animate-pulse-slow" />
              <div className="absolute inset-0 blur-xl bg-primary/30 group-hover:bg-primary/50 transition-all" />
            </div>
            <span className="text-lg sm:text-2xl font-bold text-glow">SONGVERSUS</span>
          </Link>
          
          <nav className="hidden md:flex items-center gap-6">
            <Link to="/battles" className="text-muted-foreground hover:text-foreground transition-colors">
              <Music className="inline h-4 w-4 mr-2" />
              Battles
            </Link>
            <Link to="/community" className="text-muted-foreground hover:text-foreground transition-colors">
              <Users className="inline h-4 w-4 mr-2" />
              Community
            </Link>
            <Link to="/leaderboard" className="text-muted-foreground hover:text-foreground transition-colors">
              <Trophy className="inline h-4 w-4 mr-2" />
              Leaderboard
            </Link>
            <Link to="/store" className="text-muted-foreground hover:text-foreground transition-colors">
              <ShoppingBag className="inline h-4 w-4 mr-2" />
              Store
            </Link>
            {user && (
              <Link to="/profile" className="text-muted-foreground hover:text-foreground transition-colors">
                <UserIcon className="inline h-4 w-4 mr-2" />
                Profile
              </Link>
            )}
          </nav>

          <div className="flex items-center gap-2 sm:gap-3">
            {/* Mobile Menu */}
            <Sheet open={mobileMenuOpen} onOpenChange={setMobileMenuOpen}>
              <SheetTrigger asChild className="md:hidden">
                <Button variant="ghost" size="icon">
                  <Menu className="h-5 w-5 text-foreground" />
                </Button>
              </SheetTrigger>
              <SheetContent side="right" className="w-72">
                <nav className="flex flex-col gap-4 mt-8">
                  <Link 
                    to="/battles" 
                    className="flex items-center gap-3 text-lg font-medium hover:text-primary transition-colors p-2"
                    onClick={() => setMobileMenuOpen(false)}
                  >
                    <Music className="h-5 w-5" />
                    Battles
                  </Link>
                  <Link 
                    to="/community" 
                    className="flex items-center gap-3 text-lg font-medium hover:text-primary transition-colors p-2"
                    onClick={() => setMobileMenuOpen(false)}
                  >
                    <Users className="h-5 w-5" />
                    Community
                  </Link>
                  <Link 
                    to="/leaderboard" 
                    className="flex items-center gap-3 text-lg font-medium hover:text-primary transition-colors p-2"
                    onClick={() => setMobileMenuOpen(false)}
                  >
                    <Trophy className="h-5 w-5" />
                    Leaderboard
                  </Link>
                  <Link 
                    to="/store" 
                    className="flex items-center gap-3 text-lg font-medium hover:text-primary transition-colors p-2"
                    onClick={() => setMobileMenuOpen(false)}
                  >
                    <ShoppingBag className="h-5 w-5" />
                    Store
                  </Link>
                  {user && (
                    <Link 
                      to="/profile" 
                      className="flex items-center gap-3 text-lg font-medium hover:text-primary transition-colors p-2"
                      onClick={() => setMobileMenuOpen(false)}
                    >
                      <UserIcon className="h-5 w-5" />
                      Profile
                    </Link>
                  )}
                </nav>
              </SheetContent>
            </Sheet>

            {user ? (
              <>
                <Link to="/store">
                  <Badge variant="secondary" className="gap-1 px-2 sm:px-3 py-1.5 text-sm sm:text-base font-bold cursor-pointer hover:bg-secondary/80 transition-colors">
                    <Coins className="h-3 w-3 sm:h-4 sm:w-4 text-yellow-500" />
                    <span>{profile?.coins ?? 0}</span>
                  </Badge>
                </Link>
                <Button 
                  variant="ghost" 
                  size="icon" 
                  className="relative h-9 w-9 sm:h-10 sm:w-10"
                  onClick={() => navigate('/inbox')}
                >
                  <Inbox className="h-4 w-4 sm:h-5 sm:w-5 text-foreground" />
                  {unreadCount && unreadCount > 0 && (
                    <span className="absolute -top-1 -right-1 h-5 w-5 rounded-full bg-destructive text-destructive-foreground text-xs flex items-center justify-center font-bold">
                      {unreadCount > 9 ? '9+' : unreadCount}
                    </span>
                  )}
                </Button>
                <DropdownMenu>
                  <DropdownMenuTrigger asChild>
                    <Button variant="ghost" size="icon" className="rounded-full h-9 w-9 sm:h-10 sm:w-10">
                      <UserIcon className="h-4 w-4 sm:h-5 sm:w-5 text-foreground" />
                    </Button>
                  </DropdownMenuTrigger>
                  <DropdownMenuContent align="end" className="w-56 bg-card z-50">
                    <DropdownMenuLabel>
                      <div className="flex flex-col">
                        <span className="text-sm font-medium">{profile?.username ?? 'User'}</span>
                        <span className="text-xs text-muted-foreground">{user.email}</span>
                      </div>
                    </DropdownMenuLabel>
                    <DropdownMenuSeparator />
                    <DropdownMenuItem asChild>
                      <Link to="/profile" className="cursor-pointer">
                        <UserIcon className="mr-2 h-4 w-4" />
                        Profile
                      </Link>
                    </DropdownMenuItem>
                    <DropdownMenuItem 
                      onClick={() => claimRewardMutation.mutate()}
                      disabled={claimRewardMutation.isPending}
                      className="cursor-pointer"
                    >
                      <Gift className="mr-2 h-4 w-4" />
                      Daily Reward
                    </DropdownMenuItem>
                    <DropdownMenuItem className="cursor-pointer">
                      <Settings className="mr-2 h-4 w-4" />
                      Settings
                    </DropdownMenuItem>
                    <DropdownMenuSeparator />
                    <DropdownMenuItem onClick={handleSignOut} className="cursor-pointer text-destructive">
                      <LogOut className="mr-2 h-4 w-4" />
                      Sign Out
                    </DropdownMenuItem>
                  </DropdownMenuContent>
                </DropdownMenu>
              </>
            ) : (
              <Button variant="ghost" size="default" onClick={handleSignIn}>
                Sign In
              </Button>
            )}
          </div>
        </div>
      </div>
    </header>
  );
};
