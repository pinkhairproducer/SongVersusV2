import { useState } from "react";
import { Dialog, DialogContent, DialogDescription, DialogHeader, DialogTitle, DialogTrigger } from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { Label } from "@/components/ui/label";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Input } from "@/components/ui/input";
import { useMutation, useQueryClient } from "@tanstack/react-query";
import { supabase } from "@/integrations/supabase/client";
import { useToast } from "@/hooks/use-toast";
import { useNavigate } from "react-router-dom";
import { Loader2, Upload } from "lucide-react";

interface CreateBattleDialogProps {
  children: React.ReactNode;
}

export function CreateBattleDialog({ children }: CreateBattleDialogProps) {
  const [open, setOpen] = useState(false);
  const [battleType, setBattleType] = useState<string>("");
  const [genre, setGenre] = useState<string>("");
  const [audioFile, setAudioFile] = useState<File | null>(null);
  const { toast } = useToast();
  const navigate = useNavigate();
  const queryClient = useQueryClient();

  const createBattleMutation = useMutation({
    mutationFn: async () => {
      const { data: { user } } = await supabase.auth.getUser();
      
      if (!user) {
        throw new Error("You must be logged in to create a battle");
      }

      if (!battleType) {
        throw new Error("Please select a battle type");
      }

      if (!genre) {
        throw new Error("Please select a genre");
      }

      if (!audioFile) {
        throw new Error("Please upload an audio file");
      }

      // Check if user has enough coins (20 coins to create)
      const { data: profile } = await supabase
        .from('profiles')
        .select('coins')
        .eq('user_id', user.id)
        .single();

      if (!profile || profile.coins < 20) {
        throw new Error("You need at least 20 coins to create a battle");
      }

      // Deduct coins
      const { data: deductResult } = await supabase.rpc('deduct_coins', {
        p_user_id: user.id,
        p_amount: 20
      });

      if (!deductResult) {
        throw new Error("Insufficient coins to create battle");
      }

      // First create the battle to get the battle ID
      const { data: battle, error: battleError } = await supabase
        .from('battles')
        .insert({
          creator_id: user.id,
          battle_type: battleType,
          genre: genre,
          status: 'open',
          creator_audio_url: null
        })
        .select()
        .single();

      if (battleError) throw battleError;

      // Upload the audio file
      const fileExtension = audioFile.name.split('.').pop();
      const fileName = `${battle.id}/${user.id}/${Date.now()}.${fileExtension}`;
      
      const { error: uploadError } = await supabase.storage
        .from('battle-audio')
        .upload(fileName, audioFile);

      if (uploadError) {
        // If upload fails, delete the battle
        await supabase.from('battles').delete().eq('id', battle.id);
        throw uploadError;
      }

      // Get the public URL
      const { data: { publicUrl } } = supabase.storage
        .from('battle-audio')
        .getPublicUrl(fileName);

      // Update the battle with the audio URL
      const { error: updateError } = await supabase
        .from('battles')
        .update({ creator_audio_url: publicUrl })
        .eq('id', battle.id);

      if (updateError) throw updateError;

      return { ...battle, creator_audio_url: publicUrl };
    },
    onSuccess: (battle) => {
      queryClient.invalidateQueries({ queryKey: ['battles'] });
      toast({
        title: "Battle Created!",
        description: "Your battle is now open for opponents to join.",
      });
      setOpen(false);
      setBattleType("");
      setGenre("");
      setAudioFile(null);
      navigate(`/battle/${battle.id}`);
    },
    onError: (error: Error) => {
      toast({
        title: "Error",
        description: error.message,
        variant: "destructive",
      });
    }
  });

  const handleFileChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) {
      // Check if it's an audio file
      if (!file.type.startsWith('audio/')) {
        toast({
          title: "Invalid File",
          description: "Please upload an audio file",
          variant: "destructive",
        });
        return;
      }
      setAudioFile(file);
    }
  };

  return (
    <Dialog open={open} onOpenChange={setOpen}>
      <DialogTrigger asChild>
        {children}
      </DialogTrigger>
      <DialogContent className="sm:max-w-[500px]">
        <DialogHeader>
          <DialogTitle className="text-2xl font-bold">Create Battle</DialogTitle>
          <DialogDescription>
            Select your battle type, genre, and upload your audio
          </DialogDescription>
        </DialogHeader>
        
        <div className="space-y-4 py-4">
          <div className="space-y-2">
            <Label htmlFor="battle-type">Battle Type</Label>
            <Select value={battleType} onValueChange={setBattleType}>
              <SelectTrigger id="battle-type">
                <SelectValue placeholder="Select battle type" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="producer">Producer (Beat Battle)</SelectItem>
                <SelectItem value="artist">Artist (Song Battle)</SelectItem>
              </SelectContent>
            </Select>
          </div>

          <div className="space-y-2">
            <Label htmlFor="genre">
              {battleType === "producer" ? "Beat Genre" : battleType === "artist" ? "Song Genre" : "Genre"}
            </Label>
            <Select value={genre} onValueChange={setGenre}>
              <SelectTrigger id="genre">
                <SelectValue placeholder="Select genre" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="Hip-Hop">Hip-Hop</SelectItem>
                <SelectItem value="Pop">Pop</SelectItem>
                <SelectItem value="Electronic">Electronic</SelectItem>
                <SelectItem value="R&B">R&B</SelectItem>
                <SelectItem value="Rock">Rock</SelectItem>
                <SelectItem value="Jazz">Jazz</SelectItem>
                <SelectItem value="Other">Other</SelectItem>
              </SelectContent>
            </Select>
          </div>

          <div className="space-y-2">
            <Label htmlFor="audio-file">
              Upload {battleType === "producer" ? "Beat" : battleType === "artist" ? "Song" : "Audio"}
            </Label>
            <div className="flex items-center gap-2">
              <Input
                id="audio-file"
                type="file"
                accept="audio/*"
                onChange={handleFileChange}
                className="cursor-pointer"
              />
              {audioFile && (
                <Upload className="h-4 w-4 text-primary" />
              )}
            </div>
            {audioFile && (
              <p className="text-sm text-muted-foreground">
                {audioFile.name}
              </p>
            )}
          </div>
        </div>

        <div className="flex gap-3">
          <Button
            variant="outline"
            className="flex-1"
            onClick={() => setOpen(false)}
          >
            Cancel
          </Button>
          <Button
            variant="battle"
            className="flex-1"
            onClick={() => createBattleMutation.mutate()}
            disabled={createBattleMutation.isPending || !battleType || !genre || !audioFile}
          >
            {createBattleMutation.isPending ? (
              <>
                <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                Creating...
              </>
            ) : (
              "Create Battle"
            )}
          </Button>
        </div>
      </DialogContent>
    </Dialog>
  );
}
