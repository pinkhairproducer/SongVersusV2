import { useState } from "react";
import { Dialog, DialogContent } from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { motion, AnimatePresence } from "framer-motion";
import { ChevronLeft, ChevronRight, Music, Swords, Trophy, Coins } from "lucide-react";

interface TutorialModalProps {
  open: boolean;
  onComplete: () => void;
}

const tutorialSteps = [
  {
    icon: Swords,
    title: "Welcome to SONGVERSUS",
    description: "The ultimate music battle platform where producers and artists compete head-to-head. Your beats and songs face off for glory!",
  },
  {
    icon: Music,
    title: "Create Your Battle",
    description: "Choose your role (Producer or Artist), select your genre, upload your track, and challenge the community. Your battle goes live instantly!",
  },
  {
    icon: Trophy,
    title: "Vote & Compete",
    description: "Listen to battles and vote for your favorite. Every vote counts! Winners earn coins, XP, and climb the leaderboard.",
  },
  {
    icon: Coins,
    title: "Earn & Spend Coins",
    description: "Earn coins by voting, commenting, and winning battles. Use coins in the store for customizations, or claim daily rewards to build your streak!",
  },
];

export const TutorialModal = ({ open, onComplete }: TutorialModalProps) => {
  const [currentStep, setCurrentStep] = useState(0);

  const handleNext = () => {
    if (currentStep < tutorialSteps.length - 1) {
      setCurrentStep(currentStep + 1);
    } else {
      onComplete();
    }
  };

  const handlePrev = () => {
    if (currentStep > 0) {
      setCurrentStep(currentStep - 1);
    }
  };

  const currentStepData = tutorialSteps[currentStep];
  const Icon = currentStepData.icon;

  return (
    <Dialog open={open} onOpenChange={() => {}}>
      <DialogContent className="sm:max-w-2xl bg-card border-border/50 p-0 overflow-hidden">
        <div className="relative min-h-[400px] flex flex-col">
          {/* Background gradient */}
          <div className="absolute inset-0 bg-gradient-to-br from-primary/10 via-transparent to-secondary/10" />
          
          {/* Content */}
          <div className="relative flex-1 flex flex-col items-center justify-center p-8 text-center">
            <AnimatePresence mode="wait">
              <motion.div
                key={currentStep}
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                exit={{ opacity: 0, y: -20 }}
                transition={{ duration: 0.3 }}
                className="flex flex-col items-center gap-6"
              >
                <div className="relative">
                  <div className="absolute inset-0 blur-2xl bg-primary/30 rounded-full" />
                  <Icon className="relative h-24 w-24 text-primary" />
                </div>
                
                <div className="space-y-4">
                  <h2 className="text-3xl font-bold text-glow">{currentStepData.title}</h2>
                  <p className="text-lg text-muted-foreground max-w-lg">
                    {currentStepData.description}
                  </p>
                </div>
              </motion.div>
            </AnimatePresence>
          </div>

          {/* Navigation */}
          <div className="relative border-t border-border/50 bg-card/50 backdrop-blur-sm p-6">
            <div className="flex items-center justify-between">
              <Button
                variant="ghost"
                onClick={handlePrev}
                disabled={currentStep === 0}
                className="gap-2"
              >
                <ChevronLeft className="h-4 w-4" />
                Previous
              </Button>

              {/* Step indicators */}
              <div className="flex gap-2">
                {tutorialSteps.map((_, index) => (
                  <div
                    key={index}
                    className={`h-2 rounded-full transition-all ${
                      index === currentStep
                        ? "w-8 bg-primary"
                        : "w-2 bg-muted"
                    }`}
                  />
                ))}
              </div>

              <Button
                onClick={handleNext}
                className="gap-2"
              >
                {currentStep === tutorialSteps.length - 1 ? "Get Started" : "Next"}
                {currentStep < tutorialSteps.length - 1 && <ChevronRight className="h-4 w-4" />}
              </Button>
            </div>
          </div>
        </div>
      </DialogContent>
    </Dialog>
  );
};
