import { useEffect } from "react";
import { Header } from "@/components/Header";
import { Button } from "@/components/ui/button";
import { Card } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Avatar, AvatarFallback } from "@/components/ui/avatar";
import { Music, Clock, ArrowRight, Crown, Hourglass } from "lucide-react";
import { CountdownTimer } from "@/components/CountdownTimer";
import battleArena from "@/assets/battle-arena.jpg";
import { CreateBattleDialog } from "@/components/CreateBattleDialog";
import { useQuery, useQueryClient } from "@tanstack/react-query";
import { supabase } from "@/integrations/supabase/client";
import { useNavigate } from "react-router-dom";
import { Skeleton } from "@/components/ui/skeleton";
import { formatDistanceToNow } from "date-fns";
import { motion } from "framer-motion";
import { Progress } from "@/components/ui/progress";

const Battles = () => {
  const navigate = useNavigate();
  const queryClient = useQueryClient();

  const { data: allBattles, isLoading } = useQuery({
    queryKey: ["battles"],
    queryFn: async () => {
      const { data, error } = await supabase
        .from("battles")
        .select(`
          *,
          creator:profiles!battles_creator_id_fkey(username, avatar_url, level),
          opponent:profiles!battles_opponent_id_fkey(username, avatar_url, level)
        `)
        .order("created_at", { ascending: false });

      if (error) throw error;
      return data;
    },
  });

  // Realtime subscription for battle updates
  useEffect(() => {
    const channel = supabase
      .channel('battles-list-updates')
      .on(
        'postgres_changes',
        {
          event: '*',
          schema: 'public',
          table: 'battles'
        },
        () => {
          // Refetch battles when any battle changes
          queryClient.invalidateQueries({ queryKey: ['battles'] });
        }
      )
      .subscribe();

    return () => {
      supabase.removeChannel(channel);
    };
  }, [queryClient]);

  const beatBattles = allBattles?.filter(b => b.battle_type === 'producer') || [];
  const songBattles = allBattles?.filter(b => b.battle_type === 'artist') || [];

  const getVotePercentage = (votes: number, total: number) => {
    if (total === 0) return 0;
    return Math.round((votes / total) * 100);
  };

  const handleNavigate = (battleId: string) => {
    navigate(`/battle/${battleId}`);
  };

  const renderBattleCard = (battle: any) => {
    const totalVotes = battle.creator_votes + battle.opponent_votes;
    const creatorPercentage = getVotePercentage(battle.creator_votes, totalVotes);
    const winner = battle.creator_votes > battle.opponent_votes ? 'creator' : 
                  battle.opponent_votes > battle.creator_votes ? 'opponent' : 'tie';
    
    // Check if battle has actually ended
    const hasEnded = battle.ends_at && new Date(battle.ends_at) < new Date();
    const actualStatus = hasEnded ? 'finished' : battle.status;

    return (
      <motion.div
        key={battle.id}
        whileHover={{ scale: 1.02 }}
        className="cursor-pointer"
        onClick={() => handleNavigate(battle.id)}
      >
        <Card className="overflow-hidden border-2 hover:border-primary transition-colors">
          <div className="h-32 bg-gradient-to-br from-primary/20 via-secondary/20 to-accent/20 relative flex items-center justify-center">
            {actualStatus === 'open' ? (
              <div className="flex flex-col items-center gap-2">
                <Hourglass className="h-8 w-8 text-primary animate-pulse" />
                <p className="text-lg font-bold text-primary">Waiting for opponent</p>
              </div>
            ) : actualStatus === 'ongoing' && battle.ends_at ? (
              <div className="flex flex-col items-center gap-1">
                <p className="text-sm text-muted-foreground">Battle ends in</p>
                <CountdownTimer endsAt={battle.ends_at} />
              </div>
            ) : (
              <div className="flex flex-col items-center gap-1">
                <Clock className="h-8 w-8 text-muted-foreground" />
                <p className="text-lg font-bold text-foreground">Battle Finished</p>
              </div>
            )}
            <div className="absolute top-2 right-2 flex gap-2">
              <Badge variant="secondary">{actualStatus}</Badge>
              {battle.genre && <Badge variant="outline">{battle.genre}</Badge>}
            </div>
          </div>
          <div className="p-6 space-y-4">
            {battle.status === 'open' ? (
              <>
                <div className="flex items-center gap-3">
                  <Avatar>
                    <AvatarFallback>
                      {battle.creator?.username?.[0]?.toUpperCase() || "?"}
                    </AvatarFallback>
                  </Avatar>
                  <div>
                    <p className="font-bold">{battle.creator?.username || "Unknown"}</p>
                    <p className="text-sm text-muted-foreground">Level {battle.creator?.level || 1}</p>
                  </div>
                </div>
                <div className="flex items-center gap-2 text-sm text-muted-foreground">
                  <Clock className="h-4 w-4" />
                  {formatDistanceToNow(new Date(battle.created_at), { addSuffix: true })}
                </div>
                <Button className="w-full" variant="battle">
                  Join Battle <ArrowRight className="ml-2 h-4 w-4" />
                </Button>
              </>
            ) : (
              <>
                <div className="flex items-center justify-between gap-2">
                  <div className="flex items-center gap-2 min-w-0 flex-1">
                    {winner === 'creator' && actualStatus === 'finished' && <Crown className="h-4 w-4 text-yellow-500 flex-shrink-0" />}
                    <Avatar className="h-10 w-10 flex-shrink-0">
                      <AvatarFallback>
                        {battle.creator?.username?.[0]?.toUpperCase() || "?"}
                      </AvatarFallback>
                    </Avatar>
                    <div className="min-w-0 flex-1">
                      <p className="font-bold text-sm truncate">{battle.creator?.username || "Unknown"}</p>
                      <p className="text-xs text-muted-foreground">{battle.creator_votes} votes</p>
                    </div>
                  </div>
                  <div className="text-xl sm:text-2xl font-bold text-muted-foreground flex-shrink-0">VS</div>
                  <div className="flex items-center gap-2 min-w-0 flex-1">
                    <div className="text-right min-w-0 flex-1">
                      <p className="font-bold text-sm truncate">{battle.opponent?.username || "Unknown"}</p>
                      <p className="text-xs text-muted-foreground">{battle.opponent_votes} votes</p>
                    </div>
                    <Avatar className="h-10 w-10 flex-shrink-0">
                      <AvatarFallback>
                        {battle.opponent?.username?.[0]?.toUpperCase() || "?"}
                      </AvatarFallback>
                    </Avatar>
                    {winner === 'opponent' && actualStatus === 'finished' && <Crown className="h-4 w-4 text-yellow-500 flex-shrink-0" />}
                  </div>
                </div>
                <Progress value={creatorPercentage} className="h-2" />
                <div className="flex items-center gap-2 text-sm text-muted-foreground">
                  <Clock className="h-4 w-4 flex-shrink-0" />
                  <span className="truncate">
                    {actualStatus === 'finished' ? (
                      <>Finished {formatDistanceToNow(new Date(battle.updated_at), { addSuffix: true })}</>
                    ) : battle.ends_at ? (
                      <>Ends {formatDistanceToNow(new Date(battle.ends_at), { addSuffix: true })}</>
                    ) : (
                      "Live"
                    )}
                  </span>
                </div>
                <Button className="w-full" variant="outline">
                  {actualStatus === 'finished' ? 'View Results' : 'View & Vote'} <ArrowRight className="ml-2 h-4 w-4" />
                </Button>
              </>
            )}
          </div>
        </Card>
      </motion.div>
    );
  };

  const renderBattleSection = (battles: any[], title: string) => (
    <div className="mb-16">
      <h2 className="text-3xl font-bold mb-6 text-center">
        <span className="text-primary text-glow">{title}</span>
      </h2>
      <div className="grid gap-6 md:grid-cols-2 lg:grid-cols-3">
        {isLoading ? (
          Array.from({ length: 6 }).map((_, i) => (
            <Card key={i} className="p-6">
              <Skeleton className="h-48 w-full" />
            </Card>
          ))
        ) : battles.length === 0 ? (
          <div className="col-span-full text-center py-12">
            <Music className="h-16 w-16 mx-auto mb-4 text-muted-foreground" />
            <p className="text-xl text-muted-foreground">No {title.toLowerCase()} yet</p>
            <p className="text-sm text-muted-foreground mt-2">Create one to get started!</p>
          </div>
        ) : (
          battles.map(renderBattleCard)
        )}
      </div>
    </div>
  );

  return (
    <div className="min-h-screen bg-background">
      <Header />
      
      <main className="container px-4 pt-24 pb-12">
        <motion.div 
          className="text-center mb-12"
          initial={{ opacity: 0, y: -20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.6 }}
        >
          <motion.div 
            className="inline-block mb-4"
            animate={{ 
              y: [0, -10, 0],
              rotate: [0, 5, -5, 0]
            }}
            transition={{ 
              duration: 3,
              repeat: Infinity,
              ease: "easeInOut"
            }}
          >
            <Music className="h-16 w-16 text-secondary" />
          </motion.div>
          <h1 className="text-5xl md:text-7xl font-black mb-4">
            <span className="text-primary text-glow">BATTLES</span>
          </h1>
          <p className="text-xl text-muted-foreground max-w-2xl mx-auto">
            Beat vs. Beat. Song vs. Song. The only rule? Don't miss.
          </p>
        </motion.div>

        <div className="flex justify-center mb-12">
          <CreateBattleDialog>
            <Button variant="battle" size="lg" className="text-lg px-8">
              Create Battle (20 coins)
            </Button>
          </CreateBattleDialog>
        </div>

        {renderBattleSection(beatBattles, "Beat Battles")}
        {renderBattleSection(songBattles, "Song Battles")}
      </main>
    </div>
  );
};

export default Battles;
