import { useState, useEffect } from "react";
import { motion } from "framer-motion";
import { Header } from "@/components/Header";
import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";
import { Textarea } from "@/components/ui/textarea";
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar";
import confetti from "canvas-confetti";
import { Badge } from "@/components/ui/badge";
import { useParams, useNavigate } from "react-router-dom";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { supabase } from "@/integrations/supabase/client";
import { useToast } from "@/hooks/use-toast";
import { ThumbsUp, Send, Loader2, Trophy, Crown } from "lucide-react";
import { Skeleton } from "@/components/ui/skeleton";
import { WaveformPlaceholder } from "@/components/WaveformPlaceholder";
import { AudioUpload } from "@/components/AudioUpload";
import { CountdownTimer } from "@/components/CountdownTimer";
import { CharacterDisplay } from "@/components/CharacterDisplay";
import { BattleEnergyEffects } from "@/components/BattleEnergyEffects";
import { ModernAudioPlayer } from "@/components/ModernAudioPlayer";
import { LevelUpPopup } from "@/components/LevelUpPopup";

export default function BattleView() {
  const { id } = useParams();
  const navigate = useNavigate();
  const { toast } = useToast();
  const queryClient = useQueryClient();
  const [comment, setComment] = useState("");
  const [user, setUser] = useState(null);
  const [creatorAudioPlaying, setCreatorAudioPlaying] = useState(false);
  const [opponentAudioPlaying, setOpponentAudioPlaying] = useState(false);
  const [levelUpData, setLevelUpData] = useState<{
    oldLevel: number;
    newLevel: number;
    xpGained: number;
    coinsGained: number;
    unlockedItems: string[];
  } | null>(null);

  useEffect(() => {
    supabase.auth.getUser().then(({ data: { user } }) => setUser(user));
  }, []);

  // Realtime subscription for battle updates
  useEffect(() => {
    if (!id) return;

    const channel = supabase
      .channel('battle-updates')
      .on(
        'postgres_changes',
        {
          event: '*',
          schema: 'public',
          table: 'battles',
          filter: `id=eq.${id}`
        },
        () => {
          // Refetch battle data when it changes
          queryClient.invalidateQueries({ queryKey: ['battle', id] });
        }
      )
      .subscribe();

    return () => {
      supabase.removeChannel(channel);
    };
  }, [id, queryClient]);

  const { data: battle, isLoading: battleLoading } = useQuery({
    queryKey: ['battle', id],
    queryFn: async () => {
      const { data, error } = await supabase
        .from('battles')
        .select('*')
        .eq('id', id)
        .single();
      
      if (error) throw error;

      // Fetch profiles
      const userIds = [data.creator_id, data.opponent_id].filter(Boolean);
      const { data: profiles } = await supabase
        .from('profiles')
        .select('*')
        .in('user_id', userIds);

      return {
        ...data,
        creator: profiles?.find(p => p.user_id === data.creator_id),
        opponent: profiles?.find(p => p.user_id === data.opponent_id)
      };
    }
  });

  const { data: userVote } = useQuery({
    queryKey: ['user-vote', id],
    enabled: !!user,
    queryFn: async () => {
      const { data } = await supabase
        .from('battle_votes')
        .select('voted_for')
        .eq('battle_id', id)
        .eq('user_id', user.id)
        .maybeSingle();
      
      return data;
    }
  });

  const { data: comments, isLoading: commentsLoading } = useQuery({
    queryKey: ['battle-comments', id],
    queryFn: async () => {
      const { data, error } = await supabase
        .from('battle_comments')
        .select('*')
        .eq('battle_id', id)
        .order('created_at', { ascending: false });
      
      if (error) throw error;

      if (data && data.length > 0) {
        const userIds = data.map((c: any) => c.user_id);
        const { data: profiles } = await supabase
          .from('profiles')
          .select('*')
          .in('user_id', userIds);

        return data.map((comment: any) => ({
          ...comment,
          user: profiles?.find((p: any) => p.user_id === comment.user_id)
        }));
      }
      
      return data || [];
    }
  });

  const voteMutation = useMutation({
    mutationFn: async (votedFor: 'creator' | 'opponent') => {
      if (!user) throw new Error("Must be logged in to vote");
      if (!id) throw new Error("Invalid battle");

      // Use the secure database function
      const { error } = await supabase.rpc('record_battle_vote', {
        p_battle_id: id,
        p_user_id: user.id,
        p_voted_for: votedFor
      });

      if (error) throw error;
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['battle', id] });
      queryClient.invalidateQueries({ queryKey: ['user-vote', id] });
      toast({ title: "Vote recorded!" });
    },
    onError: (error: Error) => {
      toast({
        title: "Error",
        description: error.message,
        variant: "destructive"
      });
    }
  });

  const validateComment = (msg: string): string | null => {
    const dangerousPatterns = /<script|javascript:|onerror=|onclick=/i;
    if (dangerousPatterns.test(msg)) {
      return 'Comment contains invalid content';
    }
    return null;
  };

  const commentMutation = useMutation({
    mutationFn: async () => {
      if (!user) throw new Error("Must be logged in");
      if (!comment.trim()) throw new Error("Comment cannot be empty");
      
      const validationError = validateComment(comment.trim());
      if (validationError) throw new Error(validationError);

      await supabase
        .from('battle_comments')
        .insert({ battle_id: id, user_id: user.id, comment: comment.trim() });
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['battle-comments', id] });
      setComment("");
      toast({ title: "Comment posted!" });
    },
    onError: (error: Error) => {
      toast({
        title: "Error",
        description: error.message,
        variant: "destructive"
      });
    }
  });

  const joinMutation = useMutation({
    mutationFn: async () => {
      if (!user) throw new Error("Must be logged in");
      if (battle?.opponent_id) throw new Error("Battle already has an opponent");

      // Check if user has enough coins (15 coins to join)
      const { data: profile } = await supabase
        .from('profiles')
        .select('coins')
        .eq('user_id', user.id)
        .single();

      if (!profile || profile.coins < 15) {
        throw new Error("You need at least 15 coins to join a battle");
      }

      // Deduct coins
      const { data: deductResult } = await supabase.rpc('deduct_coins', {
        p_user_id: user.id,
        p_amount: 15
      });

      if (!deductResult) {
        throw new Error("Insufficient coins to join battle");
      }

      const updates: any = { opponent_id: user.id };
      if (!battle?.ends_at) {
        updates.ends_at = new Date(Date.now() + 24 * 60 * 60 * 1000).toISOString();
      }

      const { error } = await supabase
        .from('battles')
        .update(updates)
        .eq('id', id);
      if (error) throw error;
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['battle', id] });
      toast({ title: "Joined battle! You can now upload your audio." });
    },
    onError: (error: Error) => {
      toast({
        title: "Error",
        description: error.message,
        variant: "destructive"
      });
    }
  });

  // Check and update battle status if needed, then check for level-up
  useEffect(() => {
    if (!battle || !user) return;
    
    const bothAudioUploaded = Boolean(battle.creator_audio_url && battle.opponent_audio_url);
    const hasEnded = battle.ends_at && new Date(battle.ends_at) < new Date();
    const isBattleFinished = battle.status === 'finished' || hasEnded;

    // If battle should be finished but isn't marked as such, trigger the check
    const checkBattleStatus = async () => {
      if (hasEnded && battle.status !== 'finished') {
        try {
          await supabase.rpc('check_finished_battles');
          // Refetch battle data after updating status
          queryClient.invalidateQueries({ queryKey: ['battle', id] });
        } catch (error) {
          console.error('Error checking finished battles:', error);
        }
      }
    };

    checkBattleStatus();

    if (isBattleFinished && bothAudioUploaded) {
      // Determine if current user won
      const isCreator = battle.creator_id === user.id;
      const isOpponent = battle.opponent_id === user.id;
      const isWinner = (isCreator && battle.creator_votes > battle.opponent_votes) ||
                       (isOpponent && battle.opponent_votes > battle.creator_votes);

      if (isWinner) {
        // Check for level-up
        const checkLevelUp = async () => {
          const { data: profile } = await supabase
            .from('profiles')
            .select('level, xp')
            .eq('user_id', user.id)
            .single();

          if (profile) {
            const currentLevel = profile.level;
            const xpGained = 50; // Base XP for winning
            const coinsGained = 25; // Base coins for winning
            
            // Calculate if they leveled up (every 100 XP = 1 level)
            const oldLevel = Math.floor((profile.xp - xpGained) / 100) + 1;
            const newLevel = Math.floor(profile.xp / 100) + 1;

            if (newLevel > oldLevel) {
              // Check for newly unlocked items
              const { data: unlockedItems } = await supabase
                .from('customization_items')
                .select('name')
                .eq('required_level', newLevel)
                .limit(3);

              setLevelUpData({
                oldLevel,
                newLevel,
                xpGained,
                coinsGained,
                unlockedItems: unlockedItems?.map(item => item.name) || []
              });
            }
          }
        };

        checkLevelUp();
      }

      // Trigger confetti
      const duration = 3000;
      const animationEnd = Date.now() + duration;
      const defaults = { startVelocity: 30, spread: 360, ticks: 60, zIndex: 0 };

      const randomInRange = (min: number, max: number) => Math.random() * (max - min) + min;

      const interval = window.setInterval(() => {
        const timeLeft = animationEnd - Date.now();

        if (timeLeft <= 0) {
          return clearInterval(interval);
        }

        const particleCount = 50 * (timeLeft / duration);
        
        confetti({
          ...defaults,
          particleCount,
          origin: { x: randomInRange(0.1, 0.3), y: Math.random() - 0.2 }
        });
        confetti({
          ...defaults,
          particleCount,
          origin: { x: randomInRange(0.7, 0.9), y: Math.random() - 0.2 }
        });
      }, 250);

      return () => clearInterval(interval);
    }
  }, [battle, user]);

  if (battleLoading) {
    return (
      <div className="min-h-screen bg-background">
        <Header />
        <main className="container mx-auto px-4 py-8">
          <Skeleton className="h-96 w-full" />
        </main>
      </div>
    );
  }

  if (!battle) {
    return (
      <div className="min-h-screen bg-background">
        <Header />
        <main className="container mx-auto px-4 py-8">
          <p className="text-center text-xl">Battle not found</p>
        </main>
      </div>
    );
  }

  const totalVotes = battle.creator_votes + battle.opponent_votes;
  const creatorPercentage = totalVotes === 0 ? 50 : (battle.creator_votes / totalVotes) * 100;
  
  // Both players need to upload audio before it can be played
  const bothAudioUploaded = Boolean(battle.creator_audio_url && battle.opponent_audio_url);
  const battleCanStart = Boolean(bothAudioUploaded && battle.opponent_id);

  // Check if battle has ended
  const hasEnded = battle.ends_at && new Date(battle.ends_at) < new Date();
  const isBattleFinished = battle.status === 'finished' || hasEnded;

  // Determine winner
  const winner = battle.creator_votes > battle.opponent_votes ? 'creator' : 
                battle.opponent_votes > battle.creator_votes ? 'opponent' : 'tie';
  const winnerName = winner === 'creator' ? battle.creator?.username : 
                     winner === 'opponent' ? battle.opponent?.username : null;

  // Ensure a 24-hour countdown exists even if ends_at is missing
  const endsAt = battle.ends_at || new Date(new Date(battle.created_at).getTime() + 24 * 60 * 60 * 1000).toISOString();

  return (
    <div className="min-h-screen bg-background">
      <Header />
      <main className="container mx-auto px-4 py-8 max-w-6xl">
        {!bothAudioUploaded ? (
          // Pre-battle: Upload Phase
          <>
            <div className="mb-6 text-center space-y-2">
              <div>
                <Badge className="mb-2">{battle.battle_type}</Badge>
                {battle.genre && <Badge variant="outline" className="ml-2">{battle.genre}</Badge>}
              </div>
              <h1 className="text-3xl font-bold">Battle Arena</h1>
              <CountdownTimer endsAt={endsAt} />
            </div>

            <div className="grid md:grid-cols-2 gap-8 mb-12">
              {/* Creator Side */}
              <Card className="relative">
                <CardContent className="p-6 space-y-4">
                    <div className="text-center mb-4">
                      <h2 className="text-2xl font-bold text-glow">{battle.creator?.username}</h2>
                      <p className="text-muted-foreground">Level {battle.creator?.level}</p>
                    </div>

                  <div className="flex items-center justify-center">
                    <motion.div
                      animate={{ 
                        y: [0, -10, 0],
                      }}
                      transition={{ 
                        duration: 2,
                        repeat: Infinity,
                        ease: "easeInOut"
                      }}
                    >
                      <CharacterDisplay 
                        userId={battle.creator_id} 
                        size="md"
                      />
                    </motion.div>
                  </div>

                  {user?.id === battle.creator_id && !battle.creator_audio_url && (
                    <div className="flex justify-center">
                      <AudioUpload
                        battleId={battle.id}
                        userId={user.id}
                        isCreator={true}
                        onUploadComplete={() => queryClient.invalidateQueries({ queryKey: ['battle', id] })}
                      />
                    </div>
                  )}
                </CardContent>
              </Card>

              {/* Opponent Side */}
              <Card className="relative">
                <CardContent className="p-6 space-y-4">
                  <div className="text-center mb-4">
                    <h2 className="text-2xl font-bold">{battle.opponent?.username || 'Waiting...'}</h2>
                    <p className="text-muted-foreground">Level {battle.opponent?.level || '?'}</p>
                  </div>

                  <div className="flex items-center justify-center">
                    {battle.opponent_id ? (
                      <motion.div
                        animate={{ 
                          y: [0, -10, 0],
                        }}
                        transition={{ 
                          duration: 2,
                          repeat: Infinity,
                          ease: "easeInOut",
                          delay: 1
                        }}
                      >
                        <CharacterDisplay 
                          userId={battle.opponent_id} 
                          size="md"
                        />
                      </motion.div>
                    ) : (
                      <div className="w-48 h-48 rounded-lg border-4 border-dashed border-primary/30 flex flex-col items-center justify-center p-4 text-center">
                        {user && user.id !== battle.creator_id ? (
                          <>
                            <p className="text-muted-foreground mb-2">Join this battle</p>
                            <Button onClick={() => joinMutation.mutate()} disabled={joinMutation.isPending}>
                              {joinMutation.isPending ? (
                                <Loader2 className="h-4 w-4 animate-spin" />
                              ) : (
                                <>Join Battle</>
                              )}
                            </Button>
                          </>
                        ) : (
                          <p className="text-muted-foreground">Waiting for opponent...</p>
                        )}
                      </div>
                    )}
                  </div>

                  {user?.id === battle.opponent_id && !battle.opponent_audio_url && (
                    <div className="flex justify-center">
                      <AudioUpload
                        battleId={battle.id}
                        userId={user.id}
                        isCreator={false}
                        onUploadComplete={() => queryClient.invalidateQueries({ queryKey: ['battle', id] })}
                      />
                    </div>
                  )}
                </CardContent>
              </Card>
            </div>
          </>
        ) : (
          // Battle Active: Both audios uploaded
          <>
            <div className="mb-8 text-center space-y-4">
              <div>
                <Badge className="mb-2">{battle.battle_type}</Badge>
                {battle.genre && <Badge variant="outline" className="ml-2">{battle.genre}</Badge>}
              </div>
              
              {isBattleFinished ? (
                <motion.div
                  initial={{ scale: 0, opacity: 0 }}
                  animate={{ scale: 1, opacity: 1 }}
                  transition={{ type: "spring", duration: 0.8, bounce: 0.5 }}
                  className="space-y-4"
                >
                  <motion.div
                    animate={{ 
                      rotate: [0, -5, 5, -5, 5, 0],
                      scale: [1, 1.05, 1]
                    }}
                    transition={{ 
                      duration: 1,
                      repeat: Infinity,
                      repeatDelay: 2
                    }}
                    className="inline-block"
                  >
                    <Trophy className="h-20 w-20 text-yellow-500 mx-auto drop-shadow-[0_0_15px_rgba(234,179,8,0.5)]" />
                  </motion.div>
                  
                  <motion.h1 
                    className="text-5xl font-black"
                    initial={{ y: 20, opacity: 0 }}
                    animate={{ y: 0, opacity: 1 }}
                    transition={{ delay: 0.3 }}
                  >
                    <span className="text-glow">BATTLE FINISHED!</span>
                  </motion.h1>
                  
                  {winner !== 'tie' ? (
                    <motion.div
                      initial={{ y: 20, opacity: 0 }}
                      animate={{ y: 0, opacity: 1 }}
                      transition={{ delay: 0.5 }}
                      className="space-y-2"
                    >
                      <div className="flex items-center justify-center gap-2">
                        <Crown className="h-8 w-8 text-yellow-500" />
                        <p className="text-3xl font-bold text-primary">
                          {winnerName} WINS!
                        </p>
                        <Crown className="h-8 w-8 text-yellow-500" />
                      </div>
                      <p className="text-xl text-muted-foreground">
                        With {winner === 'creator' ? battle.creator_votes : battle.opponent_votes} votes
                      </p>
                    </motion.div>
                  ) : (
                    <motion.p
                      initial={{ y: 20, opacity: 0 }}
                      animate={{ y: 0, opacity: 1 }}
                      transition={{ delay: 0.5 }}
                      className="text-2xl font-bold text-secondary"
                    >
                      IT'S A TIE!
                    </motion.p>
                  )}
                </motion.div>
              ) : (
                <>
                  <h1 className="text-4xl font-bold bg-gradient-to-r from-primary to-primary/60 bg-clip-text text-transparent">
                    Battle in Progress!
                  </h1>
                  <CountdownTimer endsAt={endsAt} />
                </>
              )}
              
              <p className="text-xl font-semibold text-muted-foreground">{totalVotes} total votes</p>
            </div>

            {/* Battle Arena - Characters facing each other */}
            <div className="relative mb-12 bg-gradient-to-br from-primary/10 via-secondary/5 to-accent/10 rounded-xl p-8 border-2 border-primary/30 overflow-hidden shadow-2xl">
              {/* 3D Energy Effects */}
              <BattleEnergyEffects 
                creatorVotePercentage={creatorPercentage}
                opponentVotePercentage={100 - creatorPercentage}
                totalVotes={totalVotes}
              />
              
              {/* Animated Background Particles */}
              <div className="absolute inset-0 opacity-30">
                {[...Array(20)].map((_, i) => (
                  <motion.div
                    key={i}
                    className="absolute w-2 h-2 bg-primary rounded-full"
                    style={{
                      left: `${Math.random() * 100}%`,
                      top: `${Math.random() * 100}%`,
                    }}
                    animate={{
                      y: [0, -30, 0],
                      opacity: [0.2, 0.8, 0.2],
                    }}
                    transition={{
                      duration: 3 + Math.random() * 2,
                      repeat: Infinity,
                      delay: Math.random() * 2,
                    }}
                  />
                ))}
              </div>
              
              <div className="grid grid-cols-2 gap-16 mb-8 relative z-10">
                {/* Creator Character - Left Side */}
                <div className="flex flex-col items-center space-y-4">
                  <motion.div 
                    className="relative"
                    animate={creatorAudioPlaying ? { 
                      x: [-5, 15, -5],
                      rotate: [-3, 3, -3],
                      scale: [1, 1.05, 1]
                    } : { 
                      x: [0, 10, 0],
                      rotate: [0, -2, 0]
                    }}
                    transition={creatorAudioPlaying ? { 
                      duration: 0.5,
                      repeat: Infinity,
                      ease: "easeInOut"
                    } : { 
                      duration: 3,
                      repeat: Infinity,
                      ease: "easeInOut"
                    }}
                  >
                    <motion.div
                      whileHover={{ scale: 1.1, rotate: 5 }}
                      transition={{ type: "spring", stiffness: 300 }}
                    >
                      <motion.div
                        animate={creatorAudioPlaying ? {
                          y: [0, -8],
                        } : {}}
                        transition={{
                          duration: 0.3,
                          repeat: Infinity,
                          repeatType: "reverse",
                          ease: "easeInOut"
                        }}
                      >
                        <CharacterDisplay 
                          userId={battle.creator_id} 
                          size="lg"
                          className="drop-shadow-2xl"
                        />
                      </motion.div>
                    </motion.div>
                    {/* Glow effect based on votes or audio playing */}
                    <motion.div
                      className={`absolute inset-0 rounded-lg blur-xl ${creatorAudioPlaying ? 'bg-primary/40' : 'bg-primary/20'}`}
                      animate={{
                        opacity: creatorAudioPlaying ? [0.5, 1, 0.5] : [0.3, 0.6, 0.3],
                        scale: creatorAudioPlaying ? [1, 1.2, 1] : [1, 1.1, 1]
                      }}
                      transition={{
                        duration: creatorAudioPlaying ? 0.6 : 2,
                        repeat: Infinity,
                      }}
                      style={{ zIndex: -1 }}
                    />
                    {/* Attack effect when playing */}
                    {creatorAudioPlaying && (
                      <motion.div
                        className="absolute -right-8 top-1/2 text-4xl"
                        initial={{ x: 0, opacity: 1 }}
                        animate={{ x: 30, opacity: 0 }}
                        transition={{ duration: 0.5, repeat: Infinity, repeatDelay: 0.3 }}
                      >
                        💥
                      </motion.div>
                    )}
                  </motion.div>
                  <div className="text-center">
                    <h2 className="text-2xl font-bold">{battle.creator?.username}</h2>
                    <p className="text-muted-foreground">Level {battle.creator?.level}</p>
                    {userVote && (
                      <div className="mt-2">
                        <p className="text-3xl font-bold text-primary">{Math.round(creatorPercentage)}%</p>
                        <p className="text-sm text-muted-foreground">{battle.creator_votes} votes</p>
                      </div>
                    )}
                  </div>
                </div>

                {/* Opponent Character - Right Side (flipped) */}
                <div className="flex flex-col items-center space-y-4">
                  <motion.div 
                    className="relative"
                    animate={opponentAudioPlaying ? { 
                      x: [5, -15, 5],
                      rotate: [3, -3, 3],
                      scale: [1, 1.05, 1]
                    } : { 
                      x: [0, -10, 0],
                      rotate: [0, 2, 0]
                    }}
                    transition={opponentAudioPlaying ? { 
                      duration: 0.5,
                      repeat: Infinity,
                      ease: "easeInOut"
                    } : { 
                      duration: 3,
                      repeat: Infinity,
                      ease: "easeInOut",
                      delay: 1.5
                    }}
                  >
                    <motion.div
                      whileHover={{ scale: 1.1, rotate: -5 }}
                      transition={{ type: "spring", stiffness: 300 }}
                    >
                      <motion.div
                        animate={opponentAudioPlaying ? {
                          y: [0, -8],
                        } : {}}
                        transition={{
                          duration: 0.3,
                          repeat: Infinity,
                          repeatType: "reverse",
                          ease: "easeInOut"
                        }}
                      >
                        <CharacterDisplay 
                          userId={battle.opponent_id!} 
                          size="lg"
                          className="transform scale-x-[-1] drop-shadow-2xl"
                        />
                      </motion.div>
                    </motion.div>
                    {/* Glow effect based on votes or audio playing */}
                    <motion.div
                      className={`absolute inset-0 rounded-lg blur-xl ${opponentAudioPlaying ? 'bg-secondary/40' : 'bg-secondary/20'}`}
                      animate={{
                        opacity: opponentAudioPlaying ? [0.5, 1, 0.5] : [0.3, 0.6, 0.3],
                        scale: opponentAudioPlaying ? [1, 1.2, 1] : [1, 1.1, 1]
                      }}
                      transition={{
                        duration: opponentAudioPlaying ? 0.6 : 2,
                        repeat: Infinity,
                        delay: opponentAudioPlaying ? 0 : 1
                      }}
                      style={{ zIndex: -1 }}
                    />
                    {/* Attack effect when playing */}
                    {opponentAudioPlaying && (
                      <motion.div
                        className="absolute -left-8 top-1/2 text-4xl transform scale-x-[-1]"
                        initial={{ x: 0, opacity: 1 }}
                        animate={{ x: -30, opacity: 0 }}
                        transition={{ duration: 0.5, repeat: Infinity, repeatDelay: 0.3 }}
                      >
                        💥
                      </motion.div>
                    )}
                  </motion.div>
                  <div className="text-center">
                    <h2 className="text-2xl font-bold">{battle.opponent?.username}</h2>
                    <p className="text-muted-foreground">Level {battle.opponent?.level}</p>
                    {userVote && (
                      <div className="mt-2">
                        <p className="text-3xl font-bold text-primary">{Math.round(100 - creatorPercentage)}%</p>
                        <p className="text-sm text-muted-foreground">{battle.opponent_votes} votes</p>
                      </div>
                    )}
                  </div>
                </div>
              </div>

              {/* VS Badge in Center */}
              <motion.div 
                className="absolute top-1/3 left-1/2 transform -translate-x-1/2 -translate-y-1/2 z-30 hidden md:block"
                animate={{ 
                  rotate: [0, 360]
                }}
                transition={{ 
                  rotate: {
                    duration: 20,
                    repeat: Infinity,
                    ease: "linear"
                  }
                }}
              >
                <div className="w-32 h-32 bg-white border-4 border-black flex items-center justify-center transform rotate-45 shadow-hard-lime">
                  <motion.span
                    className="font-display text-5xl transform -rotate-45"
                    animate={{ scale: [1, 1.1, 1] }}
                    transition={{ duration: 1, repeat: Infinity }}
                  >
                    VS
                  </motion.span>
                </div>
              </motion.div>
            </div>

            {/* Audio Battle Cards - Grunge Style */}
            <div className="flex flex-col md:flex-row items-center justify-center gap-8 md:gap-0 relative max-w-6xl mx-auto px-4">
              {/* Creator Card (Left) */}
              <motion.div 
                className="w-full md:w-1/2 max-w-md transform md:-rotate-3 md:hover:rotate-0 transition-transform duration-300 z-10"
                initial={{ opacity: 0, x: -50 }}
                animate={{ opacity: 1, x: 0 }}
                transition={{ duration: 0.6 }}
              >
                <div className="bg-card border-4 border-black p-2 pb-8 shadow-hard-lime relative">
                  {/* Tape decoration */}
                  <div className="absolute -top-3 left-1/2 w-24 h-8 bg-white/40 tape transform -translate-x-1/2 z-10"></div>
                  
                  {/* Info Section */}
                  <div className="px-4 pt-4">
                    <h3 className="font-display text-3xl leading-none mb-1">{battle.creator?.username}</h3>
                    <p className="font-mono text-sm text-muted-foreground mb-4">Level {battle.creator?.level} // {battle.creator_votes} votes</p>
                    
                    {/* Audio Player */}
                    <div className="mb-6">
                      <ModernAudioPlayer
                        audioUrl={battle.creator_audio_url || ''}
                        color="primary"
                        onPlay={() => setCreatorAudioPlaying(true)}
                        onPause={() => setCreatorAudioPlaying(false)}
                        onEnded={() => setCreatorAudioPlaying(false)}
                      />
                    </div>

                    {/* Vote Button */}
                    <Button 
                      className="w-full"
                      variant={userVote?.voted_for === 'creator' ? 'victory' : 'default'}
                      onClick={() => voteMutation.mutate('creator')}
                      disabled={!user || voteMutation.isPending || isBattleFinished}
                    >
                      <ThumbsUp className="mr-2 h-4 w-4" />
                      {isBattleFinished ? 'BATTLE ENDED' : userVote?.voted_for === 'creator' ? 'VOTED!' : 'VOTE TRACK A'}
                    </Button>
                    
                    {/* Vote Stats */}
                    {userVote && (
                      <motion.div
                        initial={{ opacity: 0 }}
                        animate={{ opacity: 1 }}
                        className="mt-4 space-y-2"
                      >
                        <div className="w-full bg-black h-2 rounded-full overflow-hidden border border-white/20">
                          <motion.div 
                            initial={{ width: 0 }}
                            animate={{ width: `${creatorPercentage}%` }}
                            transition={{ duration: 1 }}
                            className="h-full bg-acid-lime"
                          />
                        </div>
                        <div className="flex justify-between font-mono text-xs text-muted-foreground">
                          <span>{Math.round(creatorPercentage)}% VOTES</span>
                        </div>
                      </motion.div>
                    )}
                  </div>
                </div>
              </motion.div>

              {/* Opponent Card (Right) */}
              <motion.div 
                className="w-full md:w-1/2 max-w-md transform md:rotate-3 md:hover:rotate-0 transition-transform duration-300 z-20 md:ml-[-20px]"
                initial={{ opacity: 0, x: 50 }}
                animate={{ opacity: 1, x: 0 }}
                transition={{ duration: 0.6, delay: 0.2 }}
              >
                <div className="bg-card border-4 border-black p-2 pb-8 shadow-hard-pink relative paper-tear-top">
                  {/* Sticker decoration */}
                  <div className="absolute -top-6 -right-4 z-30 w-20 h-20 bg-electric-blue rounded-full border-4 border-black flex items-center justify-center transform rotate-12">
                    <span className="text-3xl">⚡</span>
                  </div>

                  {/* Info Section */}
                  <div className="px-4 pt-4">
                    <h3 className="font-display text-3xl leading-none mb-1">{battle.opponent?.username}</h3>
                    <p className="font-mono text-sm text-muted-foreground mb-4">Level {battle.opponent?.level} // {battle.opponent_votes} votes</p>
                    
                    {/* Audio Player */}
                    <div className="mb-6">
                      <ModernAudioPlayer
                        audioUrl={battle.opponent_audio_url || ''}
                        color="secondary"
                        onPlay={() => setOpponentAudioPlaying(true)}
                        onPause={() => setOpponentAudioPlaying(false)}
                        onEnded={() => setOpponentAudioPlaying(false)}
                      />
                    </div>

                    {/* Vote Button */}
                    <Button 
                      className="w-full"
                      variant={userVote?.voted_for === 'opponent' ? 'victory' : 'destructive'}
                      onClick={() => voteMutation.mutate('opponent')}
                      disabled={!user || voteMutation.isPending || isBattleFinished}
                    >
                      <ThumbsUp className="mr-2 h-4 w-4" />
                      {isBattleFinished ? 'BATTLE ENDED' : userVote?.voted_for === 'opponent' ? 'VOTED!' : 'VOTE TRACK B'}
                    </Button>
                    
                    {/* Vote Stats */}
                    {userVote && (
                      <motion.div
                        initial={{ opacity: 0 }}
                        animate={{ opacity: 1 }}
                        className="mt-4 space-y-2"
                      >
                        <div className="w-full bg-black h-2 rounded-full overflow-hidden border border-white/20">
                          <motion.div 
                            initial={{ width: 0 }}
                            animate={{ width: `${100 - creatorPercentage}%` }}
                            transition={{ duration: 1 }}
                            className="h-full bg-punk-pink"
                          />
                        </div>
                        <div className="flex justify-between font-mono text-xs text-muted-foreground">
                          <span>{Math.round(100 - creatorPercentage)}% VOTES</span>
                        </div>
                      </motion.div>
                    )}
                  </div>
                </div>
              </motion.div>
            </div>
          </>
        )}

        {/* Comments Section */}
        <Card>
          <CardContent className="p-6">
            <h2 className="text-2xl font-bold mb-4">Comments</h2>
            
            {user && (
              <div className="flex gap-2 mb-6">
                <Textarea
                  placeholder="Share your thoughts on this battle..."
                  value={comment}
                  onChange={(e) => setComment(e.target.value)}
                  className="flex-1"
                />
                <Button 
                  onClick={() => commentMutation.mutate()}
                  disabled={commentMutation.isPending || !comment.trim()}
                >
                  {commentMutation.isPending ? (
                    <Loader2 className="h-4 w-4 animate-spin" />
                  ) : (
                    <Send className="h-4 w-4" />
                  )}
                </Button>
              </div>
            )}

            <div className="space-y-4">
              {commentsLoading ? (
                Array.from({ length: 3 }).map((_, i) => (
                  <Skeleton key={i} className="h-20 w-full" />
                ))
              ) : comments?.length === 0 ? (
                <p className="text-center text-muted-foreground py-8">
                  No comments yet. Be the first to comment!
                </p>
              ) : (
                comments?.map((c: any) => (
                  <div key={c.id} className="flex gap-3 p-4 bg-muted rounded-lg">
                    <Avatar>
                      <AvatarImage src={c.user?.avatar_url} />
                      <AvatarFallback>{c.user?.username?.[0]}</AvatarFallback>
                    </Avatar>
                    <div className="flex-1">
                      <p className="font-semibold">{c.user?.username}</p>
                      <p className="text-sm text-muted-foreground">{c.comment}</p>
                      <p className="text-xs text-muted-foreground mt-1">
                        {new Date(c.created_at).toLocaleDateString()}
                      </p>
                    </div>
                  </div>
                ))
              )}
            </div>
          </CardContent>
        </Card>
      </main>

      {/* Level Up Popup */}
      {levelUpData && (
        <LevelUpPopup
          open={!!levelUpData}
          onClose={() => setLevelUpData(null)}
          oldLevel={levelUpData.oldLevel}
          newLevel={levelUpData.newLevel}
          xpGained={levelUpData.xpGained}
          coinsGained={levelUpData.coinsGained}
          unlockedItems={levelUpData.unlockedItems}
        />
      )}
    </div>
  );
}
