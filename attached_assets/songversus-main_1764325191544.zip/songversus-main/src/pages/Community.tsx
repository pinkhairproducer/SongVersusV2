import { useState, useEffect, useRef } from "react";
import { MessageCircle, Send, Users } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { ScrollArea } from "@/components/ui/scroll-area";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar";
import { supabase } from "@/integrations/supabase/client";
import { useToast } from "@/hooks/use-toast";
import { motion } from "framer-motion";
import { Header } from "@/components/Header";

interface ChatMessage {
  id: string;
  user_id: string;
  username: string;
  message: string;
  created_at: string;
}

interface OnlineUser {
  user_id: string;
  username: string;
  avatar_url: string | null;
  online_at: string;
}

const Community = () => {
  const [messages, setMessages] = useState<ChatMessage[]>([]);
  const [newMessage, setNewMessage] = useState("");
  const [currentUser, setCurrentUser] = useState<{ id: string; username: string; avatar_url: string | null } | null>(null);
  const [onlineUsers, setOnlineUsers] = useState<OnlineUser[]>([]);
  const [userProfiles, setUserProfiles] = useState<Map<string, string | null>>(new Map());
  const { toast } = useToast();
  const scrollRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    const fetchUser = async () => {
      const { data: { user } } = await supabase.auth.getUser();
      if (user) {
        const { data: profile } = await supabase
          .from("profiles")
          .select("username, avatar_url")
          .eq("user_id", user.id)
          .single();
        
        if (profile) {
          setCurrentUser({ 
            id: user.id, 
            username: profile.username,
            avatar_url: profile.avatar_url 
          });
        }
      }
    };

    fetchUser();
  }, []);

  useEffect(() => {
    const fetchMessages = async () => {
      const { data, error } = await supabase
        .from("chat_messages")
        .select("*")
        .order("created_at", { ascending: true })
        .limit(100);

      if (error) {
        console.error("Error fetching messages:", error);
        return;
      }

      setMessages(data || []);
      
      // Fetch avatar URLs for all users in messages
      if (data && data.length > 0) {
        const userIds = [...new Set(data.map(msg => msg.user_id))];
        const { data: profiles } = await supabase
          .from("profiles")
          .select("user_id, avatar_url")
          .in("user_id", userIds);
        
        if (profiles) {
          const profileMap = new Map(profiles.map(p => [p.user_id, p.avatar_url]));
          setUserProfiles(profileMap);
        }
      }
    };

    fetchMessages();

    const channel = supabase
      .channel("chat_messages")
      .on(
        "postgres_changes",
        {
          event: "INSERT",
          schema: "public",
          table: "chat_messages",
        },
        async (payload) => {
          const newMsg = payload.new as ChatMessage;
          setMessages((prev) => [...prev, newMsg]);
          
          // Fetch avatar for new user if not already in map
          if (!userProfiles.has(newMsg.user_id)) {
            const { data: profile } = await supabase
              .from("profiles")
              .select("avatar_url")
              .eq("user_id", newMsg.user_id)
              .single();
            
            if (profile) {
              setUserProfiles(prev => new Map(prev).set(newMsg.user_id, profile.avatar_url));
            }
          }
        }
      )
      .subscribe();

    return () => {
      supabase.removeChannel(channel);
    };
  }, []);

  useEffect(() => {
    const channel = supabase.channel("community-presence");
    
    channel
      .on("presence", { event: "sync" }, () => {
        const state = channel.presenceState();
        const users: OnlineUser[] = [];
        
        Object.values(state).forEach((presences: any) => {
          presences.forEach((presence: any) => {
            users.push({
              user_id: presence.user_id,
              username: presence.username,
              avatar_url: presence.avatar_url,
              online_at: presence.online_at,
            });
          });
        });
        
        setOnlineUsers(users);
      })
      .subscribe(async (status) => {
        if (status === "SUBSCRIBED" && currentUser) {
          await channel.track({
            user_id: currentUser.id,
            username: currentUser.username,
            avatar_url: currentUser.avatar_url,
            online_at: new Date().toISOString(),
          });
        }
      });

    return () => {
      supabase.removeChannel(channel);
    };
  }, [currentUser]);

  useEffect(() => {
    if (scrollRef.current) {
      scrollRef.current.scrollIntoView({ behavior: "smooth" });
    }
  }, [messages]);

  const validateMessage = (msg: string): string | null => {
    const dangerousPatterns = /<script|javascript:|onerror=|onclick=/i;
    if (dangerousPatterns.test(msg)) {
      return 'Message contains invalid content';
    }
    return null;
  };

  const sendMessage = async () => {
    if (!currentUser) {
      toast({
        title: "Sign in required",
        description: "Please sign in to send messages",
        variant: "destructive",
      });
      return;
    }

    const MAX_MESSAGE_LENGTH = 500;
    const message = newMessage.trim();

    if (message.length === 0) {
      toast({
        title: "Error",
        description: "Message cannot be empty",
        variant: "destructive",
      });
      return;
    }

    if (message.length > MAX_MESSAGE_LENGTH) {
      toast({
        title: "Error",
        description: `Message too long (max ${MAX_MESSAGE_LENGTH} characters)`,
        variant: "destructive",
      });
      return;
    }

    const validationError = validateMessage(message);
    if (validationError) {
      toast({
        title: "Error",
        description: validationError,
        variant: "destructive",
      });
      return;
    }

    const { error } = await supabase.from("chat_messages").insert({
      user_id: currentUser.id,
      username: currentUser.username,
      message: message,
    });

    if (error) {
      toast({
        title: "Error",
        description: "Failed to send message",
        variant: "destructive",
      });
      return;
    }

    setNewMessage("");
  };

  const handleKeyPress = (e: React.KeyboardEvent) => {
    if (e.key === "Enter" && !e.shiftKey) {
      e.preventDefault();
      sendMessage();
    }
  };

  return (
    <div className="min-h-screen bg-background">
      <Header />
      
      <main className="container mx-auto px-4 pt-24 pb-8">
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.5 }}
          className="max-w-6xl mx-auto"
        >
          <div className="mb-8 text-center">
            <h1 className="text-4xl font-bold mb-2 text-glow">Community Hub</h1>
            <p className="text-muted-foreground">
              Connect with fellow artists and producers
            </p>
          </div>

          <div className="grid lg:grid-cols-4 gap-6">
            {/* Sidebar - Online Users */}
            <Card className="lg:col-span-1 border-primary/20 bg-card/50 backdrop-blur">
              <CardHeader>
                <CardTitle className="flex items-center gap-2 text-lg">
                  <Users className="h-5 w-5 text-primary" />
                  Online Now
                </CardTitle>
              </CardHeader>
              <CardContent>
                <div className="flex items-center gap-2 mb-4 pb-3 border-b border-border/50">
                  <div className="h-2 w-2 rounded-full bg-green-500 animate-pulse" />
                  <span className="text-2xl font-bold">{onlineUsers.length}</span>
                  <span className="text-muted-foreground text-sm">
                    {onlineUsers.length === 1 ? "user" : "users"}
                  </span>
                </div>
                
                <ScrollArea className="h-[500px]">
                  <div className="space-y-2">
                    {onlineUsers.length === 0 ? (
                      <p className="text-sm text-muted-foreground text-center py-4">
                        No users online
                      </p>
                    ) : (
                      onlineUsers.map((user) => (
                        <div
                          key={user.user_id}
                          className="flex items-center gap-2 p-2 rounded-lg hover:bg-accent/50 transition-colors"
                        >
                          <Avatar className="h-8 w-8 border-2 border-green-500/30">
                            {user.avatar_url && <AvatarImage src={user.avatar_url} alt={user.username} />}
                            <AvatarFallback className="bg-primary/10 text-primary text-xs">
                              {user.username[0].toUpperCase()}
                            </AvatarFallback>
                          </Avatar>
                          <div className="flex-1 min-w-0">
                            <p className="text-sm font-medium truncate">
                              {user.username}
                              {user.user_id === currentUser?.id && (
                                <span className="text-xs text-muted-foreground ml-1">(you)</span>
                              )}
                            </p>
                          </div>
                          <div className="h-2 w-2 rounded-full bg-green-500" />
                        </div>
                      ))
                    )}
                  </div>
                </ScrollArea>
              </CardContent>
            </Card>

            {/* Main Chat Area */}
            <Card className="lg:col-span-3 border-primary/20 bg-card/50 backdrop-blur">
              <CardHeader className="border-b bg-gradient-to-r from-primary/10 to-secondary/10">
                <CardTitle className="flex items-center gap-2">
                  <MessageCircle className="h-5 w-5 text-primary" />
                  Global Chat
                </CardTitle>
              </CardHeader>
              <CardContent className="p-0">
                <div className="flex flex-col h-[600px]">
                  <ScrollArea className="flex-1 p-6">
                    <div className="space-y-4">
                      {messages.length === 0 ? (
                        <div className="text-center text-muted-foreground py-12">
                          <MessageCircle className="h-12 w-12 mx-auto mb-4 opacity-50" />
                          <p>No messages yet. Start the conversation!</p>
                        </div>
                      ) : (
                        messages.map((msg) => (
                          <motion.div
                            key={msg.id}
                            initial={{ opacity: 0, y: 10 }}
                            animate={{ opacity: 1, y: 0 }}
                            className={`flex gap-3 ${
                              msg.user_id === currentUser?.id ? "justify-end" : "justify-start"
                            }`}
                          >
                            {msg.user_id !== currentUser?.id && (
                              <Avatar className="h-10 w-10 border-2 border-primary/20">
                                {userProfiles.get(msg.user_id) && (
                                  <AvatarImage src={userProfiles.get(msg.user_id)!} alt={msg.username} />
                                )}
                                <AvatarFallback className="bg-primary/10 text-primary">
                                  {msg.username[0].toUpperCase()}
                                </AvatarFallback>
                              </Avatar>
                            )}
                            <div
                              className={`flex flex-col max-w-[70%] ${
                                msg.user_id === currentUser?.id ? "items-end" : "items-start"
                              }`}
                            >
                              <span className="text-xs text-muted-foreground mb-1 px-1">
                                {msg.username}
                              </span>
                              <div
                                className={`rounded-2xl px-4 py-2 ${
                                  msg.user_id === currentUser?.id
                                    ? "bg-primary text-primary-foreground"
                                    : "bg-muted text-foreground"
                                }`}
                              >
                                <p className="text-sm break-words">{msg.message}</p>
                              </div>
                              <span className="text-xs text-muted-foreground mt-1 px-1">
                                {new Date(msg.created_at).toLocaleTimeString([], {
                                  hour: "2-digit",
                                  minute: "2-digit",
                                })}
                              </span>
                            </div>
                            {msg.user_id === currentUser?.id && (
                              <Avatar className="h-10 w-10 border-2 border-primary/20">
                                {currentUser.avatar_url && (
                                  <AvatarImage src={currentUser.avatar_url} alt={currentUser.username} />
                                )}
                                <AvatarFallback className="bg-primary text-primary-foreground">
                                  {msg.username[0].toUpperCase()}
                                </AvatarFallback>
                              </Avatar>
                            )}
                          </motion.div>
                        ))
                      )}
                      <div ref={scrollRef} />
                    </div>
                  </ScrollArea>

                  <div className="p-4 border-t bg-background/50 backdrop-blur">
                    {currentUser ? (
                      <>
                        <div className="flex gap-2">
                          <Input
                            value={newMessage}
                            onChange={(e) => setNewMessage(e.target.value)}
                            onKeyPress={handleKeyPress}
                            placeholder="Type a message..."
                            className="flex-1"
                            maxLength={500}
                          />
                          <Button
                            onClick={sendMessage}
                            size="icon"
                            disabled={!newMessage.trim()}
                            className="shrink-0"
                          >
                            <Send className="h-4 w-4" />
                          </Button>
                        </div>
                        <p className="text-xs text-muted-foreground mt-2">
                          ⚠️ This is a public chat. All messages are visible to everyone.
                        </p>
                      </>
                    ) : (
                      <div className="text-center py-4">
                        <p className="text-muted-foreground mb-3">
                          Sign in to join the conversation
                        </p>
                        <Button onClick={() => window.location.href = "/auth"}>
                          Sign In
                        </Button>
                      </div>
                    )}
                  </div>
                </div>
              </CardContent>
            </Card>
          </div>
        </motion.div>
      </main>
    </div>
  );
};

export default Community;
