import { Button } from "@/components/ui/button";
import { Header } from "@/components/Header";
import { ArrowRight, Headphones, Mic, Sparkles, Zap, Trophy, Swords } from "lucide-react";
import { Link, useNavigate } from "react-router-dom";
import { toast } from "sonner";
import heroBattle from "@/assets/hero-battle-optimized.jpg";
import battleArena from "@/assets/battle-arena.jpg";
import { motion } from "framer-motion";

const Index = () => {
  const navigate = useNavigate();

  const handleEnterArena = () => {
    navigate('/battles');
  };

  const handleWatchBattles = () => {
    navigate('/battles');
  };

  const handleBecomeProducer = () => {
    toast.success("Producer mode activated! Upload your first beat to start battling.", {
      description: "Authentication required - coming soon!"
    });
  };

  const handleBecomeArtist = () => {
    toast.success("Artist mode activated! Upload your first track to start battling.", {
      description: "Authentication required - coming soon!"
    });
  };

  return (
    <div className="min-h-screen bg-background">
      <Header />
      
      {/* Hero Section */}
      <section className="relative min-h-screen flex items-center justify-center overflow-hidden pt-16">
        <div className="absolute inset-0 z-0">
          <img 
            src={heroBattle} 
            alt="Battle Arena" 
            width="1920"
            height="1080"
            className="w-full h-full object-cover opacity-40"
          />
          <div className="absolute inset-0 bg-gradient-to-b from-background/50 via-background/80 to-background" />
          
          {/* Animated background elements */}
          <motion.div
            className="absolute top-1/4 left-1/4 w-64 h-64 bg-primary/20 rounded-full blur-3xl"
            animate={{
              x: [0, 100, 0],
              y: [0, -50, 0],
              scale: [1, 1.2, 1],
            }}
            transition={{
              duration: 8,
              repeat: Infinity,
              ease: "easeInOut"
            }}
          />
          <motion.div
            className="absolute bottom-1/4 right-1/4 w-96 h-96 bg-secondary/20 rounded-full blur-3xl"
            animate={{
              x: [0, -80, 0],
              y: [0, 60, 0],
              scale: [1, 1.3, 1],
            }}
            transition={{
              duration: 10,
              repeat: Infinity,
              ease: "easeInOut"
            }}
          />
          <motion.div
            className="absolute top-1/2 right-1/3 w-48 h-48 bg-primary/30 rounded-full blur-2xl"
            animate={{
              x: [0, -60, 0],
              y: [0, 80, 0],
            }}
            transition={{
              duration: 6,
              repeat: Infinity,
              ease: "easeInOut"
            }}
          />
        </div>
        
        <div className="container relative z-10 px-4 py-20">
          <div className="max-w-4xl mx-auto text-center space-y-8">
            <motion.div 
              className="inline-block"
              initial={{ opacity: 0, y: -20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.6 }}
            >
              <span className="text-sm uppercase tracking-wider text-primary font-bold bg-primary/10 px-4 py-2 rounded-full border border-primary/30">
                Where sound becomes battle
              </span>
            </motion.div>
            
            <motion.h1 
              className="text-6xl md:text-8xl font-black leading-tight text-white"
              initial={{ opacity: 0, scale: 0.9 }}
              animate={{ opacity: 1, scale: 1 }}
              transition={{ duration: 0.8, delay: 0.2 }}
              style={{ textShadow: '0 0 30px rgba(255,255,255,0.3)' }}
            >
              SONG<span className="text-secondary" style={{ textShadow: '0 0 30px hsl(340, 70%, 60%)' }}>VERSUS</span>
            </motion.h1>
            
            <motion.p 
              className="text-xl md:text-2xl text-foreground/80 max-w-2xl mx-auto leading-relaxed"
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.6, delay: 0.4 }}
            >
              Welcome to the arena where artists and producers don't just make music… 
              <span className="text-foreground font-semibold"> they fight with it.</span>
            </motion.p>

            <motion.div 
              className="flex flex-col sm:flex-row gap-4 justify-center items-center pt-8"
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.6, delay: 0.6 }}
            >
              <Button variant="battle" size="xl" className="group" onClick={handleEnterArena}>
                Enter the Arena
                <ArrowRight className="ml-2 h-5 w-5 group-hover:translate-x-1 transition-transform" />
              </Button>
              <Button 
                variant="battle" 
                size="xl" 
                className="relative group overflow-hidden border-2 border-primary shadow-lg shadow-primary/50 animate-pulse-slow"
                onClick={() => navigate('/store')}
              >
                <span className="relative z-10 flex items-center gap-2 font-bold">
                  <Sparkles className="h-5 w-5 animate-spin" />
                  Upgrade Now
                  <Sparkles className="h-5 w-5 animate-spin" style={{ animationDirection: 'reverse' }} />
                </span>
                <motion.div
                  className="absolute inset-0 bg-gradient-to-r from-primary via-secondary to-primary opacity-30"
                  animate={{
                    x: ['-100%', '100%'],
                  }}
                  transition={{
                    duration: 1.5,
                    repeat: Infinity,
                    ease: "linear",
                  }}
                />
              </Button>
            </motion.div>

            <motion.div 
              className="grid grid-cols-1 sm:grid-cols-3 gap-4 sm:gap-8 pt-12 max-w-2xl mx-auto"
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              transition={{ duration: 0.8, delay: 0.8 }}
            >
              <div className="text-center">
                <div className="text-2xl sm:text-3xl font-bold text-primary">10K+</div>
                <div className="text-xs sm:text-sm text-foreground/70">Active Battles</div>
              </div>
              <div className="text-center">
                <div className="text-2xl sm:text-3xl font-bold text-secondary">50K+</div>
                <div className="text-xs sm:text-sm text-foreground/70">Artists</div>
              </div>
              <div className="text-center">
                <div className="text-2xl sm:text-3xl font-bold text-[hsl(var(--success))]">75K+</div>
                <div className="text-xs sm:text-sm text-foreground/70">Producers</div>
              </div>
            </motion.div>
          </div>
        </div>
      </section>

      {/* Choose Your Path */}
      <section className="py-20 relative">
        <div className="container px-4">
          <div className="text-center mb-16">
            <h2 className="text-4xl md:text-6xl font-black mb-4 text-white">
              CHOOSE YOUR <span className="text-primary" style={{ textShadow: '0 0 30px hsl(74, 65%, 55%)' }}>PATH</span>
            </h2>
            <p className="text-xl text-foreground/80 max-w-2xl mx-auto">
              Every player spawns as a blank slate. Choose your weapon, define your style.
            </p>
          </div>

          <div className="grid md:grid-cols-2 gap-8 max-w-5xl mx-auto">
            {/* Producer Card */}
            <motion.div 
              className="group relative bg-card border border-border rounded-2xl p-8 hover:border-primary/50 transition-all hover:shadow-[0_0_40px_hsl(var(--primary)/0.2)]"
              initial={{ opacity: 0, x: -50 }}
              whileInView={{ opacity: 1, x: 0 }}
              viewport={{ once: true }}
              transition={{ duration: 0.6 }}
              whileHover={{ scale: 1.02 }}
            >
              <div className="absolute top-0 right-0 w-32 h-32 bg-primary/10 rounded-full blur-3xl group-hover:bg-primary/20 transition-all" />
              <div className="relative space-y-4">
                <div className="w-16 h-16 rounded-xl bg-primary/20 flex items-center justify-center">
                  <Headphones className="h-8 w-8 text-primary" />
                </div>
                <h3 className="text-3xl font-bold">PRODUCER</h3>
                <p className="text-foreground/80">
                  Enter the Beat Battles, sculpting sonic weapons from drums, bass, and synths. 
                  Your arsenal: rhythm, melody, and raw creativity.
                </p>
                <div className="flex flex-wrap gap-2 pt-4">
                  <span className="text-xs px-3 py-1 rounded-full bg-primary/20 text-primary border border-primary/30">
                    Beat Making
                  </span>
                  <span className="text-xs px-3 py-1 rounded-full bg-primary/20 text-primary border border-primary/30">
                    Production
                  </span>
                  <span className="text-xs px-3 py-1 rounded-full bg-primary/20 text-primary border border-primary/30">
                    Sound Design
                  </span>
                </div>
                <Button variant="default" className="w-full mt-4" size="lg" onClick={handleBecomeProducer}>
                  Become a Producer
                </Button>
              </div>
            </motion.div>

            {/* Artist Card */}
            <motion.div 
              className="group relative bg-card border border-border rounded-2xl p-8 hover:border-secondary/50 transition-all hover:shadow-[0_0_40px_hsl(var(--secondary)/0.2)]"
              initial={{ opacity: 0, x: 50 }}
              whileInView={{ opacity: 1, x: 0 }}
              viewport={{ once: true }}
              transition={{ duration: 0.6 }}
              whileHover={{ scale: 1.02 }}
            >
              <div className="absolute top-0 right-0 w-32 h-32 bg-secondary/10 rounded-full blur-3xl group-hover:bg-secondary/20 transition-all" />
              <div className="relative space-y-4">
                <div className="w-16 h-16 rounded-xl bg-secondary/20 flex items-center justify-center">
                  <Mic className="h-8 w-8 text-secondary" />
                </div>
                <h3 className="text-3xl font-bold">ARTIST</h3>
                <p className="text-foreground/80">
                  Step into Song Battles, armed with vocals, lyrics, and hooks that kill. 
                  Your power: storytelling, emotion, and unforgettable melodies.
                </p>
                <div className="flex flex-wrap gap-2 pt-4">
                  <span className="text-xs px-3 py-1 rounded-full bg-secondary/20 text-secondary border border-secondary/30">
                    Vocals
                  </span>
                  <span className="text-xs px-3 py-1 rounded-full bg-secondary/20 text-secondary border border-secondary/30">
                    Songwriting
                  </span>
                  <span className="text-xs px-3 py-1 rounded-full bg-secondary/20 text-secondary border border-secondary/30">
                    Performance
                  </span>
                </div>
                <Button variant="secondary" className="w-full mt-4" size="lg" onClick={handleBecomeArtist}>
                  Become an Artist
                </Button>
              </div>
            </motion.div>
          </div>

          <p className="text-center text-foreground/80 mt-8">
            Switch roles anytime. <span className="text-foreground font-semibold">Be both. Be unstoppable.</span>
          </p>
        </div>
      </section>

      {/* Battle System */}
      <section className="py-20 relative">
        <div className="absolute inset-0 z-0">
          <img 
            src={battleArena} 
            alt="Battle visualization"
            width="1920"
            height="844"
            loading="lazy"
            className="w-full h-full object-cover opacity-20"
          />
          <div className="absolute inset-0 bg-gradient-to-b from-background via-background/95 to-background" />
        </div>

        <div className="container px-4 relative z-10">
          <div className="text-center mb-16">
            <h2 className="text-4xl md:text-6xl font-black mb-4 text-white">
              THE <span className="text-secondary" style={{ textShadow: '0 0 30px hsl(340, 70%, 60%)' }}>BATTLE</span> SYSTEM
            </h2>
            <p className="text-xl text-foreground/80 max-w-2xl mx-auto">
              Every track uploaded is a challenge. Every challenge becomes a showdown.
            </p>
          </div>

          <div className="grid md:grid-cols-3 gap-8 max-w-6xl mx-auto">
            <motion.div 
              className="bg-card/80 backdrop-blur-sm border border-border rounded-xl p-6 space-y-4"
              initial={{ opacity: 0, y: 50 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              transition={{ duration: 0.5, delay: 0.1 }}
              whileHover={{ y: -5 }}
            >
              <div className="w-12 h-12 rounded-lg bg-primary/20 flex items-center justify-center">
                <Zap className="h-6 w-6 text-primary" />
              </div>
              <h3 className="text-xl font-bold">Live Voting</h3>
              <p className="text-foreground/80">
                The community decides. One click, one vote. When the clock hits zero, the victor rises.
              </p>
            </motion.div>

            <motion.div 
              className="bg-card/80 backdrop-blur-sm border border-border rounded-xl p-6 space-y-4"
              initial={{ opacity: 0, y: 50 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              transition={{ duration: 0.5, delay: 0.2 }}
              whileHover={{ y: -5 }}
            >
              <div className="w-12 h-12 rounded-lg bg-secondary/20 flex items-center justify-center">
                <Sparkles className="h-6 w-6 text-secondary" />
              </div>
              <h3 className="text-xl font-bold">Visual Showdown</h3>
              <p className="text-foreground/80">
                Dual waveforms. Cinematic avatars. Every battle gets its own arena page.
              </p>
            </motion.div>

            <motion.div 
              className="bg-card/80 backdrop-blur-sm border border-border rounded-xl p-6 space-y-4"
              initial={{ opacity: 0, y: 50 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              transition={{ duration: 0.5, delay: 0.3 }}
              whileHover={{ y: -5 }}
            >
              <div className="w-12 h-12 rounded-lg bg-[hsl(var(--success))]/20 flex items-center justify-center">
                <Trophy className="h-6 w-6 text-[hsl(var(--success))]" />
              </div>
              <h3 className="text-xl font-bold">Level Up</h3>
              <p className="text-foreground/80">
                Win battles, earn XP and coins. Unlock Orbs filled with rare skins and effects.
              </p>
            </motion.div>
          </div>
        </div>
      </section>

      {/* CTA Section */}
      <section className="py-20">
        <div className="container px-4">
          <div className="max-w-4xl mx-auto bg-gradient-to-r from-primary/10 via-secondary/10 to-primary/10 border border-primary/30 rounded-3xl p-12 text-center space-y-6">
            <h2 className="text-4xl md:text-5xl font-black text-white">
              WELCOME TO THE <span className="text-primary" style={{ textShadow: '0 0 30px hsl(74, 65%, 55%)' }}>NOISE</span>
            </h2>
            <p className="text-xl text-foreground/80 max-w-2xl mx-auto">
              SongVersus isn't just a platform. It's a movement — half art, half warfare. 
              Built for the bold, the curious, the ones who hear sound as a weapon.
            </p>
            <div className="flex flex-col sm:flex-row gap-4 justify-center pt-6">
              <Button variant="battle" size="xl" onClick={handleEnterArena}>
                Plug In. Power Up.
              </Button>
              <Link to="/leaderboard">
                <Button variant="outline" size="xl">
                  View Leaderboards
                </Button>
              </Link>
            </div>
          </div>
        </div>
      </section>

      {/* Footer */}
      <footer className="border-t border-border py-12">
        <div className="container px-4">
          <div className="flex flex-col md:flex-row justify-between items-center gap-4">
            <div className="flex items-center gap-2">
              <Swords className="h-6 w-6 text-primary" />
              <span className="font-bold text-xl">SONGVERSUS</span>
            </div>
            <p className="text-foreground/70 text-sm">
              Where sound becomes battle. © 2025 SongVersus. All rights reserved.
            </p>
          </div>
        </div>
      </footer>
    </div>
  );
};

export default Index;
