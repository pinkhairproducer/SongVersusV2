import { useState, useEffect } from "react";
import { useParams, useNavigate } from "react-router-dom";
import { supabase } from "@/integrations/supabase/client";
import { Header } from "@/components/Header";
import { EditProfileDialog } from "@/components/EditProfileDialog";
import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Avatar, AvatarImage, AvatarFallback } from "@/components/ui/avatar";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Skeleton } from "@/components/ui/skeleton";
import { Trophy, Swords, Target, Star, ArrowLeft } from "lucide-react";
import { toast } from "sonner";
import { CharacterDisplay } from "@/components/CharacterDisplay";
import { formatDistanceToNow } from "date-fns";

interface Profile {
  id: string;
  user_id: string;
  username: string;
  bio: string | null;
  role: string;
  level: number;
  xp: number;
  coins: number;
  battles_won: number;
  battles_lost: number;
  avatar_url: string | null;
  created_at: string;
}

interface Battle {
  id: string;
  status: string;
  genre: string;
  battle_type: string;
  created_at: string;
  creator_votes: number;
  opponent_votes: number;
  creator_id: string;
  opponent_id: string;
}

interface Orb {
  id: string;
  rarity: string;
  can_open_at: string;
  is_opened: boolean;
  created_at: string;
}

interface Customization {
  id: string;
  customization_item_id: string;
  is_equipped: boolean;
  customization_items: {
    id: string;
    name: string;
    category: string;
    rarity: string;
    description: string;
    required_level: number;
    evolved_from: string | null;
    evolution_tier: string;
  };
}

export default function Profile() {
  const { userId } = useParams();
  const navigate = useNavigate();
  const [profile, setProfile] = useState<Profile | null>(null);
  const [recentBattles, setRecentBattles] = useState<Battle[]>([]);
  const [loading, setLoading] = useState(true);
  const [currentUser, setCurrentUser] = useState<string | null>(null);
  const [editDialogOpen, setEditDialogOpen] = useState(false);
  const [orbs, setOrbs] = useState<Orb[]>([]);
  const [customizations, setCustomizations] = useState<Customization[]>([]);

  useEffect(() => {
    loadProfile();
  }, [userId]);

  const loadProfile = async () => {
    try {
      // Get current user
      const { data: { session } } = await supabase.auth.getSession();
      setCurrentUser(session?.user?.id || null);

      // Load profile
      const { data: profileData, error: profileError } = await supabase
        .from("profiles")
        .select("*")
        .eq("user_id", userId || session?.user?.id)
        .single();

      if (profileError) throw profileError;
      setProfile(profileData);

      // Load recent battles
      const { data: battlesData, error: battlesError } = await supabase
        .from("battles")
        .select("*")
        .or(`creator_id.eq.${profileData.user_id},opponent_id.eq.${profileData.user_id}`)
        .order("created_at", { ascending: false })
        .limit(10);

      if (battlesError) throw battlesError;
      setRecentBattles(battlesData || []);

      // Load orbs and customizations if viewing own profile
      if (session?.user?.id === profileData.user_id) {
        const { data: orbsData } = await supabase
          .from("orbs")
          .select("*")
          .eq("user_id", profileData.user_id)
          .eq("is_opened", false)
          .order("created_at", { ascending: false });

        const { data: customizationsData } = await supabase
          .from("user_customizations")
          .select(`
            *,
            customization_items (
              id,
              name,
              category,
              rarity,
              description,
              required_level,
              evolved_from,
              evolution_tier
            )
          `)
          .eq("user_id", profileData.user_id);

        setOrbs(orbsData || []);
        setCustomizations(customizationsData || []);
      }
    } catch (error: any) {
      toast.error("Failed to load profile", {
        description: error.message
      });
      navigate("/");
    } finally {
      setLoading(false);
    }
  };

  const getBattleResult = (battle: Battle) => {
    if (battle.status !== "completed") return null;
    
    const isCreator = battle.creator_id === profile?.user_id;
    const userVotes = isCreator ? battle.creator_votes : battle.opponent_votes;
    const opponentVotes = isCreator ? battle.opponent_votes : battle.creator_votes;
    
    if (userVotes > opponentVotes) return "victory";
    if (userVotes < opponentVotes) return "defeat";
    return "draw";
  };

  const calculateWinRate = () => {
    if (!profile) return 0;
    const total = profile.battles_won + profile.battles_lost;
    if (total === 0) return 0;
    return Math.round((profile.battles_won / total) * 100);
  };

  const handleOpenOrb = async (orb: Orb) => {
    const canOpen = new Date(orb.can_open_at) <= new Date();
    
    if (!canOpen) {
      const timeLeft = formatDistanceToNow(new Date(orb.can_open_at));
      toast.error("Orb locked", {
        description: `This orb can be opened in ${timeLeft}`
      });
      return;
    }

    const { data: { session } } = await supabase.auth.getSession();
    if (!session) return;

    // Get random unlockable item
    const { data: availableItems } = await supabase
      .from("customization_items")
      .select("id")
      .eq("is_starter", false);

    if (!availableItems || availableItems.length === 0) {
      toast.error("No items available");
      return;
    }

    const randomItem = availableItems[Math.floor(Math.random() * availableItems.length)];

    // Add to user customizations
    const { error: insertError } = await supabase
      .from("user_customizations")
      .insert({
        user_id: session.user.id,
        customization_item_id: randomItem.id,
        is_equipped: false,
      });

    if (insertError && !insertError.message.includes("duplicate")) {
      toast.error("Error opening orb");
      return;
    }

    // Mark orb as opened
    await supabase
      .from("orbs")
      .update({ is_opened: true, opened_at: new Date().toISOString() })
      .eq("id", orb.id);

    toast.success("Orb opened! New customization unlocked!");
    loadProfile();
  };

  const toggleEquip = async (customization: Customization) => {
    const { data: { session } } = await supabase.auth.getSession();
    if (!session) return;

    const { error } = await supabase
      .from("user_customizations")
      .update({ is_equipped: !customization.is_equipped })
      .eq("id", customization.id);

    if (error) {
      toast.error("Error updating customization");
      return;
    }

    loadProfile();
  };

  const isOwnProfile = currentUser === profile?.user_id;

  if (loading) {
    return (
      <div className="min-h-screen bg-background">
        <Header />
        <main className="container mx-auto px-4 py-8 max-w-6xl">
          <Skeleton className="h-96 w-full" />
        </main>
      </div>
    );
  }

  if (!profile) {
    return (
      <div className="min-h-screen bg-background">
        <Header />
        <main className="container mx-auto px-4 py-8 text-center">
          <h1 className="text-4xl font-bold mb-4">Profile Not Found</h1>
          <Button onClick={() => navigate("/")}>Go Home</Button>
        </main>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-background">
      <Header />
      
      <main className="container mx-auto px-2 sm:px-4 py-4 sm:py-8 max-w-6xl">
        <Button
          variant="ghost"
          size="sm"
          onClick={() => navigate(-1)}
          className="mb-6"
        >
          <ArrowLeft className="mr-2 h-4 w-4" />
          Back
        </Button>

        {/* Profile Header */}
        <Card className="mb-8">
          <CardContent className="p-4 sm:p-8">
            <div className="flex flex-col items-center gap-6">
              {/* Avatar and Basic Info */}
              <div className="flex flex-col items-center text-center w-full">
                <Avatar className="h-24 w-24 sm:h-32 sm:w-32 border-4 border-primary mb-4">
                  <AvatarImage src={profile.avatar_url || ""} />
                  <AvatarFallback className="text-3xl sm:text-4xl bg-primary/20">
                    {profile.username?.[0]?.toUpperCase() || "?"}
                  </AvatarFallback>
                </Avatar>
                
                <h1 className="text-3xl sm:text-4xl font-bold mb-2">{profile.username}</h1>
                
                {profile.bio && (
                  <p className="text-muted-foreground mb-4 max-w-md px-4">
                    {profile.bio}
                  </p>
                )}
                
                <div className="flex flex-wrap gap-2 justify-center mb-4">
                  <Badge variant="outline" className="capitalize">
                    {profile.role}
                  </Badge>
                  <Badge variant="secondary">
                    Level {profile.level}
                  </Badge>
                </div>
                
                {isOwnProfile && (
                  <Button variant="outline" onClick={() => setEditDialogOpen(true)}>
                    Edit Profile
                  </Button>
                )}
              </div>

              {/* Stats Grid */}
              <div className="grid grid-cols-3 gap-4 sm:gap-8 w-full max-w-md">
                <div className="text-center">
                  <Trophy className="h-6 w-6 sm:h-8 sm:w-8 mx-auto mb-2 text-primary" />
                  <p className="text-xl sm:text-2xl font-bold">{profile.battles_won}</p>
                  <p className="text-xs text-muted-foreground">Wins</p>
                </div>
                <div className="text-center">
                  <Swords className="h-6 w-6 sm:h-8 sm:w-8 mx-auto mb-2 text-destructive" />
                  <p className="text-xl sm:text-2xl font-bold">{profile.battles_lost}</p>
                  <p className="text-xs text-muted-foreground">Losses</p>
                </div>
                <div className="text-center">
                  <Target className="h-6 w-6 sm:h-8 sm:w-8 mx-auto mb-2 text-secondary" />
                  <p className="text-xl sm:text-2xl font-bold">{calculateWinRate()}%</p>
                  <p className="text-xs text-muted-foreground">Win Rate</p>
                </div>
              </div>
            </div>
          </CardContent>
        </Card>

        {/* Stats Grid */}
        <div className="grid grid-cols-1 md:grid-cols-3 gap-6 mb-8">
          <Card>
            <CardContent className="p-6 text-center">
              <Star className="h-8 w-8 mx-auto mb-2 text-primary" />
              <p className="text-3xl font-bold text-glow">{profile.xp}</p>
              <p className="text-sm text-muted-foreground">Experience Points</p>
            </CardContent>
          </Card>
          
          <Card>
            <CardContent className="p-6 text-center">
              <div className="text-3xl mb-2">🪙</div>
              <p className="text-3xl font-bold text-glow">{profile.coins}</p>
              <p className="text-sm text-muted-foreground">Coins</p>
            </CardContent>
          </Card>
          
          <Card>
            <CardContent className="p-6 text-center">
              <Trophy className="h-8 w-8 mx-auto mb-2 text-secondary" />
              <p className="text-3xl font-bold text-glow">
                {profile.battles_won + profile.battles_lost}
              </p>
              <p className="text-sm text-muted-foreground">Total Battles</p>
            </CardContent>
          </Card>
        </div>

        {/* Tabs Section */}
        <Tabs defaultValue="battles" className="w-full">
          <TabsList className={`grid w-full ${isOwnProfile ? 'grid-cols-2 sm:grid-cols-4' : 'grid-cols-1'} mb-6`}>
            <TabsTrigger value="battles" className="text-xs sm:text-sm">Recent Battles</TabsTrigger>
            {isOwnProfile && (
              <>
                <TabsTrigger value="stash" className="text-xs sm:text-sm">Character</TabsTrigger>
                <TabsTrigger value="orbs" className="text-xs sm:text-sm">Orbs ({orbs.length})</TabsTrigger>
                <TabsTrigger value="customizations" className="text-xs sm:text-sm">Items ({customizations.length})</TabsTrigger>
              </>
            )}
          </TabsList>

          <TabsContent value="battles">
            <Card>
              <CardContent className="p-6">
                <h2 className="text-2xl font-bold mb-6">Recent Battles</h2>
                
                {recentBattles.length === 0 ? (
                  <div className="text-center py-12">
                    <Swords className="h-16 w-16 mx-auto mb-4 text-muted-foreground" />
                    <p className="text-muted-foreground">No battles yet</p>
                  </div>
                ) : (
                  <div className="space-y-4">
                    {recentBattles.map((battle) => {
                      const result = getBattleResult(battle);
                      
                      return (
                        <div
                          key={battle.id}
                          onClick={() => navigate(`/battle/${battle.id}`)}
                          className="p-4 border border-border rounded-lg hover:border-primary/50 transition-colors cursor-pointer"
                        >
                          <div className="flex items-center justify-between">
                            <div>
                              <p className="font-semibold capitalize">
                                {battle.battle_type} Battle
                              </p>
                              <p className="text-sm text-muted-foreground">
                                {battle.genre || "Various"} • {new Date(battle.created_at).toLocaleDateString()}
                              </p>
                            </div>
                            
                            <div className="flex items-center gap-4">
                              <Badge
                                variant={
                                  battle.status === "ongoing" ? "default" :
                                  battle.status === "completed" ? "secondary" :
                                  "outline"
                                }
                                className="capitalize"
                              >
                                {battle.status}
                              </Badge>
                              
                              {result && (
                                <Badge
                                  variant={
                                    result === "victory" ? "default" :
                                    result === "defeat" ? "destructive" :
                                    "secondary"
                                  }
                                  className="capitalize"
                                >
                                  {result}
                                </Badge>
                              )}
                            </div>
                          </div>
                        </div>
                      );
                    })}
                  </div>
                )}
              </CardContent>
            </Card>
          </TabsContent>

          {isOwnProfile && (
            <>
              <TabsContent value="stash">
                <Card className="p-8 bg-card/80 backdrop-blur-lg border-primary/20">
                  <h2 className="text-2xl font-bold text-center mb-6">Your Fighter</h2>
                  <div className="flex justify-center">
                    <CharacterDisplay userId={profile.user_id} size="lg" />
                  </div>
                </Card>
              </TabsContent>

              <TabsContent value="orbs">
                <Card>
                  <CardContent className="p-6">
                    <div className="grid grid-cols-1 md:grid-cols-3 lg:grid-cols-4 gap-6">
                      {orbs.length === 0 ? (
                        <div className="col-span-full text-center py-12">
                          <p className="text-muted-foreground">No orbs yet. Win 5 battles to earn one!</p>
                        </div>
                      ) : (
                        orbs.map((orb) => {
                          const canOpen = new Date(orb.can_open_at) <= new Date();
                          const timeLeft = canOpen ? null : formatDistanceToNow(new Date(orb.can_open_at));

                          return (
                            <Card
                              key={orb.id}
                              className="p-6 bg-card/80 backdrop-blur-lg border-primary/20 text-center hover:border-primary/50 transition-all"
                            >
                              <div className="mb-4">
                                <div className="w-24 h-24 mx-auto bg-gradient-to-br from-primary to-secondary rounded-full animate-pulse-slow flex items-center justify-center">
                                  <span className="text-5xl">🔮</span>
                                </div>
                              </div>
                              <Badge className="mb-2 capitalize">{orb.rarity}</Badge>
                              {canOpen ? (
                                <Button
                                  variant="battle"
                                  size="sm"
                                  className="w-full mt-2"
                                  onClick={() => handleOpenOrb(orb)}
                                >
                                  Open Orb
                                </Button>
                              ) : (
                                <p className="text-xs text-muted-foreground mt-2">
                                  Opens in {timeLeft}
                                </p>
                              )}
                            </Card>
                          );
                        })
                      )}
                    </div>
                  </CardContent>
                </Card>
              </TabsContent>

              <TabsContent value="customizations">
                <Card>
                  <CardContent className="p-6">
                    <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
                      {customizations.length === 0 ? (
                        <div className="col-span-full text-center py-12">
                          <p className="text-muted-foreground">No customizations yet.</p>
                        </div>
                      ) : (
                        customizations.map((custom) => {
                          const canEvolve = customizations.some(
                            c => c.customization_items.evolved_from === custom.customization_items.id
                          );
                          const evolvedItem = customizations.find(
                            c => c.customization_items.evolved_from === custom.customization_items.id
                          );
                          
                          return (
                            <Card
                              key={custom.id}
                              className={`p-6 bg-card/80 backdrop-blur-lg border-2 transition-all ${
                                custom.is_equipped
                                  ? "border-primary"
                                  : "border-primary/20 hover:border-primary/50"
                              }`}
                            >
                              <div className="aspect-square bg-background/50 rounded mb-4 flex items-center justify-center">
                                <span className="text-6xl">🎭</span>
                              </div>
                              <h3 className="font-bold mb-1">{custom.customization_items.name}</h3>
                              <p className="text-sm text-muted-foreground mb-2">
                                {custom.customization_items.description}
                              </p>
                              <div className="flex gap-2 mb-3">
                                <Badge variant="secondary" className="capitalize">
                                  {custom.customization_items.category}
                                </Badge>
                                <Badge className="capitalize">
                                  {custom.customization_items.rarity}
                                </Badge>
                              </div>
                              
                              {/* Evolution info */}
                              {canEvolve && evolvedItem && (
                                <div className="mb-3 p-2 bg-primary/10 rounded text-xs">
                                  <p className="text-muted-foreground">
                                    Can evolve to: <span className="text-primary font-bold">
                                      {evolvedItem.customization_items.name}
                                    </span>
                                  </p>
                                  <p className="text-muted-foreground">
                                    Required: Level {evolvedItem.customization_items.required_level}
                                  </p>
                                </div>
                              )}
                              
                              <Button
                                variant={custom.is_equipped ? "victory" : "outline"}
                                size="sm"
                                className="w-full"
                                onClick={() => toggleEquip(custom)}
                              >
                                {custom.is_equipped ? "Equipped" : "Equip"}
                              </Button>
                            </Card>
                          );
                        })
                      )}
                    </div>
                  </CardContent>
                </Card>
              </TabsContent>
            </>
          )}
        </Tabs>
      </main>

      {/* Edit Profile Dialog */}
      {profile && (
        <EditProfileDialog
          open={editDialogOpen}
          onOpenChange={setEditDialogOpen}
          profile={profile}
          onProfileUpdated={loadProfile}
        />
      )}
    </div>
  );
}
