import { useNavigate } from "react-router-dom";
import { Header } from "@/components/Header";
import { Button } from "@/components/ui/button";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Avatar, AvatarFallback } from "@/components/ui/avatar";
import { Trophy, Crown, Zap, TrendingUp } from "lucide-react";
import { toast } from "sonner";
import { supabase } from "@/integrations/supabase/client";
import { useQuery } from "@tanstack/react-query";
import { Skeleton } from "@/components/ui/skeleton";
import { motion } from "framer-motion";

const genreTabs = ["All", "Hip-Hop", "Electronic", "Pop", "Trap", "R&B"];

const Leaderboard = () => {
  const navigate = useNavigate();

  const { data: leaders, isLoading } = useQuery({
    queryKey: ["leaderboard"],
    queryFn: async () => {
      const { data, error } = await supabase
        .from("profiles")
        .select("*")
        .order("battles_won", { ascending: false })
        .limit(50);

      if (error) throw error;
      
      return data?.map((profile, index) => ({
        rank: index + 1,
        userId: profile.user_id,
        name: profile.username,
        wins: profile.battles_won,
        xp: profile.xp,
        genre: "Hip-Hop", // Default for now
        isFinalBoss: index === 0
      })) || [];
    },
  });

  const handleChallengeFinalBoss = (userId: string) => {
    toast.info("Challenge the Final Boss!", {
      description: "Battle system coming soon. Prepare your best track!"
    });
  };

  const handleViewProfile = (userId: string) => {
    navigate(`/profile/${userId}`);
  };

  const handleLoadMore = () => {
    toast.info("Loading more competitors...");
  };

  return (
    <div className="min-h-screen bg-background">
      <Header />
      
      <main className="container px-4 pt-24 pb-12">
        {/* Header Section */}
        <motion.div 
          className="text-center mb-12"
          initial={{ opacity: 0, y: -20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.6 }}
        >
          <motion.div 
            className="inline-block mb-4"
            animate={{ 
              scale: [1, 1.1, 1],
              rotate: [0, 10, -10, 0]
            }}
            transition={{ 
              duration: 2,
              repeat: Infinity,
              ease: "easeInOut"
            }}
          >
            <Trophy className="h-16 w-16 text-primary" />
          </motion.div>
          <h1 className="text-5xl md:text-7xl font-black mb-4 text-white">
            LEADER<span className="text-secondary" style={{ textShadow: '0 0 30px hsl(340, 70%, 60%)' }}>BOARD</span>
          </h1>
          <p className="text-xl text-foreground/80 max-w-2xl mx-auto">
            Every sound leaves a scar. Every win leaves a mark. Rise to become the Final Boss.
          </p>
        </motion.div>

        {/* Genre Tabs */}
        <Tabs defaultValue="All" className="w-full max-w-6xl mx-auto">
          <TabsList className="grid w-full grid-cols-3 md:grid-cols-6 mb-8 bg-card/50 backdrop-blur-sm">
            {genreTabs.map((genre) => (
              <TabsTrigger 
                key={genre} 
                value={genre}
                className="data-[state=active]:bg-primary data-[state=active]:text-primary-foreground"
              >
                {genre}
              </TabsTrigger>
            ))}
          </TabsList>

          {genreTabs.map((genre) => (
            <TabsContent key={genre} value={genre} className="space-y-4">
              {isLoading ? (
                <div className="grid md:grid-cols-3 gap-6 mb-8">
                  <Skeleton className="h-64" />
                  <Skeleton className="h-72" />
                  <Skeleton className="h-64" />
                </div>
              ) : leaders && leaders.length > 0 ? (
                <>
                  {/* Top 3 Podium */}
                  <div className="grid md:grid-cols-3 gap-6 mb-8">
                    {leaders.slice(0, 3).map((leader, idx) => (
                      <motion.div
                        initial={{ opacity: 0, y: 50 }}
                        animate={{ opacity: 1, y: 0 }}
                        transition={{ duration: 0.5, delay: idx * 0.2 }}
                        whileHover={{ scale: 1.05, y: -10 }}
                        key={leader.rank}
                        className={`relative bg-card border rounded-2xl p-6 text-center ${
                          idx === 0 
                            ? 'md:col-start-2 md:row-start-1 border-primary shadow-[0_0_40px_hsl(var(--primary)/0.3)]' 
                            : idx === 1
                            ? 'md:col-start-1 md:row-start-2 border-secondary/50'
                            : 'md:col-start-3 md:row-start-2 border-border'
                        }`}
                      >
                        {leader.isFinalBoss && (
                          <div className="absolute -top-4 left-1/2 -translate-x-1/2">
                            <div className="bg-primary text-primary-foreground px-4 py-1 rounded-full text-xs font-bold flex items-center gap-1">
                              <Crown className="h-3 w-3" />
                              FINAL BOSS
                            </div>
                          </div>
                        )}
                        
                        <div className="relative inline-block mb-4">
                          <Avatar className="h-24 w-24 border-4 border-primary">
                            <AvatarFallback className="text-2xl font-bold bg-primary/20">
                              {leader.name.slice(0, 2)}
                            </AvatarFallback>
                          </Avatar>
                          <div className={`absolute -bottom-2 -right-2 w-10 h-10 rounded-full flex items-center justify-center font-bold ${
                            idx === 0 ? 'bg-primary text-primary-foreground' :
                            idx === 1 ? 'bg-secondary text-secondary-foreground' :
                            'bg-[hsl(var(--success))] text-[hsl(var(--success-foreground))]'
                          }`}>
                            #{leader.rank}
                          </div>
                        </div>

                        <h3 className="text-xl font-bold mb-2 text-foreground">{leader.name}</h3>
                        <div className="flex justify-center gap-4 text-sm text-foreground/70 mb-4">
                          <div className="flex items-center gap-1">
                            <Trophy className="h-4 w-4 text-primary" />
                            {leader.wins} Wins
                          </div>
                          <div className="flex items-center gap-1">
                            <Zap className="h-4 w-4 text-secondary" />
                            {leader.xp.toLocaleString()} XP
                          </div>
                        </div>
                        
                        {idx === 0 ? (
                          <Button variant="battle" size="sm" className="w-full" onClick={() => handleChallengeFinalBoss(leader.userId)}>
                            Challenge Final Boss
                          </Button>
                        ) : (
                          <Button variant="outline" size="sm" className="w-full" onClick={() => handleViewProfile(leader.userId)}>
                            View Profile
                          </Button>
                        )}
                      </motion.div>
                    ))}
                  </div>

                  {/* Rest of Leaderboard */}
                  <div className="bg-card border border-border rounded-2xl overflow-hidden">
                    <div className="p-4 bg-card/50 border-b border-border">
                      <h2 className="text-xl font-bold">Top Competitors</h2>
                    </div>
                    
                    <div className="divide-y divide-border">
                      {leaders.slice(3).map((leader, idx) => (
                        <motion.div
                          initial={{ opacity: 0, x: -20 }}
                          whileInView={{ opacity: 1, x: 0 }}
                          viewport={{ once: true }}
                          transition={{ duration: 0.3, delay: idx * 0.05 }}
                          whileHover={{ backgroundColor: "hsl(var(--card) / 0.5)" }}
                          key={leader.rank}
                          className="p-4 hover:bg-card/50 transition-colors flex items-center justify-between"
                        >
                          <div className="flex items-center gap-4">
                            <div className="w-8 h-8 rounded-full bg-muted flex items-center justify-center font-bold text-sm">
                              #{leader.rank}
                            </div>
                            
                            <Avatar className="h-12 w-12">
                              <AvatarFallback className="bg-primary/20">
                                {leader.name.slice(0, 2)}
                              </AvatarFallback>
                            </Avatar>

                            <div>
                              <h3 className="font-bold text-foreground">{leader.name}</h3>
                              <p className="text-sm text-foreground/70">{leader.genre}</p>
                            </div>
                          </div>

                          <div className="flex items-center gap-8">
                            <div className="text-right">
                              <div className="flex items-center gap-1 text-sm">
                                <Trophy className="h-4 w-4 text-primary" />
                                <span className="font-semibold">{leader.wins}</span>
                              </div>
                              <div className="text-xs text-foreground/70">Wins</div>
                            </div>

                            <div className="text-right">
                              <div className="flex items-center gap-1 text-sm">
                                <Zap className="h-4 w-4 text-secondary" />
                                <span className="font-semibold">{leader.xp.toLocaleString()}</span>
                              </div>
                              <div className="text-xs text-foreground/70">XP</div>
                            </div>

                            <Button variant="outline" size="sm" onClick={() => handleViewProfile(leader.userId)}>
                              View Profile
                            </Button>
                          </div>
                        </motion.div>
                      ))}
                    </div>
                  </div>

                  {/* Load More */}
                  <div className="text-center pt-6">
                    <Button variant="outline" size="lg" onClick={handleLoadMore}>
                      <TrendingUp className="mr-2 h-4 w-4" />
                      Load More
                    </Button>
                  </div>
                </>
              ) : (
                <div className="text-center py-12">
                  <Trophy className="h-16 w-16 mx-auto mb-4 text-foreground/50" />
                  <p className="text-foreground/80">No competitors yet. Be the first to battle!</p>
                </div>
              )}
            </TabsContent>
          ))}
        </Tabs>

        {/* Info Box */}
        <div className="max-w-6xl mx-auto mt-12 bg-primary/10 border border-primary/30 rounded-xl p-6">
          <h3 className="text-lg font-bold mb-2 flex items-center gap-2">
            <Crown className="h-5 w-5 text-primary" />
            What is a Final Boss?
          </h3>
          <p className="text-foreground/80">
            The top player in each genre earns the title of Final Boss. Anyone can challenge a Final Boss 
            for bragging rights, titles, and exclusive loot. Only one rule at the top: stay undefeated.
          </p>
        </div>
      </main>
    </div>
  );
};

export default Leaderboard;
