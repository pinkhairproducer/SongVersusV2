import { useState, useEffect } from "react";
import { Button } from "@/components/ui/button";
import { useNavigate } from "react-router-dom";
import { motion, AnimatePresence } from "framer-motion";
import { Swords, Volume2, VolumeX } from "lucide-react";
import heroBattle from "@/assets/hero-battle-optimized.jpg";
import { TutorialModal } from "@/components/TutorialModal";

const Splash = () => {
  const navigate = useNavigate();
  const [isVisible, setIsVisible] = useState(true);
  const [soundEnabled, setSoundEnabled] = useState(false);
  const [showTutorial, setShowTutorial] = useState(false);

  useEffect(() => {
    // Prevent scrolling on splash page
    document.body.style.overflow = "hidden";
    return () => {
      document.body.style.overflow = "unset";
    };
  }, []);

  const handleEnter = () => {
    setShowTutorial(true);
  };

  const handleTutorialComplete = () => {
    setShowTutorial(false);
    setIsVisible(false);
    setTimeout(() => {
      navigate("/home");
    }, 800);
  };

  return (
    <AnimatePresence>
      {isVisible && (
        <motion.div
          className="fixed inset-0 z-50 bg-background"
          initial={{ opacity: 1 }}
          exit={{ opacity: 0 }}
          transition={{ duration: 0.8 }}
        >
          {/* Background Image with Overlay */}
          <div className="absolute inset-0">
            <img
              src={heroBattle}
              alt="Battle Arena Background"
              width="1920"
              height="1080"
              className="w-full h-full object-cover"
            />
            <div className="absolute inset-0 bg-background/80" />
            <div className="absolute inset-0 bg-gradient-to-b from-background/60 via-transparent to-background/60" />
          </div>

          {/* Animated Background Effects - Optimized for mobile */}
          <div className="absolute inset-0 overflow-hidden">
            {/* Pulsing Orbs - Simplified animation */}
            <motion.div
              className="absolute top-1/4 left-1/4 w-96 h-96 bg-primary/30 rounded-full blur-3xl"
              style={{ willChange: "transform, opacity" }}
              animate={{
                scale: [1, 1.2, 1],
                opacity: [0.2, 0.4, 0.2],
              }}
              transition={{
                duration: 6,
                repeat: Infinity,
                ease: "linear",
              }}
            />
            <motion.div
              className="absolute bottom-1/4 right-1/4 w-96 h-96 bg-secondary/30 rounded-full blur-3xl"
              style={{ willChange: "transform, opacity" }}
              animate={{
                scale: [1, 1.2, 1],
                opacity: [0.2, 0.4, 0.2],
              }}
              transition={{
                duration: 8,
                repeat: Infinity,
                ease: "linear",
                delay: 2,
              }}
            />
          </div>

          {/* Content */}
          <div className="relative z-10 flex flex-col items-center justify-center min-h-screen px-4">
            {/* Logo Icon */}
            <motion.div
              initial={{ scale: 0, rotate: -180 }}
              animate={{ scale: 1, rotate: 0 }}
              transition={{
                type: "spring",
                stiffness: 200,
                damping: 15,
                duration: 1,
              }}
              className="mb-8"
            >
              <div className="relative">
                <motion.div
                  className="absolute inset-0 bg-primary/20 rounded-full blur-2xl"
                  animate={{
                    scale: [1, 1.2, 1],
                  }}
                  transition={{
                    duration: 2,
                    repeat: Infinity,
                    ease: "easeInOut",
                  }}
                />
                <Swords className="h-24 w-24 text-primary relative z-10" />
              </div>
            </motion.div>

            {/* Main Title */}
            <motion.div
              initial={{ opacity: 0, y: 50 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: 0.3, duration: 0.8 }}
              className="text-center mb-4"
            >
              <h1 className="text-7xl md:text-9xl font-black leading-none mb-2">
                <motion.span
                  className="inline-block text-glow"
                  animate={{
                    textShadow: [
                      "0 0 20px hsl(var(--primary))",
                      "0 0 40px hsl(var(--primary))",
                      "0 0 20px hsl(var(--primary))",
                    ],
                  }}
                  transition={{
                    duration: 2,
                    repeat: Infinity,
                    ease: "easeInOut",
                  }}
                >
                  SONG
                </motion.span>
              </h1>
              <h1 className="text-7xl md:text-9xl font-black leading-none">
                <motion.span
                  className="inline-block text-secondary text-glow-magenta"
                  animate={{
                    textShadow: [
                      "0 0 20px hsl(var(--secondary))",
                      "0 0 40px hsl(var(--secondary))",
                      "0 0 20px hsl(var(--secondary))",
                    ],
                  }}
                  transition={{
                    duration: 2,
                    repeat: Infinity,
                    ease: "easeInOut",
                    delay: 0.5,
                  }}
                >
                  VERSUS
                </motion.span>
              </h1>
            </motion.div>

            {/* Tagline */}
            <motion.div
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              transition={{ delay: 0.8, duration: 1 }}
              className="text-center mb-12"
            >
              <p className="text-xl md:text-3xl font-bold text-muted-foreground tracking-wider">
                WHERE SOUND BECOMES{" "}
                <span className="text-primary">BATTLE</span>
              </p>
            </motion.div>

            {/* Enter Button */}
            <motion.div
              initial={{ opacity: 0, scale: 0.8 }}
              animate={{ opacity: 1, scale: 1 }}
              transition={{ delay: 1.2, duration: 0.5 }}
              className="relative"
            >
              <motion.div
                className="absolute inset-0 bg-primary/20 rounded-full blur-xl"
                animate={{
                  scale: [1, 1.3, 1],
                  opacity: [0.5, 0.8, 0.5],
                }}
                transition={{
                  duration: 2,
                  repeat: Infinity,
                  ease: "easeInOut",
                }}
              />
              <Button
                variant="battle"
                size="xl"
                onClick={handleEnter}
                className="relative z-10 text-2xl px-12 py-8 h-auto font-black tracking-wider group"
              >
                <motion.span
                  animate={{
                    scale: [1, 1.05, 1],
                  }}
                  transition={{
                    duration: 1.5,
                    repeat: Infinity,
                    ease: "easeInOut",
                  }}
                >
                  ENTER THE ARENA
                </motion.span>
              </Button>
            </motion.div>

            {/* Scroll Hint */}
            <motion.div
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              transition={{ delay: 2, duration: 1 }}
              className="absolute bottom-8 left-1/2 -translate-x-1/2"
            >
              <motion.div
                animate={{
                  y: [0, 10, 0],
                }}
                transition={{
                  duration: 1.5,
                  repeat: Infinity,
                  ease: "easeInOut",
                }}
                className="text-muted-foreground text-sm flex flex-col items-center gap-2"
              >
                <div className="w-6 h-10 border-2 border-muted-foreground rounded-full flex justify-center">
                  <motion.div
                    className="w-1.5 h-3 bg-muted-foreground rounded-full mt-2"
                    animate={{
                      y: [0, 12, 0],
                      opacity: [1, 0, 1],
                    }}
                    transition={{
                      duration: 1.5,
                      repeat: Infinity,
                      ease: "easeInOut",
                    }}
                  />
                </div>
              </motion.div>
            </motion.div>

            {/* Sound Toggle */}
            <motion.button
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              transition={{ delay: 1.5 }}
              onClick={() => setSoundEnabled(!soundEnabled)}
              className="absolute top-8 right-8 p-3 rounded-full bg-card/50 backdrop-blur-sm border border-border hover:border-primary/50 transition-colors"
            >
              {soundEnabled ? (
                <Volume2 className="h-6 w-6 text-primary" />
              ) : (
                <VolumeX className="h-6 w-6 text-muted-foreground" />
              )}
            </motion.button>
          </div>

          {/* Tutorial Modal */}
          <TutorialModal open={showTutorial} onComplete={handleTutorialComplete} />

          {/* Vignette Effect */}
          <div className="absolute inset-0 pointer-events-none bg-gradient-radial from-transparent via-transparent to-background/50" />
        </motion.div>
      )}
    </AnimatePresence>
  );
};

export default Splash;
