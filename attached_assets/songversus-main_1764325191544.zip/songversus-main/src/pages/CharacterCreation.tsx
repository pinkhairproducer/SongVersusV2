import { useState, useEffect } from "react";
import { useNavigate } from "react-router-dom";
import { supabase } from "@/lib/supabase";
import { Button } from "@/components/ui/button";
import { toast } from "@/hooks/use-toast";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Badge } from "@/components/ui/badge";
import { Card } from "@/components/ui/card";
import { CharacterDisplay } from "@/components/CharacterDisplay";
import { motion } from "framer-motion";

interface CustomizationItem {
  id: string;
  name: string;
  category: string;
  rarity: string;
  is_starter: boolean;
  description: string;
  image_url?: string;
}

const CharacterCreation = () => {
  const [loading, setLoading] = useState(true);
  const [hasProfile, setHasProfile] = useState(false);
  const [assignedItems, setAssignedItems] = useState<CustomizationItem[]>([]);
  const [role, setRole] = useState<"producer" | "artist" | "both">("producer");
  const navigate = useNavigate();

  useEffect(() => {
    checkProfile();
  }, []);

  const checkProfile = async () => {
    const { data: { session } } = await supabase.auth.getSession();
    if (!session) {
      navigate("/auth");
      return;
    }

    const { data: profile } = await supabase
      .from("profiles")
      .select("*")
      .eq("user_id", session.user.id)
      .single();

    if (profile) {
      // Check if user already has customizations (character already created)
      const { data: customizations } = await supabase
        .from("user_customizations")
        .select(`
          *,
          customization_items (
            id,
            name,
            category,
            rarity,
            is_starter,
            description,
            image_url
          )
        `)
        .eq("user_id", session.user.id);

      if (customizations && customizations.length > 0) {
        // Character already created, redirect to home
        navigate("/");
        return;
      }
      
      // Load the auto-assigned items
      const items = customizations?.map((c: any) => c.customization_items).filter(Boolean) || [];
      setAssignedItems(items);
      
      if (profile.role) {
        setRole(profile.role as "producer" | "artist" | "both");
      }
    }
    setLoading(false);
  };

  const handleComplete = async () => {
    setLoading(true);
    const { data: { session } } = await supabase.auth.getSession();
    if (!session) return;

    try {
      // Update profile role only - character items were already assigned by trigger
      const { error: profileError } = await supabase
        .from("profiles")
        .update({ role })
        .eq("user_id", session.user.id);

      if (profileError) throw profileError;

      toast({ title: "Character created! Welcome to the arena." });
      navigate("/");
    } catch (error: any) {
      toast({
        title: "Error creating character",
        description: error.message,
        variant: "destructive",
      });
    } finally {
      setLoading(false);
    }
  };

  if (loading) {
    return (
      <div className="min-h-screen bg-background flex items-center justify-center">
        <p className="text-glow">Loading...</p>
      </div>
    );
  }

  console.log("Assigned items for character:", assignedItems);

  return (
    <div className="min-h-screen bg-background p-8">
      <div className="max-w-6xl mx-auto">
        <motion.div 
          className="text-center mb-8"
          initial={{ opacity: 0, y: -20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.6 }}
        >
          <h1 className="text-5xl font-bold text-glow mb-4">CREATE YOUR FIGHTER</h1>
          <p className="text-muted-foreground">Choose your path and customize your avatar</p>
        </motion.div>

        {/* Role Selection */}
        <Card className="p-6 mb-8 bg-card/80 backdrop-blur-lg border-primary/20">
          <h2 className="text-2xl font-bold mb-4">Choose Your Role</h2>
          <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
            <Button
              variant={role === "producer" ? "battle" : "outline"}
              size="lg"
              onClick={() => setRole("producer")}
              className="h-auto py-6 flex-col"
            >
              <span className="text-xl font-bold">PRODUCER</span>
              <span className="text-sm mt-2">Master of beats</span>
            </Button>
            <Button
              variant={role === "artist" ? "battle" : "outline"}
              size="lg"
              onClick={() => setRole("artist")}
              className="h-auto py-6 flex-col"
            >
              <span className="text-xl font-bold">ARTIST</span>
              <span className="text-sm mt-2">Voice of power</span>
            </Button>
            <Button
              variant={role === "both" ? "battle" : "outline"}
              size="lg"
              onClick={() => setRole("both")}
              className="h-auto py-6 flex-col"
            >
              <span className="text-xl font-bold">BOTH</span>
              <span className="text-sm mt-2">Ultimate warrior</span>
            </Button>
          </div>
        </Card>

        {/* Character Preview */}
        <motion.div 
          className="flex justify-center"
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.6, delay: 0.3 }}
        >
          <Card className="p-8 bg-card/80 backdrop-blur-lg border-primary/20 max-w-md w-full">
            <h2 className="text-3xl font-bold mb-6 text-center text-glow">Your Unique Fighter</h2>
            <div className="flex justify-center items-center mb-6">
              <CharacterDisplay 
                previewItems={assignedItems}
                size="lg"
                className="border-4 border-primary/30 shadow-2xl"
              />
            </div>
            <div className="space-y-3">
              <p className="text-center text-muted-foreground">
                This character has been uniquely assigned to you. No other fighter in the arena has this exact combination!
              </p>
              {assignedItems.length > 0 && (
                <div className="grid grid-cols-2 gap-2 mt-4">
                  {assignedItems.map((item) => (
                    <div key={item.id} className="flex items-center gap-2 p-2 bg-background/50 rounded border border-border">
                      <Badge variant="secondary" className="capitalize text-xs">
                        {item.category}
                      </Badge>
                      <span className="text-xs truncate">{item.name}</span>
                    </div>
                  ))}
                </div>
              )}
            </div>
          </Card>
        </motion.div>

      <motion.div 
        className="mt-8 text-center"
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.6, delay: 0.6 }}
      >
          <Button
            variant="battle"
            size="xl"
            onClick={handleComplete}
            disabled={loading}
          >
            {loading ? "Creating..." : "Enter the Arena"}
          </Button>
        </motion.div>
      </div>
    </div>
  );
};

export default CharacterCreation;
