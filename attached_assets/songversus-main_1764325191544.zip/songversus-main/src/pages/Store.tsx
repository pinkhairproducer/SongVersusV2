import { useState, useEffect } from "react";
import { Header } from "@/components/Header";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Badge } from "@/components/ui/badge";
import { Progress } from "@/components/ui/progress";
import { Coins, Sparkles, Zap, Crown, Check, Star, Lock, TrendingUp, Flame } from "lucide-react";
import { supabase } from "@/lib/supabase";
import { useNavigate, useSearchParams } from "react-router-dom";
import { toast } from "sonner";
import { motion } from "framer-motion";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";

interface CoinPackage {
  id: string;
  name: string;
  coins: number;
  price: number;
  priceId: string;
  icon: any;
  color: string;
  description: string;
  badge?: string;
}

const coinPackages: CoinPackage[] = [
  {
    id: "starter",
    name: "Starter Pack",
    coins: 100,
    price: 4.99,
    priceId: "price_1SV18VA74KlR7uVLxeukKII3",
    icon: Coins,
    color: "text-gray-400",
    description: "Perfect to get started",
  },
  {
    id: "popular",
    name: "Popular Pack",
    coins: 500,
    price: 19.99,
    priceId: "price_1SV18jA74KlR7uVLmnAQEHff",
    icon: Sparkles,
    color: "text-blue-400",
    description: "Most popular choice",
    badge: "Best Value",
  },
  {
    id: "power",
    name: "Power Pack",
    coins: 1000,
    price: 34.99,
    priceId: "price_1SV18vA74KlR7uVLETo8yvZw",
    icon: Zap,
    color: "text-purple-400",
    description: "For serious competitors",
  },
  {
    id: "ultimate",
    name: "Ultimate Pack",
    coins: 2500,
    price: 79.99,
    priceId: "price_1SV19AA74KlR7uVLIzwZK3xc",
    icon: Crown,
    color: "text-yellow-400",
    description: "Maximum coins",
    badge: "Premium",
  },
];

interface CustomizationItem {
  id: string;
  name: string;
  description: string | null;
  category: string;
  rarity: string;
  image_url: string | null;
  required_level: number;
  evolved_from: string | null;
  evolution_tier: string;
  is_starter: boolean;
}

const getRarityColor = (rarity: string) => {
  switch (rarity) {
    case "legendary": return "text-yellow-400";
    case "epic": return "text-purple-400";
    case "rare": return "text-blue-400";
    default: return "text-gray-400";
  }
};

const getEvolutionBadge = (tier: string) => {
  switch (tier) {
    case "ultimate": return { label: "Ultimate", icon: Crown, color: "bg-yellow-500" };
    case "evolved": return { label: "Evolved", icon: TrendingUp, color: "bg-purple-500" };
    default: return null;
  }
};

export default function Store() {
  const navigate = useNavigate();
  const [searchParams] = useSearchParams();
  const [user, setUser] = useState<any>(null);
  const [loading, setLoading] = useState<string | null>(null);
  const [memberships, setMemberships] = useState<any[]>([]);
  const [currentSubscription, setCurrentSubscription] = useState<any>(null);
  const [selectedCategory, setSelectedCategory] = useState<string>("all");
  const queryClient = useQueryClient();

  const membershipPriceIds: Record<string, string> = {
    Pro: "price_1SV27JA74KlR7uVLudmo0MtH",
    Elite: "price_1SV27XA74KlR7uVLOyQBj9JL",
  };

  useEffect(() => {
    supabase.auth.getSession().then(({ data: { session } }) => {
      setUser(session?.user ?? null);
    });

    const { data: { subscription } } = supabase.auth.onAuthStateChange((event, session) => {
      setUser(session?.user ?? null);
    });

    return () => subscription.unsubscribe();
  }, []);

  useEffect(() => {
    const fetchMemberships = async () => {
      const { data, error } = await supabase
        .from("membership_tiers")
        .select("*")
        .eq("is_active", true)
        .order("sort_order");

      if (error) {
        console.error("Error fetching memberships:", error);
        toast.error("Failed to load memberships");
      } else {
        setMemberships(data || []);
      }
    };

    fetchMemberships();
  }, []);

  useEffect(() => {
    const checkSubscription = async () => {
      if (!user) return;

      try {
        const { data, error } = await supabase.functions.invoke("check-subscription");

        if (error) throw error;

        setCurrentSubscription(data);
      } catch (error) {
        console.error("Error checking subscription:", error);
      }
    };

    checkSubscription();
  }, [user]);

  // Check if user has any paid membership (not just Basic/Free)
  const hasPaidMembership = currentSubscription?.subscribed && 
    currentSubscription?.tier_id && 
    memberships.find(m => m.id === currentSubscription.tier_id)?.price > 0;

  useEffect(() => {
    const success = searchParams.get("success");
    const canceled = searchParams.get("canceled");

    if (success) {
      toast.success("Payment successful! Your coins have been added.");
    } else if (canceled) {
      toast.info("Payment canceled.");
    }
  }, [searchParams]);

  // Fetch user profile with level
  const { data: profile } = useQuery({
    queryKey: ['profile', user?.id],
    queryFn: async () => {
      if (!user) return null;
      const { data, error } = await supabase
        .from('profiles')
        .select('*')
        .eq('user_id', user.id)
        .single();
      if (error) throw error;
      return data;
    },
    enabled: !!user,
  });

  // Fetch all customization items
  const { data: customizationItems = [], isLoading: itemsLoading } = useQuery({
    queryKey: ['customization-items'],
    queryFn: async () => {
      const { data, error } = await supabase
        .from('customization_items')
        .select('*')
        .order('required_level')
        .order('rarity');
      if (error) throw error;
      return data as CustomizationItem[];
    },
  });

  // Fetch user's owned items
  const { data: userItems = [] } = useQuery({
    queryKey: ['user-customizations', user?.id],
    queryFn: async () => {
      if (!user) return [];
      const { data, error } = await supabase
        .from('user_customizations')
        .select('customization_item_id, is_equipped')
        .eq('user_id', user.id);
      if (error) throw error;
      return data;
    },
    enabled: !!user,
  });

  // Evolve item mutation
  const evolveMutation = useMutation({
    mutationFn: async (itemId: string) => {
      const { data, error } = await supabase.rpc('evolve_item', {
        p_user_id: user.id,
        p_base_item_id: itemId,
      });
      if (error) throw error;
      return data as { success: boolean; message: string; evolved_item_id?: string };
    },
    onSuccess: (data) => {
      if (data.success) {
        toast.success(data.message);
        queryClient.invalidateQueries({ queryKey: ['user-customizations'] });
        queryClient.invalidateQueries({ queryKey: ['profile'] });
      } else {
        toast.error(data.message);
      }
    },
    onError: () => {
      toast.error("Failed to evolve item");
    },
  });

  const handlePurchase = async (priceId: string, packageId: string) => {
    if (!user) {
      toast.error("Please sign in to purchase coins");
      navigate("/auth");
      return;
    }

    setLoading(packageId);

    try {
      const { data, error } = await supabase.functions.invoke("create-coin-checkout", {
        body: { priceId },
      });

      if (error) throw error;

      if (data?.url) {
        window.open(data.url, "_blank");
      }
    } catch (error) {
      console.error("Error:", error);
      toast.error("Failed to create checkout session");
    } finally {
      setLoading(null);
    }
  };

  const handleMembershipPurchase = async (tierName: string, tierId: string) => {
    if (!user) {
      toast.error("Please sign in to purchase a membership");
      navigate("/auth");
      return;
    }

    const priceId = membershipPriceIds[tierName];
    if (!priceId) {
      toast.error("Membership pricing not configured");
      return;
    }

    setLoading(tierId);

    try {
      const { data, error } = await supabase.functions.invoke("create-membership-checkout", {
        body: { priceId },
      });

      if (error) throw error;

      if (data?.url) {
        window.open(data.url, "_blank");
      }
    } catch (error) {
      console.error("Error:", error);
      toast.error("Failed to create checkout session");
    } finally {
      setLoading(null);
    }
  };

  const handleManageSubscription = async () => {
    try {
      const { data, error } = await supabase.functions.invoke("customer-portal");

      if (error) throw error;

      if (data?.url) {
        window.open(data.url, "_blank");
      }
    } catch (error) {
      console.error("Error:", error);
      toast.error("Failed to open customer portal");
    }
  };

  return (
    <div className="min-h-screen bg-background">
      <Header />
      <main className="container mx-auto px-4 pt-24 pb-12">
        <div className="max-w-7xl mx-auto">
          <div className="text-center mb-12">
            <h1 className="text-4xl font-bold mb-4 text-white" style={{ textShadow: '0 0 30px rgba(255,255,255,0.3)' }}>Store</h1>
            <p className="text-xl text-foreground/80">
              Purchase coins and unlock exclusive customizations
            </p>
          </div>

          <Tabs defaultValue={hasPaidMembership ? "coins" : "memberships"} className="w-full">
            {hasPaidMembership ? (
              <TabsList className="grid w-full max-w-2xl mx-auto grid-cols-1 sm:grid-cols-3 mb-8">
                <TabsTrigger value="coins" className="text-xs sm:text-sm">Coin Packages</TabsTrigger>
                <TabsTrigger value="memberships" className="text-xs sm:text-sm">Memberships</TabsTrigger>
                <TabsTrigger value="customizations" className="text-xs sm:text-sm">Customizations</TabsTrigger>
              </TabsList>
            ) : (
              <TabsList className="grid w-full max-w-md mx-auto grid-cols-1 mb-8">
                <TabsTrigger value="memberships" className="text-xs sm:text-sm">Memberships</TabsTrigger>
              </TabsList>
            )}

            {hasPaidMembership && <TabsContent value="coins" className="space-y-8">
              <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
                {coinPackages.map((pkg) => {
                  const Icon = pkg.icon;
                  return (
                    <motion.div
                      key={pkg.id}
                      initial={{ opacity: 0, y: 20 }}
                      animate={{ opacity: 1, y: 0 }}
                      transition={{ delay: coinPackages.indexOf(pkg) * 0.1 }}
                    >
                      <Card
                        className={`relative overflow-hidden transition-all hover:scale-105 ${
                          pkg.badge ? "border-primary shadow-lg shadow-primary/20" : ""
                        }`}
                      >
                        {pkg.badge && (
                          <div className="absolute top-4 right-4">
                            <span className="bg-primary text-primary-foreground text-xs font-bold px-2 py-1 rounded-full">
                              {pkg.badge}
                            </span>
                          </div>
                        )}

                        <CardHeader className="text-center pb-4">
                          <div className="mx-auto mb-4">
                            <div className="relative inline-block">
                              <div className={`absolute inset-0 blur-xl ${pkg.color} opacity-50`} />
                              <Icon className={`relative h-16 w-16 ${pkg.color}`} />
                            </div>
                          </div>
                          <CardTitle className="text-2xl">{pkg.name}</CardTitle>
                          <CardDescription className="text-foreground/80">{pkg.description}</CardDescription>
                        </CardHeader>

                        <CardContent className="text-center space-y-4">
                          <div className="space-y-2">
                            <div className="flex items-center justify-center gap-2">
                              <Coins className="h-8 w-8 text-yellow-500" />
                              <span className="text-4xl font-bold">{pkg.coins}</span>
                            </div>
                            <div className="text-2xl font-semibold text-primary">
                              ${pkg.price}
                            </div>
                          </div>

                          <Button
                            className="w-full"
                            onClick={() => handlePurchase(pkg.priceId, pkg.id)}
                            disabled={loading === pkg.id}
                          >
                            {loading === pkg.id ? "Processing..." : "Purchase"}
                          </Button>
                        </CardContent>
                      </Card>
                    </motion.div>
                  );
                })}
              </div>

              <Card className="max-w-2xl mx-auto bg-card/50">
                <CardHeader>
                  <CardTitle>Why Buy Coins?</CardTitle>
                </CardHeader>
                <CardContent className="text-left space-y-3 text-foreground/80">
                  <p className="flex items-start gap-2">
                    <Check className="h-5 w-5 text-primary mt-0.5" />
                    Create unlimited battles without waiting
                  </p>
                  <p className="flex items-start gap-2">
                    <Check className="h-5 w-5 text-primary mt-0.5" />
                    Purchase exclusive customizations from the store
                  </p>
                  <p className="flex items-start gap-2">
                    <Check className="h-5 w-5 text-primary mt-0.5" />
                    Unlock premium features and boost your profile
                  </p>
                  <p className="flex items-start gap-2">
                    <Check className="h-5 w-5 text-primary mt-0.5" />
                    Support the platform and its creators
                  </p>
                </CardContent>
              </Card>
            </TabsContent>}

            <TabsContent value="memberships" className="space-y-8">
              {!hasPaidMembership && user && (
                <Card className="max-w-2xl mx-auto bg-primary/10 border-primary/20 mb-8">
                  <CardContent className="pt-6 text-center">
                    <p className="text-lg font-semibold mb-2">🎉 Unlock the Full Store!</p>
                    <p className="text-muted-foreground">
                      Purchase a membership to access Coin Packages and exclusive Customizations
                    </p>
                  </CardContent>
                </Card>
              )}
              {currentSubscription?.subscribed && (
                <Card className="max-w-2xl mx-auto bg-primary/10 border-primary">
                  <CardContent className="pt-6">
                    <div className="flex items-center justify-between">
                      <div>
                        <p className="font-semibold">Active Subscription</p>
                        <p className="text-sm text-foreground/80">
                          You have an active membership subscription
                        </p>
                      </div>
                      <Button onClick={handleManageSubscription} variant="outline">
                        Manage Subscription
                      </Button>
                    </div>
                  </CardContent>
                </Card>
              )}

              <div className="grid grid-cols-1 md:grid-cols-3 gap-6 max-w-6xl mx-auto">
                {memberships.map((tier, index) => {
                  const tierIcons: Record<string, any> = {
                    Free: Star,
                    Pro: Sparkles,
                    Elite: Crown,
                  };
                  const TierIcon = tierIcons[tier.name] || Star;
                  const features = Array.isArray(tier.features) ? tier.features : [];
                  const isCurrentTier = currentSubscription?.tier_id === tier.id;
                  const isFree = tier.name === "Free";
                  
                  return (
                    <motion.div
                      key={tier.id}
                      initial={{ opacity: 0, y: 20 }}
                      animate={{ opacity: 1, y: 0 }}
                      transition={{ delay: index * 0.1 }}
                    >
                      <Card
                        className={`relative overflow-hidden h-full flex flex-col ${
                          tier.name === "Pro" ? "border-primary shadow-lg shadow-primary/20" : ""
                        } ${isCurrentTier ? "border-primary shadow-lg" : ""}`}
                      >
                        {tier.name === "Pro" && !isCurrentTier && (
                          <div className="absolute top-4 right-4">
                            <span className="bg-primary text-primary-foreground text-xs font-bold px-2 py-1 rounded-full">
                              Popular
                            </span>
                          </div>
                        )}
                        {isCurrentTier && (
                          <div className="absolute top-4 right-4">
                            <span className="bg-primary text-primary-foreground text-xs font-bold px-2 py-1 rounded-full">
                              Your Plan
                            </span>
                          </div>
                        )}

                        <CardHeader className="text-center pb-4">
                          <div className="mx-auto mb-4">
                            <div className="relative inline-block">
                              <div className={`absolute inset-0 blur-xl opacity-50 ${
                                tier.name === "Free" ? "text-gray-400" :
                                tier.name === "Pro" ? "text-blue-400" : "text-yellow-400"
                              }`} />
                              <TierIcon className={`relative h-16 w-16 ${
                                tier.name === "Free" ? "text-gray-400" :
                                tier.name === "Pro" ? "text-blue-400" : "text-yellow-400"
                              }`} />
                            </div>
                          </div>
                          <CardTitle className="text-2xl">{tier.name}</CardTitle>
                          <CardDescription className="text-foreground/80">{tier.description}</CardDescription>
                        </CardHeader>

                        <CardContent className="text-center space-y-4 flex-1 flex flex-col">
                          <div className="space-y-2">
                            <div className="text-4xl font-bold">
                              {tier.price === 0 ? (
                                "Free"
                              ) : (
                                <>
                                  ${(tier.price / 100).toFixed(2)}
                                  <span className="text-sm text-foreground/70">/month</span>
                                </>
                              )}
                            </div>
                          </div>

                          <div className="text-left space-y-2 flex-1">
                            {features.map((feature: string, idx: number) => (
                              <p key={idx} className="flex items-start gap-2 text-sm">
                                <Check className="h-4 w-4 text-primary mt-0.5 shrink-0" />
                                <span>{feature}</span>
                              </p>
                            ))}
                          </div>

                          <Button
                            className="w-full mt-auto"
                            variant={isFree || isCurrentTier ? "outline" : "default"}
                            disabled={isFree || isCurrentTier || loading === tier.id}
                            onClick={() => handleMembershipPurchase(tier.name, tier.id)}
                          >
                            {isCurrentTier ? "Current Plan" : 
                             isFree ? "Free" : 
                             loading === tier.id ? "Processing..." : "Subscribe"}
                          </Button>
                        </CardContent>
                      </Card>
                    </motion.div>
                  );
                })}
              </div>

              <Card className="max-w-2xl mx-auto bg-card/50">
                <CardHeader>
                  <CardTitle>Why Subscribe?</CardTitle>
                </CardHeader>
                <CardContent className="text-left space-y-3 text-foreground/80">
                  <p className="flex items-start gap-2">
                    <Check className="h-5 w-5 text-primary mt-0.5" />
                    Earn 1.5x-2x more coins and XP on all activities
                  </p>
                  <p className="flex items-start gap-2">
                    <Check className="h-5 w-5 text-primary mt-0.5" />
                    Unlock exclusive skins and profile customizations
                  </p>
                  <p className="flex items-start gap-2">
                    <Check className="h-5 w-5 text-primary mt-0.5" />
                    Priority matchmaking and support from our team
                  </p>
                  <p className="flex items-start gap-2">
                    <Check className="h-5 w-5 text-primary mt-0.5" />
                    Cancel anytime through the customer portal
                  </p>
                </CardContent>
              </Card>
            </TabsContent>

            {hasPaidMembership && (
              <TabsContent value="customizations" className="space-y-8">
                <div className="max-w-7xl mx-auto">
                  {/* Level Progress Card */}
                  {profile && (
                    <Card className="mb-8 bg-gradient-to-r from-primary/10 to-primary/5 border-primary/20">
                      <CardContent className="pt-6">
                        <div className="flex items-center justify-between mb-4">
                          <div className="flex items-center gap-3">
                            <div className="h-12 w-12 rounded-full bg-primary/20 flex items-center justify-center">
                              <Flame className="h-6 w-6 text-primary" />
                            </div>
                            <div>
                              <h3 className="text-lg font-bold">Level {profile.level}</h3>
                              <p className="text-sm text-muted-foreground">
                                {profile.xp} XP • {Math.floor(profile.xp / 100)} levels gained
                              </p>
                            </div>
                          </div>
                          <div className="text-right">
                            <p className="text-sm text-muted-foreground">Next unlock</p>
                            <p className="text-lg font-bold">Level {profile.level + 1}</p>
                          </div>
                        </div>
                        <Progress value={(profile.xp % 100)} className="h-2" />
                      </CardContent>
                    </Card>
                  )}

                  {/* Category Filter */}
                  <div className="flex gap-2 mb-6 overflow-x-auto pb-2">
                    {["all", "skin", "outfit", "hair", "eyes", "accessory", "effect"].map((cat) => (
                      <Button
                        key={cat}
                        variant={selectedCategory === cat ? "default" : "outline"}
                        size="sm"
                        onClick={() => setSelectedCategory(cat)}
                        className="capitalize whitespace-nowrap"
                      >
                        {cat}
                      </Button>
                    ))}
                  </div>

                  {/* Items Grid */}
                  {itemsLoading ? (
                    <div className="text-center py-12">Loading items...</div>
                  ) : (
                    <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-4">
                      {customizationItems
                        .filter(item => selectedCategory === "all" || item.category === selectedCategory)
                        .map((item) => {
                          const isOwned = userItems.some(ui => ui.customization_item_id === item.id);
                          const isEquipped = userItems.find(ui => ui.customization_item_id === item.id)?.is_equipped;
                          const isLocked = profile && item.required_level > profile.level;
                          const canEvolve = isOwned && customizationItems.some(ci => ci.evolved_from === item.id);
                          const evolvedItem = customizationItems.find(ci => ci.evolved_from === item.id);
                          const evolutionBadge = getEvolutionBadge(item.evolution_tier);

                          return (
                            <motion.div
                              key={item.id}
                              initial={{ opacity: 0, scale: 0.95 }}
                              animate={{ opacity: 1, scale: 1 }}
                              transition={{ duration: 0.2 }}
                            >
                              <Card className={`relative overflow-hidden h-full ${
                                isLocked ? "opacity-60" : ""
                              } ${isEquipped ? "border-primary shadow-lg shadow-primary/20" : ""}`}>
                                {/* Evolution Badge */}
                                {evolutionBadge && (
                                  <div className="absolute top-2 right-2 z-10">
                                    <Badge className={`${evolutionBadge.color} text-white flex items-center gap-1`}>
                                      <evolutionBadge.icon className="h-3 w-3" />
                                      {evolutionBadge.label}
                                    </Badge>
                                  </div>
                                )}

                                {/* Locked Overlay */}
                                {isLocked && (
                                  <div className="absolute inset-0 bg-black/60 flex items-center justify-center z-10">
                                    <div className="text-center">
                                      <Lock className="h-8 w-8 mx-auto mb-2 text-white" />
                                      <p className="text-white font-bold">Level {item.required_level}</p>
                                      <p className="text-white/80 text-xs">Required</p>
                                    </div>
                                  </div>
                                )}

                                <CardContent className="p-4">
                                  {/* Item Image Placeholder */}
                                  <div className="aspect-square mb-3 rounded-lg bg-gradient-to-br from-primary/20 to-primary/5 flex items-center justify-center">
                                    {item.image_url ? (
                                      <img src={item.image_url} alt={item.name} className="w-full h-full object-cover rounded-lg" />
                                    ) : (
                                      <Sparkles className={`h-12 w-12 ${getRarityColor(item.rarity)}`} />
                                    )}
                                  </div>

                                  {/* Item Info */}
                                  <div className="space-y-2">
                                    <div className="flex justify-between items-start">
                                      <h4 className="font-bold text-sm line-clamp-1">{item.name}</h4>
                                      <Badge variant="outline" className={getRarityColor(item.rarity)}>
                                        {item.rarity}
                                      </Badge>
                                    </div>

                                    {item.description && (
                                      <p className="text-xs text-muted-foreground line-clamp-2">
                                        {item.description}
                                      </p>
                                    )}

                                    {/* Category & Level */}
                                    <div className="flex items-center justify-between text-xs text-muted-foreground">
                                      <span className="capitalize">{item.category}</span>
                                      <span>Lvl {item.required_level}+</span>
                                    </div>

                                    {/* Evolution Path */}
                                    {canEvolve && evolvedItem && (
                                      <div className="pt-2 border-t border-border">
                                        <p className="text-xs text-muted-foreground mb-2 flex items-center gap-1">
                                          <TrendingUp className="h-3 w-3" />
                                          Evolves to: {evolvedItem.name}
                                        </p>
                                        <Button
                                          size="sm"
                                          className="w-full"
                                          onClick={() => evolveMutation.mutate(item.id)}
                                          disabled={evolveMutation.isPending || (profile && evolvedItem.required_level > profile.level)}
                                        >
                                          {evolveMutation.isPending ? "Evolving..." : 
                                           (profile && evolvedItem.required_level > profile.level) ? 
                                           `Req. Lvl ${evolvedItem.required_level}` : "Evolve (500 coins)"}
                                        </Button>
                                      </div>
                                    )}

                                    {/* Status */}
                                    {isEquipped && (
                                      <Badge className="w-full justify-center bg-primary">
                                        Equipped
                                      </Badge>
                                    )}
                                    {isOwned && !isEquipped && (
                                      <Badge variant="outline" className="w-full justify-center">
                                        Owned
                                      </Badge>
                                    )}
                                  </div>
                                </CardContent>
                              </Card>
                            </motion.div>
                          );
                        })}
                    </div>
                  )}
                </div>
              </TabsContent>
            )}

          </Tabs>
        </div>
      </main>
    </div>
  );
}
