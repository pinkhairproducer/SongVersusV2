import { supabase } from "@/integrations/supabase/client";
import { User, Session } from "@supabase/supabase-js";

export { supabase, type User, type Session };
