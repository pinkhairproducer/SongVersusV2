export type Json =
  | string
  | number
  | boolean
  | null
  | { [key: string]: Json | undefined }
  | Json[]

export type Database = {
  // Allows to automatically instantiate createClient with right options
  // instead of createClient<Database, { PostgrestVersion: 'XX' }>(URL, KEY)
  __InternalSupabase: {
    PostgrestVersion: "13.0.5"
  }
  public: {
    Tables: {
      battle_comments: {
        Row: {
          battle_id: string
          comment: string
          created_at: string
          id: string
          user_id: string
        }
        Insert: {
          battle_id: string
          comment: string
          created_at?: string
          id?: string
          user_id: string
        }
        Update: {
          battle_id?: string
          comment?: string
          created_at?: string
          id?: string
          user_id?: string
        }
        Relationships: [
          {
            foreignKeyName: "battle_comments_battle_id_fkey"
            columns: ["battle_id"]
            isOneToOne: false
            referencedRelation: "battles"
            referencedColumns: ["id"]
          },
        ]
      }
      battle_votes: {
        Row: {
          battle_id: string
          created_at: string
          id: string
          user_id: string
          voted_for: string
        }
        Insert: {
          battle_id: string
          created_at?: string
          id?: string
          user_id: string
          voted_for: string
        }
        Update: {
          battle_id?: string
          created_at?: string
          id?: string
          user_id?: string
          voted_for?: string
        }
        Relationships: [
          {
            foreignKeyName: "battle_votes_battle_id_fkey"
            columns: ["battle_id"]
            isOneToOne: false
            referencedRelation: "battles"
            referencedColumns: ["id"]
          },
        ]
      }
      battles: {
        Row: {
          battle_type: string
          created_at: string
          creator_audio_url: string | null
          creator_id: string
          creator_votes: number
          ends_at: string | null
          genre: string | null
          id: string
          opponent_audio_url: string | null
          opponent_id: string | null
          opponent_votes: number
          status: string
          updated_at: string
        }
        Insert: {
          battle_type?: string
          created_at?: string
          creator_audio_url?: string | null
          creator_id: string
          creator_votes?: number
          ends_at?: string | null
          genre?: string | null
          id?: string
          opponent_audio_url?: string | null
          opponent_id?: string | null
          opponent_votes?: number
          status?: string
          updated_at?: string
        }
        Update: {
          battle_type?: string
          created_at?: string
          creator_audio_url?: string | null
          creator_id?: string
          creator_votes?: number
          ends_at?: string | null
          genre?: string | null
          id?: string
          opponent_audio_url?: string | null
          opponent_id?: string | null
          opponent_votes?: number
          status?: string
          updated_at?: string
        }
        Relationships: [
          {
            foreignKeyName: "battles_creator_id_fkey"
            columns: ["creator_id"]
            isOneToOne: false
            referencedRelation: "profiles"
            referencedColumns: ["user_id"]
          },
          {
            foreignKeyName: "battles_opponent_id_fkey"
            columns: ["opponent_id"]
            isOneToOne: false
            referencedRelation: "profiles"
            referencedColumns: ["user_id"]
          },
        ]
      }
      character_assignments: {
        Row: {
          accessory_item_id: string | null
          created_at: string
          effect_item_id: string | null
          eyes_item_id: string | null
          hair_item_id: string | null
          id: string
          outfit_item_id: string | null
          skin_item_id: string | null
          user_id: string
        }
        Insert: {
          accessory_item_id?: string | null
          created_at?: string
          effect_item_id?: string | null
          eyes_item_id?: string | null
          hair_item_id?: string | null
          id?: string
          outfit_item_id?: string | null
          skin_item_id?: string | null
          user_id: string
        }
        Update: {
          accessory_item_id?: string | null
          created_at?: string
          effect_item_id?: string | null
          eyes_item_id?: string | null
          hair_item_id?: string | null
          id?: string
          outfit_item_id?: string | null
          skin_item_id?: string | null
          user_id?: string
        }
        Relationships: [
          {
            foreignKeyName: "character_assignments_accessory_item_id_fkey"
            columns: ["accessory_item_id"]
            isOneToOne: false
            referencedRelation: "customization_items"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "character_assignments_effect_item_id_fkey"
            columns: ["effect_item_id"]
            isOneToOne: false
            referencedRelation: "customization_items"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "character_assignments_eyes_item_id_fkey"
            columns: ["eyes_item_id"]
            isOneToOne: false
            referencedRelation: "customization_items"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "character_assignments_hair_item_id_fkey"
            columns: ["hair_item_id"]
            isOneToOne: false
            referencedRelation: "customization_items"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "character_assignments_outfit_item_id_fkey"
            columns: ["outfit_item_id"]
            isOneToOne: false
            referencedRelation: "customization_items"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "character_assignments_skin_item_id_fkey"
            columns: ["skin_item_id"]
            isOneToOne: false
            referencedRelation: "customization_items"
            referencedColumns: ["id"]
          },
        ]
      }
      chat_messages: {
        Row: {
          created_at: string
          id: string
          message: string
          user_id: string
          username: string
        }
        Insert: {
          created_at?: string
          id?: string
          message: string
          user_id: string
          username: string
        }
        Update: {
          created_at?: string
          id?: string
          message?: string
          user_id?: string
          username?: string
        }
        Relationships: []
      }
      customization_items: {
        Row: {
          category: Database["public"]["Enums"]["customization_category"]
          created_at: string
          description: string | null
          evolution_tier: string | null
          evolved_from: string | null
          id: string
          image_url: string | null
          is_starter: boolean
          name: string
          rarity: Database["public"]["Enums"]["rarity"]
          required_level: number | null
        }
        Insert: {
          category: Database["public"]["Enums"]["customization_category"]
          created_at?: string
          description?: string | null
          evolution_tier?: string | null
          evolved_from?: string | null
          id?: string
          image_url?: string | null
          is_starter?: boolean
          name: string
          rarity?: Database["public"]["Enums"]["rarity"]
          required_level?: number | null
        }
        Update: {
          category?: Database["public"]["Enums"]["customization_category"]
          created_at?: string
          description?: string | null
          evolution_tier?: string | null
          evolved_from?: string | null
          id?: string
          image_url?: string | null
          is_starter?: boolean
          name?: string
          rarity?: Database["public"]["Enums"]["rarity"]
          required_level?: number | null
        }
        Relationships: [
          {
            foreignKeyName: "customization_items_evolved_from_fkey"
            columns: ["evolved_from"]
            isOneToOne: false
            referencedRelation: "customization_items"
            referencedColumns: ["id"]
          },
        ]
      }
      daily_logins: {
        Row: {
          coins_awarded: number
          created_at: string | null
          id: string
          login_date: string
          user_id: string
        }
        Insert: {
          coins_awarded?: number
          created_at?: string | null
          id?: string
          login_date?: string
          user_id: string
        }
        Update: {
          coins_awarded?: number
          created_at?: string | null
          id?: string
          login_date?: string
          user_id?: string
        }
        Relationships: []
      }
      daily_spins: {
        Row: {
          created_at: string
          id: string
          spin_date: string
          user_id: string
        }
        Insert: {
          created_at?: string
          id?: string
          spin_date?: string
          user_id: string
        }
        Update: {
          created_at?: string
          id?: string
          spin_date?: string
          user_id?: string
        }
        Relationships: []
      }
      membership_tiers: {
        Row: {
          billing_period: string
          coin_multiplier: number
          created_at: string
          description: string | null
          features: Json
          id: string
          is_active: boolean
          max_battles_per_day: number | null
          name: string
          price: number
          sort_order: number
          xp_multiplier: number
        }
        Insert: {
          billing_period?: string
          coin_multiplier?: number
          created_at?: string
          description?: string | null
          features?: Json
          id?: string
          is_active?: boolean
          max_battles_per_day?: number | null
          name: string
          price?: number
          sort_order?: number
          xp_multiplier?: number
        }
        Update: {
          billing_period?: string
          coin_multiplier?: number
          created_at?: string
          description?: string | null
          features?: Json
          id?: string
          is_active?: boolean
          max_battles_per_day?: number | null
          name?: string
          price?: number
          sort_order?: number
          xp_multiplier?: number
        }
        Relationships: []
      }
      notifications: {
        Row: {
          created_at: string
          id: string
          is_read: boolean
          message: string
          related_battle_id: string | null
          type: string
          user_id: string
        }
        Insert: {
          created_at?: string
          id?: string
          is_read?: boolean
          message: string
          related_battle_id?: string | null
          type: string
          user_id: string
        }
        Update: {
          created_at?: string
          id?: string
          is_read?: boolean
          message?: string
          related_battle_id?: string | null
          type?: string
          user_id?: string
        }
        Relationships: []
      }
      orbs: {
        Row: {
          can_open_at: string
          created_at: string
          id: string
          is_opened: boolean
          opened_at: string | null
          rarity: Database["public"]["Enums"]["rarity"]
          user_id: string
        }
        Insert: {
          can_open_at: string
          created_at?: string
          id?: string
          is_opened?: boolean
          opened_at?: string | null
          rarity?: Database["public"]["Enums"]["rarity"]
          user_id: string
        }
        Update: {
          can_open_at?: string
          created_at?: string
          id?: string
          is_opened?: boolean
          opened_at?: string | null
          rarity?: Database["public"]["Enums"]["rarity"]
          user_id?: string
        }
        Relationships: []
      }
      profiles: {
        Row: {
          avatar_url: string | null
          battles_lost: number
          battles_won: number
          bio: string | null
          coins: number
          created_at: string
          gems: number
          id: string
          level: number
          role: Database["public"]["Enums"]["player_role"] | null
          updated_at: string
          user_id: string
          username: string
          xp: number
        }
        Insert: {
          avatar_url?: string | null
          battles_lost?: number
          battles_won?: number
          bio?: string | null
          coins?: number
          created_at?: string
          gems?: number
          id?: string
          level?: number
          role?: Database["public"]["Enums"]["player_role"] | null
          updated_at?: string
          user_id: string
          username: string
          xp?: number
        }
        Update: {
          avatar_url?: string | null
          battles_lost?: number
          battles_won?: number
          bio?: string | null
          coins?: number
          created_at?: string
          gems?: number
          id?: string
          level?: number
          role?: Database["public"]["Enums"]["player_role"] | null
          updated_at?: string
          user_id?: string
          username?: string
          xp?: number
        }
        Relationships: []
      }
      user_customizations: {
        Row: {
          acquired_at: string
          customization_item_id: string
          id: string
          is_equipped: boolean
          user_id: string
        }
        Insert: {
          acquired_at?: string
          customization_item_id: string
          id?: string
          is_equipped?: boolean
          user_id: string
        }
        Update: {
          acquired_at?: string
          customization_item_id?: string
          id?: string
          is_equipped?: boolean
          user_id?: string
        }
        Relationships: [
          {
            foreignKeyName: "user_customizations_customization_item_id_fkey"
            columns: ["customization_item_id"]
            isOneToOne: false
            referencedRelation: "customization_items"
            referencedColumns: ["id"]
          },
        ]
      }
      user_memberships: {
        Row: {
          created_at: string
          expires_at: string | null
          id: string
          is_active: boolean
          started_at: string
          tier_id: string
          updated_at: string
          user_id: string
        }
        Insert: {
          created_at?: string
          expires_at?: string | null
          id?: string
          is_active?: boolean
          started_at?: string
          tier_id: string
          updated_at?: string
          user_id: string
        }
        Update: {
          created_at?: string
          expires_at?: string | null
          id?: string
          is_active?: boolean
          started_at?: string
          tier_id?: string
          updated_at?: string
          user_id?: string
        }
        Relationships: [
          {
            foreignKeyName: "user_memberships_tier_id_fkey"
            columns: ["tier_id"]
            isOneToOne: false
            referencedRelation: "membership_tiers"
            referencedColumns: ["id"]
          },
        ]
      }
    }
    Views: {
      [_ in never]: never
    }
    Functions: {
      add_coins: {
        Args: { p_amount: number; p_user_id: string }
        Returns: undefined
      }
      can_unlock_item: {
        Args: { p_item_id: string; p_user_id: string }
        Returns: boolean
      }
      check_finished_battles: { Args: never; Returns: undefined }
      claim_daily_reward: { Args: never; Returns: Json }
      deduct_coins: {
        Args: { p_amount: number; p_user_id: string }
        Returns: boolean
      }
      evolve_item: {
        Args: { p_base_item_id: string; p_user_id: string }
        Returns: Json
      }
      record_battle_vote: {
        Args: { p_battle_id: string; p_user_id: string; p_voted_for: string }
        Returns: undefined
      }
      use_daily_free_spin: { Args: never; Returns: Json }
    }
    Enums: {
      customization_category:
        | "skin"
        | "hair"
        | "eyes"
        | "outfit"
        | "accessory"
        | "effect"
      player_role: "producer" | "artist" | "both"
      rarity: "common" | "rare" | "epic" | "legendary"
    }
    CompositeTypes: {
      [_ in never]: never
    }
  }
}

type DatabaseWithoutInternals = Omit<Database, "__InternalSupabase">

type DefaultSchema = DatabaseWithoutInternals[Extract<keyof Database, "public">]

export type Tables<
  DefaultSchemaTableNameOrOptions extends
    | keyof (DefaultSchema["Tables"] & DefaultSchema["Views"])
    | { schema: keyof DatabaseWithoutInternals },
  TableName extends DefaultSchemaTableNameOrOptions extends {
    schema: keyof DatabaseWithoutInternals
  }
    ? keyof (DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Tables"] &
        DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Views"])
    : never = never,
> = DefaultSchemaTableNameOrOptions extends {
  schema: keyof DatabaseWithoutInternals
}
  ? (DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Tables"] &
      DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Views"])[TableName] extends {
      Row: infer R
    }
    ? R
    : never
  : DefaultSchemaTableNameOrOptions extends keyof (DefaultSchema["Tables"] &
        DefaultSchema["Views"])
    ? (DefaultSchema["Tables"] &
        DefaultSchema["Views"])[DefaultSchemaTableNameOrOptions] extends {
        Row: infer R
      }
      ? R
      : never
    : never

export type TablesInsert<
  DefaultSchemaTableNameOrOptions extends
    | keyof DefaultSchema["Tables"]
    | { schema: keyof DatabaseWithoutInternals },
  TableName extends DefaultSchemaTableNameOrOptions extends {
    schema: keyof DatabaseWithoutInternals
  }
    ? keyof DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Tables"]
    : never = never,
> = DefaultSchemaTableNameOrOptions extends {
  schema: keyof DatabaseWithoutInternals
}
  ? DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Tables"][TableName] extends {
      Insert: infer I
    }
    ? I
    : never
  : DefaultSchemaTableNameOrOptions extends keyof DefaultSchema["Tables"]
    ? DefaultSchema["Tables"][DefaultSchemaTableNameOrOptions] extends {
        Insert: infer I
      }
      ? I
      : never
    : never

export type TablesUpdate<
  DefaultSchemaTableNameOrOptions extends
    | keyof DefaultSchema["Tables"]
    | { schema: keyof DatabaseWithoutInternals },
  TableName extends DefaultSchemaTableNameOrOptions extends {
    schema: keyof DatabaseWithoutInternals
  }
    ? keyof DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Tables"]
    : never = never,
> = DefaultSchemaTableNameOrOptions extends {
  schema: keyof DatabaseWithoutInternals
}
  ? DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Tables"][TableName] extends {
      Update: infer U
    }
    ? U
    : never
  : DefaultSchemaTableNameOrOptions extends keyof DefaultSchema["Tables"]
    ? DefaultSchema["Tables"][DefaultSchemaTableNameOrOptions] extends {
        Update: infer U
      }
      ? U
      : never
    : never

export type Enums<
  DefaultSchemaEnumNameOrOptions extends
    | keyof DefaultSchema["Enums"]
    | { schema: keyof DatabaseWithoutInternals },
  EnumName extends DefaultSchemaEnumNameOrOptions extends {
    schema: keyof DatabaseWithoutInternals
  }
    ? keyof DatabaseWithoutInternals[DefaultSchemaEnumNameOrOptions["schema"]]["Enums"]
    : never = never,
> = DefaultSchemaEnumNameOrOptions extends {
  schema: keyof DatabaseWithoutInternals
}
  ? DatabaseWithoutInternals[DefaultSchemaEnumNameOrOptions["schema"]]["Enums"][EnumName]
  : DefaultSchemaEnumNameOrOptions extends keyof DefaultSchema["Enums"]
    ? DefaultSchema["Enums"][DefaultSchemaEnumNameOrOptions]
    : never

export type CompositeTypes<
  PublicCompositeTypeNameOrOptions extends
    | keyof DefaultSchema["CompositeTypes"]
    | { schema: keyof DatabaseWithoutInternals },
  CompositeTypeName extends PublicCompositeTypeNameOrOptions extends {
    schema: keyof DatabaseWithoutInternals
  }
    ? keyof DatabaseWithoutInternals[PublicCompositeTypeNameOrOptions["schema"]]["CompositeTypes"]
    : never = never,
> = PublicCompositeTypeNameOrOptions extends {
  schema: keyof DatabaseWithoutInternals
}
  ? DatabaseWithoutInternals[PublicCompositeTypeNameOrOptions["schema"]]["CompositeTypes"][CompositeTypeName]
  : PublicCompositeTypeNameOrOptions extends keyof DefaultSchema["CompositeTypes"]
    ? DefaultSchema["CompositeTypes"][PublicCompositeTypeNameOrOptions]
    : never

export const Constants = {
  public: {
    Enums: {
      customization_category: [
        "skin",
        "hair",
        "eyes",
        "outfit",
        "accessory",
        "effect",
      ],
      player_role: ["producer", "artist", "both"],
      rarity: ["common", "rare", "epic", "legendary"],
    },
  },
} as const
