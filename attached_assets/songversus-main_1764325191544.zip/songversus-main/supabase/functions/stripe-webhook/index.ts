import { serve } from "https://deno.land/std@0.190.0/http/server.ts";
import Stripe from "https://esm.sh/stripe@18.5.0";
import { createClient } from "https://esm.sh/@supabase/supabase-js@2.57.2";

const stripe = new Stripe(Deno.env.get("STRIPE_SECRET_KEY") || "", {
  apiVersion: "2025-08-27.basil",
});

const cryptoProvider = Stripe.createSubtleCryptoProvider();

console.log("Stripe webhook handler loaded");

serve(async (request) => {
  const signature = request.headers.get("Stripe-Signature");
  const webhookSecret = Deno.env.get("STRIPE_WEBHOOK_SECRET");

  if (!webhookSecret) {
    console.error("STRIPE_WEBHOOK_SECRET not configured");
    return new Response("Webhook secret not configured", { status: 500 });
  }

  if (!signature) {
    console.error("No Stripe signature found");
    return new Response("No signature", { status: 400 });
  }

  const body = await request.text();
  let event;

  try {
    event = await stripe.webhooks.constructEventAsync(
      body,
      signature,
      webhookSecret,
      undefined,
      cryptoProvider
    );
    console.log("Webhook event received:", event.type);
  } catch (err) {
    const errorMessage = err instanceof Error ? err.message : "Unknown error";
    console.error("Webhook signature verification failed:", errorMessage);
    return new Response(JSON.stringify({ error: errorMessage }), { status: 400 });
  }

  const supabaseClient = createClient(
    Deno.env.get("SUPABASE_URL") ?? "",
    Deno.env.get("SUPABASE_SERVICE_ROLE_KEY") ?? ""
  );

  // Handle checkout.session.completed event
  if (event.type === "checkout.session.completed") {
    const session = event.data.object as Stripe.Checkout.Session;
    console.log("Processing checkout session:", session.id);

    const userId = session.metadata?.user_id;
    
    if (!userId) {
      console.error("No user_id in session metadata");
      return new Response(JSON.stringify({ error: "No user_id" }), { status: 400 });
    }

    // Get line items to determine coin amount
    const lineItems = await stripe.checkout.sessions.listLineItems(session.id);
    const priceId = lineItems.data[0]?.price?.id;

    // Map price IDs to coin amounts
    const coinMapping: Record<string, number> = {
      "price_1SV18VA74KlR7uVLxeukKII3": 100, // Starter Pack
      "price_1SV18jA74KlR7uVLmnAQEHff": 500, // Popular Pack
      "price_1SV18vA74KlR7uVLETo8yvZw": 1000, // Power Pack
      "price_1SV19AA74KlR7uVLIzwZK3xc": 2500, // Ultimate Pack
    };

    const coinsToAdd = priceId ? coinMapping[priceId] : 0;

    if (!coinsToAdd) {
      console.error("Unknown price ID:", priceId);
      return new Response(JSON.stringify({ error: "Unknown price" }), { status: 400 });
    }

    console.log(`Adding ${coinsToAdd} coins to user ${userId}`);

    // Add coins using the database function
    const { error } = await supabaseClient.rpc("add_coins", {
      p_user_id: userId,
      p_amount: coinsToAdd,
    });

    if (error) {
      console.error("Error adding coins:", error);
      return new Response(JSON.stringify({ error: error.message }), { status: 500 });
    }

    console.log(`Successfully added ${coinsToAdd} coins to user ${userId}`);
  }

  return new Response(JSON.stringify({ received: true }), { status: 200 });
});
