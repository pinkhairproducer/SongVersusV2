CREATE OR REPLACE FUNCTION public.claim_daily_reward()
 RETURNS jsonb
 LANGUAGE plpgsql
 SECURITY DEFINER
 SET search_path TO 'public'
AS $function$
DECLARE
  v_user_id uuid;
  v_already_claimed boolean;
  v_coins_awarded integer := 10;
  v_streak integer := 0;
BEGIN
  -- Get current user
  v_user_id := auth.uid();
  
  IF v_user_id IS NULL THEN
    RETURN jsonb_build_object('success', false, 'message', 'Not authenticated');
  END IF;
  
  -- Check if already claimed today
  SELECT EXISTS (
    SELECT 1 FROM daily_logins 
    WHERE user_id = v_user_id 
    AND login_date = CURRENT_DATE
  ) INTO v_already_claimed;
  
  IF v_already_claimed THEN
    RETURN jsonb_build_object('success', false, 'message', 'Already claimed today');
  END IF;
  
  -- Calculate streak (consecutive days)
  SELECT COUNT(*) INTO v_streak
  FROM (
    SELECT login_date,
           login_date - LAG(login_date, 1, login_date) OVER (ORDER BY login_date) as diff
    FROM daily_logins
    WHERE user_id = v_user_id
    AND login_date >= CURRENT_DATE - INTERVAL '30 days'
    ORDER BY login_date DESC
  ) streaks
  WHERE diff <= 1;
  
  -- Bonus coins for streaks (every 7 days adds 5 bonus coins)
  v_coins_awarded := v_coins_awarded + (FLOOR(v_streak / 7) * 5)::integer;
  
  -- Record the login
  INSERT INTO daily_logins (user_id, login_date, coins_awarded)
  VALUES (v_user_id, CURRENT_DATE, v_coins_awarded);
  
  -- Award coins
  PERFORM public.add_coins(v_user_id, v_coins_awarded);
  
  RETURN jsonb_build_object(
    'success', true, 
    'coins_awarded', v_coins_awarded,
    'streak', v_streak + 1,
    'message', 'Daily reward claimed!'
  );
END;
$function$;