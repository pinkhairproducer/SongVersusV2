-- Allow authenticated users to join open battles by setting themselves as opponent
-- without already being creator or opponent.

-- Create a permissive UPDATE policy specifically for joining
CREATE POLICY "Users can join open battles"
ON public.battles
FOR UPDATE
TO authenticated
USING (
  status = 'open' AND opponent_id IS NULL
)
WITH CHECK (
  opponent_id = auth.uid() AND auth.uid() <> creator_id
);
