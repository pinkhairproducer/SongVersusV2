-- Add evolution system fields to customization_items
ALTER TABLE customization_items
ADD COLUMN required_level integer DEFAULT 1,
ADD COLUMN evolved_from uuid REFERENCES customization_items(id) ON DELETE SET NULL,
ADD COLUMN evolution_tier text DEFAULT 'base' CHECK (evolution_tier IN ('base', 'evolved', 'ultimate'));

-- Add index for efficient queries
CREATE INDEX idx_customization_items_required_level ON customization_items(required_level);
CREATE INDEX idx_customization_items_evolved_from ON customization_items(evolved_from);

-- Create function to check if user can unlock item based on level
CREATE OR REPLACE FUNCTION public.can_unlock_item(p_user_id uuid, p_item_id uuid)
RETURNS boolean
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = 'public'
AS $$
DECLARE
  user_level integer;
  required_level integer;
BEGIN
  -- Get user's current level
  SELECT level INTO user_level
  FROM profiles
  WHERE user_id = p_user_id;
  
  -- Get item's required level
  SELECT customization_items.required_level INTO required_level
  FROM customization_items
  WHERE id = p_item_id;
  
  RETURN user_level >= required_level;
END;
$$;

-- Create function to evolve an item (upgrade equipped item to next tier)
CREATE OR REPLACE FUNCTION public.evolve_item(p_user_id uuid, p_base_item_id uuid)
RETURNS jsonb
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = 'public'
AS $$
DECLARE
  v_evolved_item_id uuid;
  v_user_coins integer;
  v_evolution_cost integer := 500; -- Cost to evolve
  v_user_level integer;
  v_required_level integer;
BEGIN
  -- Get user's level and coins
  SELECT level, coins INTO v_user_level, v_user_coins
  FROM profiles
  WHERE user_id = p_user_id;
  
  -- Find the evolved version of this item
  SELECT id, required_level INTO v_evolved_item_id, v_required_level
  FROM customization_items
  WHERE evolved_from = p_base_item_id
  LIMIT 1;
  
  -- Check if evolved version exists
  IF v_evolved_item_id IS NULL THEN
    RETURN jsonb_build_object('success', false, 'message', 'No evolved version available');
  END IF;
  
  -- Check if user meets level requirement
  IF v_user_level < v_required_level THEN
    RETURN jsonb_build_object(
      'success', false, 
      'message', 'Level ' || v_required_level || ' required to evolve this item'
    );
  END IF;
  
  -- Check if user has enough coins
  IF v_user_coins < v_evolution_cost THEN
    RETURN jsonb_build_object('success', false, 'message', 'Not enough coins');
  END IF;
  
  -- Deduct coins
  UPDATE profiles
  SET coins = coins - v_evolution_cost
  WHERE user_id = p_user_id;
  
  -- Unequip the base item
  UPDATE user_customizations
  SET is_equipped = false
  WHERE user_id = p_user_id AND customization_item_id = p_base_item_id;
  
  -- Add evolved item to user's collection
  INSERT INTO user_customizations (user_id, customization_item_id, is_equipped)
  VALUES (p_user_id, v_evolved_item_id, true)
  ON CONFLICT (user_id, customization_item_id) 
  DO UPDATE SET is_equipped = true;
  
  RETURN jsonb_build_object(
    'success', true, 
    'evolved_item_id', v_evolved_item_id,
    'message', 'Item evolved successfully!'
  );
END;
$$;