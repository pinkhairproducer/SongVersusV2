-- Create a function to deduct coins safely
CREATE OR REPLACE FUNCTION public.deduct_coins(
  p_user_id uuid,
  p_amount integer
)
RETURNS boolean
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public
AS $$
DECLARE
  current_coins integer;
BEGIN
  -- Get current coin balance with row lock
  SELECT coins INTO current_coins
  FROM profiles
  WHERE user_id = p_user_id
  FOR UPDATE;
  
  -- Check if user has enough coins
  IF current_coins < p_amount THEN
    RETURN false;
  END IF;
  
  -- Deduct coins
  UPDATE profiles
  SET coins = coins - p_amount
  WHERE user_id = p_user_id;
  
  RETURN true;
END;
$$;

-- Create a function to add coins
CREATE OR REPLACE FUNCTION public.add_coins(
  p_user_id uuid,
  p_amount integer
)
RETURNS void
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public
AS $$
BEGIN
  UPDATE profiles
  SET coins = coins + p_amount
  WHERE user_id = p_user_id;
END;
$$;

-- Create a trigger to reward users for voting
CREATE OR REPLACE FUNCTION public.reward_vote()
RETURNS TRIGGER
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public
AS $$
BEGIN
  -- Add 5 coins for voting
  PERFORM public.add_coins(NEW.user_id, 5);
  RETURN NEW;
END;
$$;

CREATE TRIGGER on_battle_vote_reward
  AFTER INSERT ON battle_votes
  FOR EACH ROW
  EXECUTE FUNCTION public.reward_vote();

-- Create a trigger to reward users for commenting
CREATE OR REPLACE FUNCTION public.reward_comment()
RETURNS TRIGGER
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public
AS $$
BEGIN
  -- Add 3 coins for commenting
  PERFORM public.add_coins(NEW.user_id, 3);
  RETURN NEW;
END;
$$;

CREATE TRIGGER on_battle_comment_reward
  AFTER INSERT ON battle_comments
  FOR EACH ROW
  EXECUTE FUNCTION public.reward_comment();