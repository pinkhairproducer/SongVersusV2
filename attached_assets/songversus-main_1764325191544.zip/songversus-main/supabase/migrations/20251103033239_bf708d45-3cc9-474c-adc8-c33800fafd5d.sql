-- Add foreign key constraints to battles table for creator and opponent profiles
ALTER TABLE public.battles
ADD CONSTRAINT battles_creator_id_fkey 
FOREIGN KEY (creator_id) 
REFERENCES public.profiles(user_id) 
ON DELETE CASCADE;

ALTER TABLE public.battles
ADD CONSTRAINT battles_opponent_id_fkey 
FOREIGN KEY (opponent_id) 
REFERENCES public.profiles(user_id) 
ON DELETE SET NULL;