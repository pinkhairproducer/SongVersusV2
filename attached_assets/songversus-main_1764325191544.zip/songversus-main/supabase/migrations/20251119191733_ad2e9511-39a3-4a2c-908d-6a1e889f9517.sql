-- Clear existing membership tiers and create exactly 3 tiers
DELETE FROM membership_tiers;

-- Insert 3 membership tiers
INSERT INTO membership_tiers (name, description, price, billing_period, coin_multiplier, xp_multiplier, max_battles_per_day, features, sort_order, is_active)
VALUES 
  (
    'Basic',
    'Perfect for getting started',
    0,
    'monthly',
    1.0,
    1.0,
    5,
    '["Access to all battles", "Daily rewards", "Basic customizations"]'::jsonb,
    1,
    true
  ),
  (
    'Pro',
    'For serious competitors',
    999,
    'monthly',
    1.5,
    1.5,
    15,
    '["Everything in Basic", "1.5x coin multiplier", "1.5x XP multiplier", "15 battles per day", "Priority support", "Exclusive skins"]'::jsonb,
    2,
    true
  ),
  (
    'Elite',
    'The ultimate experience',
    1999,
    'monthly',
    2.0,
    2.0,
    NULL,
    '["Everything in Pro", "2x coin multiplier", "2x XP multiplier", "Unlimited battles", "Early access to features", "Rare customizations", "Custom profile badge"]'::jsonb,
    3,
    true
  );