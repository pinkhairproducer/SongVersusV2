-- Create battles table
CREATE TABLE public.battles (
  id uuid NOT NULL DEFAULT gen_random_uuid() PRIMARY KEY,
  created_at timestamp with time zone NOT NULL DEFAULT now(),
  updated_at timestamp with time zone NOT NULL DEFAULT now(),
  status text NOT NULL DEFAULT 'open' CHECK (status IN ('open', 'ongoing', 'completed')),
  genre text,
  battle_type text NOT NULL DEFAULT 'producer' CHECK (battle_type IN ('producer', 'artist', 'both')),
  creator_id uuid NOT NULL,
  creator_audio_url text,
  opponent_id uuid,
  opponent_audio_url text,
  creator_votes integer NOT NULL DEFAULT 0,
  opponent_votes integer NOT NULL DEFAULT 0,
  ends_at timestamp with time zone
);

-- Enable RLS
ALTER TABLE public.battles ENABLE ROW LEVEL SECURITY;

-- Policies for battles
CREATE POLICY "Anyone can view battles"
ON public.battles FOR SELECT
USING (true);

CREATE POLICY "Users can create battles"
ON public.battles FOR INSERT
WITH CHECK (auth.uid() = creator_id);

CREATE POLICY "Users can update their own battles"
ON public.battles FOR UPDATE
USING (auth.uid() = creator_id OR auth.uid() = opponent_id);

-- Create battle_comments table
CREATE TABLE public.battle_comments (
  id uuid NOT NULL DEFAULT gen_random_uuid() PRIMARY KEY,
  created_at timestamp with time zone NOT NULL DEFAULT now(),
  battle_id uuid NOT NULL REFERENCES public.battles(id) ON DELETE CASCADE,
  user_id uuid NOT NULL,
  comment text NOT NULL
);

-- Enable RLS
ALTER TABLE public.battle_comments ENABLE ROW LEVEL SECURITY;

-- Policies for battle_comments
CREATE POLICY "Anyone can view comments"
ON public.battle_comments FOR SELECT
USING (true);

CREATE POLICY "Authenticated users can create comments"
ON public.battle_comments FOR INSERT
WITH CHECK (auth.uid() = user_id);

CREATE POLICY "Users can delete their own comments"
ON public.battle_comments FOR DELETE
USING (auth.uid() = user_id);

-- Create battle_votes table to track who voted
CREATE TABLE public.battle_votes (
  id uuid NOT NULL DEFAULT gen_random_uuid() PRIMARY KEY,
  created_at timestamp with time zone NOT NULL DEFAULT now(),
  battle_id uuid NOT NULL REFERENCES public.battles(id) ON DELETE CASCADE,
  user_id uuid NOT NULL,
  voted_for text NOT NULL CHECK (voted_for IN ('creator', 'opponent')),
  UNIQUE(battle_id, user_id)
);

-- Enable RLS
ALTER TABLE public.battle_votes ENABLE ROW LEVEL SECURITY;

-- Policies for battle_votes
CREATE POLICY "Anyone can view votes"
ON public.battle_votes FOR SELECT
USING (true);

CREATE POLICY "Authenticated users can vote"
ON public.battle_votes FOR INSERT
WITH CHECK (auth.uid() = user_id);

CREATE POLICY "Users can update their own votes"
ON public.battle_votes FOR UPDATE
USING (auth.uid() = user_id);

-- Trigger for updating battles updated_at
CREATE TRIGGER update_battles_updated_at
BEFORE UPDATE ON public.battles
FOR EACH ROW
EXECUTE FUNCTION public.update_updated_at_column();