-- Fix character assignment to handle optional categories (accessory, effect)
-- These categories may not have starter items, so we allow NULL values

DROP TRIGGER IF EXISTS on_profile_created_assign_character ON public.profiles;
DROP FUNCTION IF EXISTS public.assign_unique_character();

-- Create improved function that handles optional categories gracefully
CREATE OR REPLACE FUNCTION public.assign_unique_character()
RETURNS TRIGGER
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public
AS $$
DECLARE
  v_skin_id uuid;
  v_hair_id uuid;
  v_eyes_id uuid;
  v_outfit_id uuid;
  v_accessory_id uuid;
  v_effect_id uuid;
  v_attempt integer := 0;
  v_max_attempts integer := 100;
  v_combination_exists boolean;
BEGIN
  -- Loop to find a unique combination
  LOOP
    v_attempt := v_attempt + 1;
    
    -- Exit if too many attempts
    IF v_attempt > v_max_attempts THEN
      RAISE EXCEPTION 'Could not find unique character combination after % attempts', v_max_attempts;
    END IF;
    
    -- Select random starter items for REQUIRED categories
    SELECT id INTO v_skin_id
    FROM customization_items
    WHERE category = 'skin' AND is_starter = true
    ORDER BY md5(id::text || NEW.user_id::text || v_attempt::text)
    LIMIT 1;
    
    SELECT id INTO v_hair_id
    FROM customization_items
    WHERE category = 'hair' AND is_starter = true
    ORDER BY md5(id::text || NEW.user_id::text || v_attempt::text)
    LIMIT 1;
    
    SELECT id INTO v_eyes_id
    FROM customization_items
    WHERE category = 'eyes' AND is_starter = true
    ORDER BY md5(id::text || NEW.user_id::text || v_attempt::text)
    LIMIT 1;
    
    SELECT id INTO v_outfit_id
    FROM customization_items
    WHERE category = 'outfit' AND is_starter = true
    ORDER BY md5(id::text || NEW.user_id::text || v_attempt::text)
    LIMIT 1;
    
    -- OPTIONAL categories (may not have starter items)
    -- Use NULL if no items exist
    SELECT id INTO v_accessory_id
    FROM customization_items
    WHERE category = 'accessory' AND is_starter = true
    ORDER BY md5(id::text || NEW.user_id::text || v_attempt::text)
    LIMIT 1;
    
    SELECT id INTO v_effect_id
    FROM customization_items
    WHERE category = 'effect' AND is_starter = true
    ORDER BY md5(id::text || NEW.user_id::text || v_attempt::text)
    LIMIT 1;
    
    -- Check if this combination already exists
    -- Only check based on required items (skin, hair, eyes, outfit)
    SELECT EXISTS(
      SELECT 1 FROM character_assignments
      WHERE skin_item_id = v_skin_id
        AND hair_item_id = v_hair_id
        AND eyes_item_id = v_eyes_id
        AND outfit_item_id = v_outfit_id
    ) INTO v_combination_exists;
    
    -- If combination is unique, break the loop
    EXIT WHEN NOT v_combination_exists;
  END LOOP;
  
  -- Record the assignment
  INSERT INTO character_assignments (
    user_id, skin_item_id, hair_item_id, eyes_item_id, 
    outfit_item_id, accessory_item_id, effect_item_id
  ) VALUES (
    NEW.user_id, v_skin_id, v_hair_id, v_eyes_id,
    v_outfit_id, v_accessory_id, v_effect_id
  );
  
  -- Assign items to user_customizations (only non-NULL items)
  IF v_skin_id IS NOT NULL THEN
    INSERT INTO user_customizations (user_id, customization_item_id, is_equipped)
    VALUES (NEW.user_id, v_skin_id, true);
  END IF;
  
  IF v_hair_id IS NOT NULL THEN
    INSERT INTO user_customizations (user_id, customization_item_id, is_equipped)
    VALUES (NEW.user_id, v_hair_id, true);
  END IF;
  
  IF v_eyes_id IS NOT NULL THEN
    INSERT INTO user_customizations (user_id, customization_item_id, is_equipped)
    VALUES (NEW.user_id, v_eyes_id, true);
  END IF;
  
  IF v_outfit_id IS NOT NULL THEN
    INSERT INTO user_customizations (user_id, customization_item_id, is_equipped)
    VALUES (NEW.user_id, v_outfit_id, true);
  END IF;
  
  IF v_accessory_id IS NOT NULL THEN
    INSERT INTO user_customizations (user_id, customization_item_id, is_equipped)
    VALUES (NEW.user_id, v_accessory_id, true);
  END IF;
  
  IF v_effect_id IS NOT NULL THEN
    INSERT INTO user_customizations (user_id, customization_item_id, is_equipped)
    VALUES (NEW.user_id, v_effect_id, true);
  END IF;
  
  RETURN NEW;
END;
$$;

-- Recreate the trigger
CREATE TRIGGER on_profile_created_assign_character
AFTER INSERT ON public.profiles
FOR EACH ROW
EXECUTE FUNCTION public.assign_unique_character();

-- Also update the unique constraint to only check required categories
ALTER TABLE public.character_assignments 
DROP CONSTRAINT IF EXISTS character_assignments_skin_item_id_hair_item_id_eyes_item_id_key;

-- Create a new unique constraint on only the required fields
CREATE UNIQUE INDEX IF NOT EXISTS idx_character_assignments_unique_combo
ON public.character_assignments(skin_item_id, hair_item_id, eyes_item_id, outfit_item_id);