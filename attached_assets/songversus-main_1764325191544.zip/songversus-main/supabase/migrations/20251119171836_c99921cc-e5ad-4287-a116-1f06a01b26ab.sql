-- Add unique constraint to battle_votes to support ON CONFLICT
ALTER TABLE battle_votes ADD CONSTRAINT battle_votes_battle_user_unique UNIQUE (battle_id, user_id);

-- Create secure function for recording votes
CREATE OR REPLACE FUNCTION record_battle_vote(
  p_battle_id uuid,
  p_user_id uuid,
  p_voted_for text
)
RETURNS void
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public
AS $$
DECLARE
  v_old_vote text;
BEGIN
  -- Validate voted_for value
  IF p_voted_for NOT IN ('creator', 'opponent') THEN
    RAISE EXCEPTION 'Invalid vote target: must be creator or opponent';
  END IF;

  -- Get existing vote if any
  SELECT voted_for INTO v_old_vote
  FROM battle_votes
  WHERE battle_id = p_battle_id AND user_id = p_user_id;

  -- Update or insert vote
  INSERT INTO battle_votes (battle_id, user_id, voted_for)
  VALUES (p_battle_id, p_user_id, p_voted_for)
  ON CONFLICT (battle_id, user_id) 
  DO UPDATE SET voted_for = p_voted_for, created_at = now();

  -- Recalculate vote counts from actual votes (prevents manipulation)
  UPDATE battles
  SET 
    creator_votes = (SELECT COUNT(*) FROM battle_votes WHERE battle_id = p_battle_id AND voted_for = 'creator'),
    opponent_votes = (SELECT COUNT(*) FROM battle_votes WHERE battle_id = p_battle_id AND voted_for = 'opponent'),
    updated_at = now()
  WHERE id = p_battle_id;
END;
$$;