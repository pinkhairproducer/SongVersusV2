-- Create membership tiers table
CREATE TABLE public.membership_tiers (
  id UUID NOT NULL DEFAULT gen_random_uuid() PRIMARY KEY,
  name TEXT NOT NULL,
  description TEXT,
  price INTEGER NOT NULL DEFAULT 0,
  billing_period TEXT NOT NULL DEFAULT 'monthly',
  features JSONB NOT NULL DEFAULT '[]'::jsonb,
  max_battles_per_day INTEGER,
  xp_multiplier DECIMAL NOT NULL DEFAULT 1.0,
  coin_multiplier DECIMAL NOT NULL DEFAULT 1.0,
  is_active BOOLEAN NOT NULL DEFAULT true,
  sort_order INTEGER NOT NULL DEFAULT 0,
  created_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now()
);

-- Create user memberships table
CREATE TABLE public.user_memberships (
  id UUID NOT NULL DEFAULT gen_random_uuid() PRIMARY KEY,
  user_id UUID NOT NULL,
  tier_id UUID NOT NULL REFERENCES public.membership_tiers(id),
  started_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now(),
  expires_at TIMESTAMP WITH TIME ZONE,
  is_active BOOLEAN NOT NULL DEFAULT true,
  created_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now(),
  updated_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now()
);

-- Enable RLS
ALTER TABLE public.membership_tiers ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.user_memberships ENABLE ROW LEVEL SECURITY;

-- RLS Policies for membership_tiers
CREATE POLICY "Anyone can view active membership tiers"
ON public.membership_tiers
FOR SELECT
USING (is_active = true);

-- RLS Policies for user_memberships
CREATE POLICY "Users can view their own memberships"
ON public.user_memberships
FOR SELECT
USING (auth.uid() = user_id);

CREATE POLICY "Users can insert their own memberships"
ON public.user_memberships
FOR INSERT
WITH CHECK (auth.uid() = user_id);

CREATE POLICY "Users can update their own memberships"
ON public.user_memberships
FOR UPDATE
USING (auth.uid() = user_id);

-- Add trigger for updated_at
CREATE TRIGGER update_user_memberships_updated_at
BEFORE UPDATE ON public.user_memberships
FOR EACH ROW
EXECUTE FUNCTION public.update_updated_at_column();

-- Insert default membership tiers
INSERT INTO public.membership_tiers (name, description, price, billing_period, features, max_battles_per_day, xp_multiplier, coin_multiplier, sort_order) VALUES
('Free', 'Get started with basic features', 0, 'monthly', '["3 battles per day", "Standard XP gain", "Basic character customization", "Community access"]'::jsonb, 3, 1.0, 1.0, 1),
('Pro', 'Unlock more battles and faster progression', 999, 'monthly', '["10 battles per day", "2x XP multiplier", "2x Coin rewards", "Priority matchmaking", "Exclusive character items", "Custom profile badge"]'::jsonb, 10, 2.0, 2.0, 2),
('Elite', 'Maximum power for serious battlers', 1999, 'monthly', '["Unlimited battles", "3x XP multiplier", "3x Coin rewards", "VIP matchmaking", "All exclusive items", "Elite profile badge", "Early access to new features", "Premium support"]'::jsonb, NULL, 3.0, 3.0, 3);