-- Fix search path for update_battle_status function
CREATE OR REPLACE FUNCTION update_battle_status()
RETURNS TRIGGER AS $$
BEGIN
  -- If both players have uploaded audio, set status to ongoing
  IF NEW.creator_audio_url IS NOT NULL 
     AND NEW.opponent_audio_url IS NOT NULL 
     AND NEW.opponent_id IS NOT NULL
     AND NEW.status = 'open' THEN
    NEW.status := 'ongoing';
  END IF;
  
  RETURN NEW;
END;
$$ LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = 'public';