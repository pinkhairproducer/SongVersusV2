-- Create a table to track assigned character combinations for uniqueness
CREATE TABLE IF NOT EXISTS public.character_assignments (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id uuid REFERENCES auth.users(id) ON DELETE CASCADE NOT NULL UNIQUE,
  skin_item_id uuid REFERENCES public.customization_items(id),
  hair_item_id uuid REFERENCES public.customization_items(id),
  eyes_item_id uuid REFERENCES public.customization_items(id),
  outfit_item_id uuid REFERENCES public.customization_items(id),
  accessory_item_id uuid REFERENCES public.customization_items(id),
  effect_item_id uuid REFERENCES public.customization_items(id),
  created_at timestamp with time zone DEFAULT now() NOT NULL,
  UNIQUE(skin_item_id, hair_item_id, eyes_item_id, outfit_item_id, accessory_item_id, effect_item_id)
);

ALTER TABLE public.character_assignments ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Users can view their own character assignment"
ON public.character_assignments FOR SELECT
USING (auth.uid() = user_id);

CREATE POLICY "Users can insert their own character assignment"
ON public.character_assignments FOR INSERT
WITH CHECK (auth.uid() = user_id);

-- Drop existing trigger and function
DROP TRIGGER IF EXISTS on_profile_created_assign_character ON public.profiles;
DROP FUNCTION IF EXISTS public.assign_unique_character();

-- Create improved function that assigns truly unique character combinations
CREATE OR REPLACE FUNCTION public.assign_unique_character()
RETURNS TRIGGER
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public
AS $$
DECLARE
  v_skin_id uuid;
  v_hair_id uuid;
  v_eyes_id uuid;
  v_outfit_id uuid;
  v_accessory_id uuid;
  v_effect_id uuid;
  v_attempt integer := 0;
  v_max_attempts integer := 100;
  v_combination_exists boolean;
BEGIN
  -- Loop to find a unique combination
  LOOP
    v_attempt := v_attempt + 1;
    
    -- Exit if too many attempts
    IF v_attempt > v_max_attempts THEN
      RAISE EXCEPTION 'Could not find unique character combination after % attempts', v_max_attempts;
    END IF;
    
    -- Select random starter items for each category using user_id as seed
    SELECT id INTO v_skin_id
    FROM customization_items
    WHERE category = 'skin' AND is_starter = true
    ORDER BY md5(id::text || NEW.user_id::text || v_attempt::text)
    LIMIT 1;
    
    SELECT id INTO v_hair_id
    FROM customization_items
    WHERE category = 'hair' AND is_starter = true
    ORDER BY md5(id::text || NEW.user_id::text || v_attempt::text)
    LIMIT 1;
    
    SELECT id INTO v_eyes_id
    FROM customization_items
    WHERE category = 'eyes' AND is_starter = true
    ORDER BY md5(id::text || NEW.user_id::text || v_attempt::text)
    LIMIT 1;
    
    SELECT id INTO v_outfit_id
    FROM customization_items
    WHERE category = 'outfit' AND is_starter = true
    ORDER BY md5(id::text || NEW.user_id::text || v_attempt::text)
    LIMIT 1;
    
    SELECT id INTO v_accessory_id
    FROM customization_items
    WHERE category = 'accessory' AND is_starter = true
    ORDER BY md5(id::text || NEW.user_id::text || v_attempt::text)
    LIMIT 1;
    
    SELECT id INTO v_effect_id
    FROM customization_items
    WHERE category = 'effect' AND is_starter = true
    ORDER BY md5(id::text || NEW.user_id::text || v_attempt::text)
    LIMIT 1;
    
    -- Check if this combination already exists
    SELECT EXISTS(
      SELECT 1 FROM character_assignments
      WHERE skin_item_id IS NOT DISTINCT FROM v_skin_id
        AND hair_item_id IS NOT DISTINCT FROM v_hair_id
        AND eyes_item_id IS NOT DISTINCT FROM v_eyes_id
        AND outfit_item_id IS NOT DISTINCT FROM v_outfit_id
        AND accessory_item_id IS NOT DISTINCT FROM v_accessory_id
        AND effect_item_id IS NOT DISTINCT FROM v_effect_id
    ) INTO v_combination_exists;
    
    -- If combination is unique, break the loop
    EXIT WHEN NOT v_combination_exists;
  END LOOP;
  
  -- Record the assignment
  INSERT INTO character_assignments (
    user_id, skin_item_id, hair_item_id, eyes_item_id, 
    outfit_item_id, accessory_item_id, effect_item_id
  ) VALUES (
    NEW.user_id, v_skin_id, v_hair_id, v_eyes_id,
    v_outfit_id, v_accessory_id, v_effect_id
  );
  
  -- Assign items to user_customizations
  IF v_skin_id IS NOT NULL THEN
    INSERT INTO user_customizations (user_id, customization_item_id, is_equipped)
    VALUES (NEW.user_id, v_skin_id, true);
  END IF;
  
  IF v_hair_id IS NOT NULL THEN
    INSERT INTO user_customizations (user_id, customization_item_id, is_equipped)
    VALUES (NEW.user_id, v_hair_id, true);
  END IF;
  
  IF v_eyes_id IS NOT NULL THEN
    INSERT INTO user_customizations (user_id, customization_item_id, is_equipped)
    VALUES (NEW.user_id, v_eyes_id, true);
  END IF;
  
  IF v_outfit_id IS NOT NULL THEN
    INSERT INTO user_customizations (user_id, customization_item_id, is_equipped)
    VALUES (NEW.user_id, v_outfit_id, true);
  END IF;
  
  IF v_accessory_id IS NOT NULL THEN
    INSERT INTO user_customizations (user_id, customization_item_id, is_equipped)
    VALUES (NEW.user_id, v_accessory_id, true);
  END IF;
  
  IF v_effect_id IS NOT NULL THEN
    INSERT INTO user_customizations (user_id, customization_item_id, is_equipped)
    VALUES (NEW.user_id, v_effect_id, true);
  END IF;
  
  RETURN NEW;
END;
$$;

-- Recreate the trigger
CREATE TRIGGER on_profile_created_assign_character
AFTER INSERT ON public.profiles
FOR EACH ROW
EXECUTE FUNCTION public.assign_unique_character();