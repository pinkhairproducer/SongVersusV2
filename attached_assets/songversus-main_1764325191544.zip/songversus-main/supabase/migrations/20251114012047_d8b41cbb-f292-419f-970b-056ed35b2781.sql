-- Add message length constraint to chat_messages table
ALTER TABLE chat_messages 
ADD CONSTRAINT message_length_check 
CHECK (char_length(message) > 0 AND char_length(message) <= 500);

-- Add RLS policies for avatars storage bucket
CREATE POLICY "Users can upload own avatar"
  ON storage.objects FOR INSERT
  WITH CHECK (
    bucket_id = 'avatars' AND
    auth.uid() IS NOT NULL AND
    (storage.foldername(name))[1] = auth.uid()::text
  );

CREATE POLICY "Users can update own avatar"
  ON storage.objects FOR UPDATE
  USING (
    bucket_id = 'avatars' AND
    auth.uid() IS NOT NULL AND
    (storage.foldername(name))[1] = auth.uid()::text
  );

CREATE POLICY "Users can delete own avatar"
  ON storage.objects FOR DELETE
  USING (
    bucket_id = 'avatars' AND
    auth.uid() IS NOT NULL AND
    (storage.foldername(name))[1] = auth.uid()::text
  );

CREATE POLICY "Avatars are publicly readable"
  ON storage.objects FOR SELECT
  USING (bucket_id = 'avatars');

-- Add RLS policies for battle-audio storage bucket
CREATE POLICY "Battle creators can upload audio"
  ON storage.objects FOR INSERT
  WITH CHECK (
    bucket_id = 'battle-audio' AND
    auth.uid() IS NOT NULL
  );

CREATE POLICY "Battle participants can update their audio"
  ON storage.objects FOR UPDATE
  USING (
    bucket_id = 'battle-audio' AND
    auth.uid() IS NOT NULL
  );

CREATE POLICY "Battle participants can delete their audio"
  ON storage.objects FOR DELETE
  USING (
    bucket_id = 'battle-audio' AND
    auth.uid() IS NOT NULL
  );

CREATE POLICY "Battle audio is publicly readable"
  ON storage.objects FOR SELECT
  USING (bucket_id = 'battle-audio');