-- Create table to track daily free spins
CREATE TABLE IF NOT EXISTS public.daily_spins (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id uuid NOT NULL,
  spin_date date NOT NULL DEFAULT CURRENT_DATE,
  created_at timestamptz NOT NULL DEFAULT now(),
  UNIQUE(user_id, spin_date)
);

-- Enable RLS
ALTER TABLE public.daily_spins ENABLE ROW LEVEL SECURITY;

-- Users can view their own spins
CREATE POLICY "Users can view their own spins"
ON public.daily_spins
FOR SELECT
USING (auth.uid() = user_id);

-- Users can insert their own spins
CREATE POLICY "Users can insert their own spins"
ON public.daily_spins
FOR INSERT
WITH CHECK (auth.uid() = user_id);

-- Create function to check and use free spin
CREATE OR REPLACE FUNCTION public.use_daily_free_spin()
RETURNS jsonb
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = 'public'
AS $$
DECLARE
  v_user_id uuid;
  v_already_used boolean;
BEGIN
  v_user_id := auth.uid();
  
  IF v_user_id IS NULL THEN
    RETURN jsonb_build_object('success', false, 'message', 'Not authenticated');
  END IF;
  
  -- Check if already used today
  SELECT EXISTS (
    SELECT 1 FROM daily_spins 
    WHERE user_id = v_user_id 
    AND spin_date = CURRENT_DATE
  ) INTO v_already_used;
  
  IF v_already_used THEN
    RETURN jsonb_build_object('success', false, 'message', 'Already used today');
  END IF;
  
  -- Record the free spin usage
  INSERT INTO daily_spins (user_id, spin_date)
  VALUES (v_user_id, CURRENT_DATE);
  
  RETURN jsonb_build_object('success', true, 'message', 'Free spin claimed!');
END;
$$;