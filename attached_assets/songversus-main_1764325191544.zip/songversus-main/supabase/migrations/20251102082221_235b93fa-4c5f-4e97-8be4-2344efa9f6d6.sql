-- Create enum for role types
CREATE TYPE public.player_role AS ENUM ('producer', 'artist', 'both');

-- Create enum for customization categories
CREATE TYPE public.customization_category AS ENUM ('skin', 'hair', 'eyes', 'outfit', 'accessory', 'effect');

-- Create enum for rarity levels
CREATE TYPE public.rarity AS ENUM ('common', 'rare', 'epic', 'legendary');

-- Create profiles table for user character data
CREATE TABLE public.profiles (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id UUID REFERENCES auth.users(id) ON DELETE CASCADE NOT NULL UNIQUE,
  username TEXT NOT NULL UNIQUE,
  role player_role DEFAULT 'producer',
  level INTEGER DEFAULT 1 NOT NULL,
  xp INTEGER DEFAULT 0 NOT NULL,
  coins INTEGER DEFAULT 100 NOT NULL,
  battles_won INTEGER DEFAULT 0 NOT NULL,
  battles_lost INTEGER DEFAULT 0 NOT NULL,
  avatar_url TEXT,
  created_at TIMESTAMPTZ DEFAULT now() NOT NULL,
  updated_at TIMESTAMPTZ DEFAULT now() NOT NULL
);

-- Create customization_items table (available items in the game)
CREATE TABLE public.customization_items (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  name TEXT NOT NULL,
  category customization_category NOT NULL,
  rarity rarity DEFAULT 'common' NOT NULL,
  is_starter BOOLEAN DEFAULT false NOT NULL,
  image_url TEXT,
  description TEXT,
  created_at TIMESTAMPTZ DEFAULT now() NOT NULL
);

-- Create user_customizations table (items owned by users)
CREATE TABLE public.user_customizations (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id UUID REFERENCES auth.users(id) ON DELETE CASCADE NOT NULL,
  customization_item_id UUID REFERENCES public.customization_items(id) ON DELETE CASCADE NOT NULL,
  is_equipped BOOLEAN DEFAULT false NOT NULL,
  acquired_at TIMESTAMPTZ DEFAULT now() NOT NULL,
  UNIQUE(user_id, customization_item_id)
);

-- Create orbs table (orbs waiting to be opened)
CREATE TABLE public.orbs (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id UUID REFERENCES auth.users(id) ON DELETE CASCADE NOT NULL,
  rarity rarity DEFAULT 'common' NOT NULL,
  can_open_at TIMESTAMPTZ NOT NULL,
  is_opened BOOLEAN DEFAULT false NOT NULL,
  created_at TIMESTAMPTZ DEFAULT now() NOT NULL,
  opened_at TIMESTAMPTZ
);

-- Enable Row Level Security
ALTER TABLE public.profiles ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.customization_items ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.user_customizations ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.orbs ENABLE ROW LEVEL SECURITY;

-- RLS Policies for profiles
CREATE POLICY "Users can view all profiles"
  ON public.profiles FOR SELECT
  USING (true);

CREATE POLICY "Users can insert their own profile"
  ON public.profiles FOR INSERT
  WITH CHECK (auth.uid() = user_id);

CREATE POLICY "Users can update their own profile"
  ON public.profiles FOR UPDATE
  USING (auth.uid() = user_id);

-- RLS Policies for customization_items (public read)
CREATE POLICY "Anyone can view customization items"
  ON public.customization_items FOR SELECT
  USING (true);

-- RLS Policies for user_customizations
CREATE POLICY "Users can view their own customizations"
  ON public.user_customizations FOR SELECT
  USING (auth.uid() = user_id);

CREATE POLICY "Users can insert their own customizations"
  ON public.user_customizations FOR INSERT
  WITH CHECK (auth.uid() = user_id);

CREATE POLICY "Users can update their own customizations"
  ON public.user_customizations FOR UPDATE
  USING (auth.uid() = user_id);

CREATE POLICY "Users can delete their own customizations"
  ON public.user_customizations FOR DELETE
  USING (auth.uid() = user_id);

-- RLS Policies for orbs
CREATE POLICY "Users can view their own orbs"
  ON public.orbs FOR SELECT
  USING (auth.uid() = user_id);

CREATE POLICY "Users can insert their own orbs"
  ON public.orbs FOR INSERT
  WITH CHECK (auth.uid() = user_id);

CREATE POLICY "Users can update their own orbs"
  ON public.orbs FOR UPDATE
  USING (auth.uid() = user_id);

CREATE POLICY "Users can delete their own orbs"
  ON public.orbs FOR DELETE
  USING (auth.uid() = user_id);

-- Function to update updated_at timestamp
CREATE OR REPLACE FUNCTION public.update_updated_at_column()
RETURNS TRIGGER AS $$
BEGIN
  NEW.updated_at = now();
  RETURN NEW;
END;
$$ LANGUAGE plpgsql SECURITY DEFINER SET search_path = public;

-- Trigger for profiles updated_at
CREATE TRIGGER update_profiles_updated_at
  BEFORE UPDATE ON public.profiles
  FOR EACH ROW
  EXECUTE FUNCTION public.update_updated_at_column();

-- Function to handle new user signup
CREATE OR REPLACE FUNCTION public.handle_new_user()
RETURNS TRIGGER AS $$
BEGIN
  INSERT INTO public.profiles (user_id, username)
  VALUES (
    NEW.id,
    COALESCE(NEW.raw_user_meta_data->>'username', 'Player_' || substring(NEW.id::text from 1 for 8))
  );
  RETURN NEW;
END;
$$ LANGUAGE plpgsql SECURITY DEFINER SET search_path = public;

-- Trigger to create profile on signup
CREATE TRIGGER on_auth_user_created
  AFTER INSERT ON auth.users
  FOR EACH ROW
  EXECUTE FUNCTION public.handle_new_user();

-- Function to award orb after 5 wins
CREATE OR REPLACE FUNCTION public.check_and_award_orb()
RETURNS TRIGGER AS $$
BEGIN
  -- Check if battles_won is divisible by 5 and greater than old value
  IF NEW.battles_won % 5 = 0 AND NEW.battles_won > OLD.battles_won THEN
    INSERT INTO public.orbs (user_id, rarity, can_open_at)
    VALUES (
      NEW.user_id,
      'common',
      now() + INTERVAL '24 hours'
    );
  END IF;
  RETURN NEW;
END;
$$ LANGUAGE plpgsql SECURITY DEFINER SET search_path = public;

-- Trigger to award orb
CREATE TRIGGER award_orb_trigger
  AFTER UPDATE ON public.profiles
  FOR EACH ROW
  EXECUTE FUNCTION public.check_and_award_orb();

-- Insert starter customization items
INSERT INTO public.customization_items (name, category, rarity, is_starter, description) VALUES
  ('Default Skin', 'skin', 'common', true, 'Standard arena fighter skin'),
  ('Buzz Cut', 'hair', 'common', true, 'Classic short hair'),
  ('Normal Eyes', 'eyes', 'common', true, 'Standard eye design'),
  ('Arena Outfit', 'outfit', 'common', true, 'Basic battle gear'),
  ('Neon Skin', 'skin', 'rare', false, 'Glowing neon skin effect'),
  ('Cyber Hair', 'hair', 'rare', false, 'Digital matrix hairstyle'),
  ('Laser Eyes', 'eyes', 'epic', false, 'Eyes that glow with power'),
  ('Battle Armor', 'outfit', 'epic', false, 'Heavy combat armor'),
  ('Victory Aura', 'effect', 'legendary', false, 'Pulsing aura of triumph'),
  ('Sound Wave Ring', 'accessory', 'rare', false, 'Floating sound wave rings');