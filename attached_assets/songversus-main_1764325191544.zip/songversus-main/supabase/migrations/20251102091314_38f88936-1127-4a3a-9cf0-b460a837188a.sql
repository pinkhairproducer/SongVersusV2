-- Add foreign key constraints for battles table
ALTER TABLE public.battles
ADD CONSTRAINT battles_creator_id_fkey 
FOREIGN KEY (creator_id) 
REFERENCES auth.users(id) 
ON DELETE CASCADE;

ALTER TABLE public.battles
ADD CONSTRAINT battles_opponent_id_fkey 
FOREIGN KEY (opponent_id) 
REFERENCES auth.users(id) 
ON DELETE CASCADE;

-- Add foreign key constraint for battle_comments
ALTER TABLE public.battle_comments
ADD CONSTRAINT battle_comments_user_id_fkey 
FOREIGN KEY (user_id) 
REFERENCES auth.users(id) 
ON DELETE CASCADE;