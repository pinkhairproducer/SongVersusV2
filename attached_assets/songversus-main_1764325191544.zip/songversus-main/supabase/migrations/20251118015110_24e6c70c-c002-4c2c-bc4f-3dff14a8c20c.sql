-- Add 'finished' as a valid battle status
ALTER TABLE battles 
DROP CONSTRAINT IF EXISTS battles_status_check;

ALTER TABLE battles
ADD CONSTRAINT battles_status_check 
CHECK (status IN ('open', 'ongoing', 'completed', 'finished'));

-- Now update battles that should be marked as finished
UPDATE battles 
SET status = 'finished', updated_at = now()
WHERE status IN ('open', 'ongoing') 
  AND ends_at IS NOT NULL 
  AND ends_at + INTERVAL '24 hours' < now();

-- Create a function to automatically mark battles as finished
CREATE OR REPLACE FUNCTION public.check_finished_battles()
RETURNS void
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public
AS $$
BEGIN
  UPDATE battles 
  SET status = 'finished', updated_at = now()
  WHERE status IN ('open', 'ongoing') 
    AND ends_at IS NOT NULL 
    AND ends_at + INTERVAL '24 hours' < now();
END;
$$;