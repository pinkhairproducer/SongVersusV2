-- Enable pg_cron and pg_net extensions for scheduled jobs
CREATE EXTENSION IF NOT EXISTS pg_cron WITH SCHEMA extensions;
CREATE EXTENSION IF NOT EXISTS pg_net WITH SCHEMA extensions;

-- Update the record_battle_vote function to prevent voting on finished battles
CREATE OR REPLACE FUNCTION public.record_battle_vote(p_battle_id uuid, p_user_id uuid, p_voted_for text)
RETURNS void
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path TO 'public'
AS $function$
DECLARE
  v_old_vote text;
  v_battle_status text;
BEGIN
  -- Check if battle is finished
  SELECT status INTO v_battle_status
  FROM battles
  WHERE id = p_battle_id;
  
  IF v_battle_status IS NULL THEN
    RAISE EXCEPTION 'Battle not found';
  END IF;
  
  IF v_battle_status = 'finished' THEN
    RAISE EXCEPTION 'Cannot vote on a finished battle';
  END IF;

  -- Validate voted_for value
  IF p_voted_for NOT IN ('creator', 'opponent') THEN
    RAISE EXCEPTION 'Invalid vote target: must be creator or opponent';
  END IF;

  -- Get existing vote if any
  SELECT voted_for INTO v_old_vote
  FROM battle_votes
  WHERE battle_id = p_battle_id AND user_id = p_user_id;

  -- Update or insert vote (unique constraint prevents duplicate votes)
  INSERT INTO battle_votes (battle_id, user_id, voted_for)
  VALUES (p_battle_id, p_user_id, p_voted_for)
  ON CONFLICT (battle_id, user_id) 
  DO UPDATE SET voted_for = p_voted_for, created_at = now();

  -- Recalculate vote counts from actual votes (prevents manipulation)
  UPDATE battles
  SET 
    creator_votes = (SELECT COUNT(*) FROM battle_votes WHERE battle_id = p_battle_id AND voted_for = 'creator'),
    opponent_votes = (SELECT COUNT(*) FROM battle_votes WHERE battle_id = p_battle_id AND voted_for = 'opponent'),
    updated_at = now()
  WHERE id = p_battle_id;
END;
$function$;

-- Ensure unique constraint exists on battle_votes (one vote per user per battle)
DO $$ 
BEGIN
  IF NOT EXISTS (
    SELECT 1 FROM pg_constraint 
    WHERE conname = 'battle_votes_battle_id_user_id_key'
  ) THEN
    ALTER TABLE battle_votes ADD CONSTRAINT battle_votes_battle_id_user_id_key UNIQUE (battle_id, user_id);
  END IF;
END $$;