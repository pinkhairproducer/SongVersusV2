-- Create function to update battle status
CREATE OR REPLACE FUNCTION update_battle_status()
RETURNS TRIGGER AS $$
BEGIN
  -- If both players have uploaded audio, set status to ongoing
  IF NEW.creator_audio_url IS NOT NULL 
     AND NEW.opponent_audio_url IS NOT NULL 
     AND NEW.opponent_id IS NOT NULL
     AND NEW.status = 'open' THEN
    NEW.status := 'ongoing';
  END IF;
  
  RETURN NEW;
END;
$$ LANGUAGE plpgsql;

-- Create trigger on battles table
DROP TRIGGER IF EXISTS trigger_update_battle_status ON battles;
CREATE TRIGGER trigger_update_battle_status
  BEFORE UPDATE ON battles
  FOR EACH ROW
  EXECUTE FUNCTION update_battle_status();

-- Update existing battles that should be ongoing
UPDATE battles
SET status = 'ongoing'
WHERE status = 'open'
  AND creator_audio_url IS NOT NULL
  AND opponent_audio_url IS NOT NULL
  AND opponent_id IS NOT NULL;