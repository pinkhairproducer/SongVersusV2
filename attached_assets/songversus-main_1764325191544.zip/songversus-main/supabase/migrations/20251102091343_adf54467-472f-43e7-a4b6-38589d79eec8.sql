-- Drop the foreign keys to auth.users
ALTER TABLE public.battles
DROP CONSTRAINT IF EXISTS battles_creator_id_fkey,
DROP CONSTRAINT IF EXISTS battles_opponent_id_fkey;

ALTER TABLE public.battle_comments
DROP CONSTRAINT IF EXISTS battle_comments_user_id_fkey;

-- Create references to profiles instead (using user_id column in profiles)
-- We can't directly reference profiles.user_id, so we need to add the user_ids to battles
-- First, let's create proper indexes
CREATE INDEX IF NOT EXISTS idx_profiles_user_id ON public.profiles(user_id);

-- Note: battles.creator_id and battles.opponent_id should reference the user_id from auth
-- We'll rely on RLS policies for data integrity instead of foreign keys to auth.users