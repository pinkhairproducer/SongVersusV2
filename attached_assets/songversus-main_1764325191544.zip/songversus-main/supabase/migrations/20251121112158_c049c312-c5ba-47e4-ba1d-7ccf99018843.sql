-- Enable realtime for battles table
ALTER PUBLICATION supabase_realtime ADD TABLE public.battles;