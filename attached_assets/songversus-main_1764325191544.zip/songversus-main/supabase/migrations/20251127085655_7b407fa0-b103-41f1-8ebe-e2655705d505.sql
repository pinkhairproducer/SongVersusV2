-- Fix the check_finished_battles function to correctly identify finished battles
DROP FUNCTION IF EXISTS public.check_finished_battles();

CREATE OR REPLACE FUNCTION public.check_finished_battles()
RETURNS void
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path TO 'public'
AS $$
BEGIN
  -- Update battles that have passed their end time
  UPDATE battles 
  SET status = 'finished', updated_at = now()
  WHERE status IN ('open', 'ongoing') 
    AND ends_at IS NOT NULL 
    AND ends_at < now();
END;
$$;

-- Create function to update player statistics when battle finishes
CREATE OR REPLACE FUNCTION public.update_battle_results()
RETURNS trigger
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path TO 'public'
AS $$
DECLARE
  v_creator_won boolean;
  v_xp_reward integer := 50;
  v_coin_reward integer := 25;
BEGIN
  -- Only process when status changes to 'finished'
  IF NEW.status = 'finished' AND OLD.status != 'finished' THEN
    -- Determine winner based on votes
    v_creator_won := NEW.creator_votes > NEW.opponent_votes;
    
    -- Update creator stats
    IF v_creator_won THEN
      UPDATE profiles
      SET 
        battles_won = battles_won + 1,
        xp = xp + v_xp_reward,
        coins = coins + v_coin_reward,
        updated_at = now()
      WHERE user_id = NEW.creator_id;
      
      -- Loser still gets participation XP
      IF NEW.opponent_id IS NOT NULL THEN
        UPDATE profiles
        SET 
          battles_lost = battles_lost + 1,
          xp = xp + (v_xp_reward / 2),
          updated_at = now()
        WHERE user_id = NEW.opponent_id;
      END IF;
    ELSE
      -- Opponent won
      IF NEW.opponent_id IS NOT NULL THEN
        UPDATE profiles
        SET 
          battles_won = battles_won + 1,
          xp = xp + v_xp_reward,
          coins = coins + v_coin_reward,
          updated_at = now()
        WHERE user_id = NEW.opponent_id;
      END IF;
      
      UPDATE profiles
      SET 
        battles_lost = battles_lost + 1,
        xp = xp + (v_xp_reward / 2),
        updated_at = now()
      WHERE user_id = NEW.creator_id;
    END IF;
  END IF;
  
  RETURN NEW;
END;
$$;

-- Create trigger to update stats when battle finishes
DROP TRIGGER IF EXISTS on_battle_finished ON battles;

CREATE TRIGGER on_battle_finished
  AFTER UPDATE ON battles
  FOR EACH ROW
  EXECUTE FUNCTION public.update_battle_results();