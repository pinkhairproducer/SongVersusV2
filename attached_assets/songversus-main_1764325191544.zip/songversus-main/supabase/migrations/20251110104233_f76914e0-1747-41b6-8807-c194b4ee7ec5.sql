-- Add gems column to profiles table
ALTER TABLE public.profiles 
ADD COLUMN gems integer NOT NULL DEFAULT 0;